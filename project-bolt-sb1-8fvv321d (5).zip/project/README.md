# Vehicle Repair Management System (RMS)

A comprehensive vehicle repair management platform connecting drivers with verified mechanics on the Freetown to Mile 91 highway in Sierra Leone.

## 🚀 Features

- **Smart Authentication**: Unified login system that automatically detects user type
- **Real-time GPS Tracking**: Live Google Maps integration with satellite view
- **Service Request Management**: Complete workflow from request to payment
- **Payment Integration**: Mobile money support (Orange Money, Qcell Money, Afrimoney)
- **Admin Dashboard**: Comprehensive system management and analytics
- **Responsive Design**: Works seamlessly on desktop and mobile devices

## 🛠️ Technology Stack

### Frontend
- **React 18.3.1** - Modern UI library with hooks
- **TypeScript 5.5.3** - Type-safe development
- **Tailwind CSS 3.4.1** - Utility-first styling
- **React Router DOM 6.26.1** - Client-side routing
- **Lucide React 0.344.0** - Beautiful icons
- **Vite 5.4.2** - Fast build tool

### Maps & Location
- **Google Maps JavaScript API** - Interactive satellite maps
- **Geolocation API** - GPS tracking
- **@googlemaps/js-api-loader** - Maps integration

### APIs & Services
- **MediaRecorder API** - Audio recording
- **File Reader API** - Photo uploads
- **LocalStorage** - Client-side data persistence

## 🗺️ Google Maps Setup

1. **Get Google Maps API Key:**
   - Go to [Google Cloud Console](https://console.cloud.google.com/)
   - Create a new project or select existing one
   - Enable "Maps JavaScript API"
   - Create credentials (API Key)
   - Restrict the API key to your domain for security

2. **Configure Environment:**
   ```bash
   cp .env.example .env
   # Edit .env and add your Google Maps API key
   VITE_GOOGLE_MAPS_API_KEY=your_actual_api_key_here
   ```

3. **Map Features:**
   - **Satellite View**: High-resolution satellite imagery
   - **Hybrid Mode**: Satellite with road overlays
   - **Real-time Tracking**: Live GPS updates
   - **Route Planning**: Turn-by-turn directions
   - **Custom Markers**: Driver, mechanic, and location pins

## 🚀 Getting Started

1. **Clone the repository:**
   ```bash
   git clone <repository-url>
   cd vehicle-repair-management-system
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Set up environment variables:**
   ```bash
   cp .env.example .env
   # Edit .env with your Google Maps API key
   ```

4. **Start development server:**
   ```bash
   npm run dev
   ```

5. **Open in browser:**
   ```
   http://localhost:5173
   ```

## 👥 Demo Accounts

### Admin Account
- **Email**: admin@vehiclerms.com
- **Password**: admin123

### Test Accounts
- Create driver and mechanic accounts through registration
- Mechanic accounts require admin approval

## 🎯 User Roles

### **Drivers**
- Request vehicle assistance
- Upload photos and audio explanations
- Track mechanic location in real-time
- Make payments through mobile money

### **Mechanics**
- Receive and accept service requests
- Navigate to breakdown locations
- Update job status in real-time
- Receive payments automatically

### **Administrators**
- Approve mechanic registrations
- Monitor system activity
- Generate comprehensive reports
- Manage user accounts

## 📱 Key Features

### **Smart Authentication**
- Single login page for all user types
- Automatic role detection
- Real-time user preview
- Secure session management

### **Google Maps Integration**
- **Satellite View**: Crystal-clear satellite imagery
- **Live Tracking**: Real-time GPS updates
- **Route Planning**: Optimized navigation
- **Custom Markers**: Role-specific location pins
- **Interactive Controls**: Map type switching

### **Service Management**
- Photo documentation
- Audio explanations
- Urgency level classification
- Real-time status updates

### **Payment System**
- Mobile money integration
- Automatic fee calculation
- Commission tracking
- Payment history

## 🔧 Development

### **Build for Production**
```bash
npm run build
```

### **Preview Production Build**
```bash
npm run preview
```

### **Lint Code**
```bash
npm run lint
```

## 🌟 Recommended Enhancements

### **Backend Infrastructure**
- PostgreSQL/MongoDB database
- Node.js API server
- Real-time WebSocket communication
- Cloud storage for media files

### **Advanced Features**
- Push notifications
- SMS integration
- Email notifications
- AI-powered matching
- Preventive maintenance scheduling

### **Mobile Development**
- React Native mobile apps
- Progressive Web App (PWA)
- Offline capabilities
- Background location tracking

## 📊 System Architecture

```
Frontend (React + TypeScript)
├── Authentication System
├── Google Maps Integration
├── Real-time Location Tracking
├── Payment Processing
└── Admin Dashboard

Data Layer (LocalStorage → Database)
├── User Management
├── Service Requests
├── Payment Records
└── System Analytics
```

## 🔒 Security Features

- Email validation and normalization
- Account suspension enforcement
- Session timeout management
- Role-based access control
- Input sanitization

## 📈 Analytics & Reporting

- User activity tracking
- Service completion rates
- Revenue analytics
- Performance metrics
- Exportable reports

## 🌍 Deployment

The system is designed for deployment on:
- **Frontend**: Netlify, Vercel, or AWS S3
- **Backend**: AWS, Azure, or Google Cloud
- **Database**: PostgreSQL on cloud providers
- **Maps**: Google Maps Platform

## 📞 Support

For technical support or feature requests, please contact the development team.

---

**Vehicle Repair Management System (RMS)** - Professional vehicle repair management platform for Sierra Leone.