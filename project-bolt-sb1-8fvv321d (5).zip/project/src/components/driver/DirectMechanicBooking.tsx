import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import TrackingNotification from '../notifications/TrackingNotification';
import { MapPin, Phone, Car, Clock, Star, CheckCircle, Camera, Mic, MicOff, Play, X, Mail, MessageSquare, Upload, Volume2, ArrowLeft, AlertTriangle } from 'lucide-react';
import { useLocation } from '../../context/LocationContext';
import { Mechanic } from '../../types';
import { databaseAPI, generateTrackingId, BreakdownRequest } from '../../services/api';
import Card from '../ui/Card';
import Button from '../ui/Button';
import Input from '../ui/Input';
import GoogleMapView from '../maps/GoogleMapView';

const DirectMechanicBooking: React.FC = () => {
  const { currentLocation, requestLocation, locationError } = useLocation();
  const [availableMechanics, setAvailableMechanics] = useState<Mechanic[]>([]);
  const [selectedMechanic, setSelectedMechanic] = useState<Mechanic | null>(null);
  const [showBookingForm, setShowBookingForm] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showTrackingNotification, setShowTrackingNotification] = useState(false);
  const [generatedTrackingId, setGeneratedTrackingId] = useState<string>('');
  const [bookingData, setBookingData] = useState({
    phoneNumber: '',
    email: '',
    vehicleType: '',
    vehicleMake: '',
    vehicleModel: '',
    vehicleYear: '',
    problemDescription: '',
    urgencyLevel: 'medium' as 'low' | 'medium' | 'high' | 'emergency',
    photos: [] as string[],
    audioExplanation: '',
    additionalNotes: '',
  });
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string>('');
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [trackingId, setTrackingId] = useState<string>('');
  const [bookingConfirmed, setBookingConfirmed] = useState(false);
  const navigate = useNavigate();

  const vehicleTypes = ['Sedan', 'SUV', 'Truck', 'Van', 'Motorcycle', 'Bus'];
  const urgencyLevels = [
    { value: 'low', label: 'Low Priority', color: 'green', description: 'Can wait 1-2 hours', multiplier: 1.0 },
    { value: 'medium', label: 'Medium Priority', color: 'yellow', description: 'Need help soon', multiplier: 1.2 },
    { value: 'high', label: 'High Priority', color: 'orange', description: 'Urgent assistance', multiplier: 1.4 },
    { value: 'emergency', label: 'Emergency', color: 'red', description: 'Immediate help needed', multiplier: 1.6 },
  ];

  useEffect(() => {
    // Request location and load mechanics immediately
    if (!currentLocation) {
      requestLocation();
    }
    loadAvailableMechanics();
  }, []);

  useEffect(() => {
    if (currentLocation) {
      loadAvailableMechanics();
    }
  }, [currentLocation]);

  const loadAvailableMechanics = () => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const approvedMechanics = users.filter((u: any) => 
      u.role === 'mechanic' && 
      u.isApproved && 
      u.isOnline
    );
    
    // Add mock current locations for demo
    const mechanicsWithLocation = approvedMechanics.map((mechanic: any, index: number) => ({
      ...mechanic,
      currentLocation: mechanic.currentLocation || {
        lat: 8.4657 + (Math.random() - 0.5) * 0.1, // Around Freetown
        lng: -13.2317 + (Math.random() - 0.5) * 0.1,
      }
    }));
    
    setAvailableMechanics(mechanicsWithLocation);
  };

  const calculateDistance = (mechanic: Mechanic) => {
    if (!currentLocation || !mechanic.currentLocation) return 0;
    
    const lat1 = currentLocation.lat;
    const lng1 = currentLocation.lng;
    const lat2 = mechanic.currentLocation.lat;
    const lng2 = mechanic.currentLocation.lng;
    
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c;
    
    return distance;
  };

  const getEstimatedArrival = (mechanic: Mechanic) => {
    const distance = calculateDistance(mechanic);
    const estimatedMinutes = Math.round(distance * 2.5); // Assuming 24km/h average speed
    return estimatedMinutes;
  };

  const calculateEstimatedCost = () => {
    if (!bookingData.vehicleType || !bookingData.urgencyLevel) return 0;
    
    let baseCost = 75000; // Base cost in Sierra Leone Leones
    
    // Urgency multiplier
    const urgencyMultiplier = urgencyLevels.find(u => u.value === bookingData.urgencyLevel)?.multiplier || 1.0;
    baseCost *= urgencyMultiplier;
    
    // Vehicle type multiplier
    const vehicleMultipliers = {
      'Sedan': 1.0,
      'SUV': 1.2,
      'Truck': 1.5,
      'Van': 1.3,
      'Motorcycle': 0.8,
      'Bus': 1.6,
    };
    baseCost *= vehicleMultipliers[bookingData.vehicleType as keyof typeof vehicleMultipliers] || 1.0;
    
    return Math.round(baseCost);
  };

  const handleMechanicSelect = (mechanic: Mechanic) => {
    setSelectedMechanic(mechanic);
    setShowBookingForm(true);
  };

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      const newPhotos: string[] = [];
      Array.from(files).forEach((file) => {
        const reader = new FileReader();
        reader.onload = (e) => {
          if (e.target?.result) {
            newPhotos.push(e.target.result as string);
            if (newPhotos.length === files.length) {
              setBookingData(prev => ({
                ...prev,
                photos: [...prev.photos, ...newPhotos].slice(0, 5)
              }));
            }
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const removePhoto = (index: number) => {
    setBookingData(prev => ({
      ...prev,
      photos: prev.photos.filter((_, i) => i !== index)
    }));
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks: BlobPart[] = [];

      recorder.ondataavailable = (e) => chunks.push(e.data);
      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/wav' });
        setAudioBlob(blob);
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
        setBookingData(prev => ({ ...prev, audioExplanation: url }));
      };

      recorder.start();
      setMediaRecorder(recorder);
      setIsRecording(true);
    } catch (error) {
      alert('Could not access microphone. Please check permissions.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorder && isRecording) {
      mediaRecorder.stop();
      mediaRecorder.stream.getTracks().forEach(track => track.stop());
      setIsRecording(false);
    }
  };

  const removeAudio = () => {
    setAudioBlob(null);
    setAudioUrl('');
    setBookingData(prev => ({ ...prev, audioExplanation: '' }));
  };

  const generateTrackingId = () => {
    const timestamp = Date.now().toString().slice(-6);
    const random = Math.random().toString(36).substring(2, 5).toUpperCase();
    return `VRM-${new Date().getFullYear()}-${random}${timestamp}`;
  };

  const sendNotifications = (trackingId: string, phoneNumber: string, email: string, mechanicName: string, isAccepted: boolean, rejectionReason?: string) => {
    const trackingUrl = `${window.location.origin}/track/${trackingId}`;
    
    if (isAccepted) {
      // SMS notification for acceptance
      const smsDiv = document.createElement('div');
      smsDiv.className = 'fixed top-4 right-4 bg-green-600 text-white p-4 rounded-lg shadow-lg z-50 max-w-sm';
      smsDiv.innerHTML = `
        <div class="flex items-start space-x-3">
          <div class="bg-white/20 rounded-full p-1">
            <svg class="h-4 w-4 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"/>
              <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"/>
            </svg>
          </div>
          <div class="flex-1">
            <p class="font-medium text-sm">SMS Sent to ${phoneNumber}</p>
            <p class="text-xs text-green-100 mt-1">✅ ${mechanicName} accepted your request!</p>
            <p class="text-xs text-green-200 mt-2">Track: ${trackingUrl}</p>
          </div>
        </div>
      `;
      
      document.body.appendChild(smsDiv);
      setTimeout(() => {
        if (document.body.contains(smsDiv)) {
          document.body.removeChild(smsDiv);
        }
      }, 8000);

      // Email notification for acceptance
      setTimeout(() => {
        const emailDiv = document.createElement('div');
        emailDiv.className = 'fixed top-20 right-4 bg-blue-600 text-white p-4 rounded-lg shadow-lg z-50 max-w-sm';
        emailDiv.innerHTML = `
          <div class="flex items-start space-x-3">
            <div class="bg-white/20 rounded-full p-1">
              <svg class="h-4 w-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2.586l-4.293 4.293a1 1 0 01-1.414 0L7 6.586V4z"/>
                <path d="M3 8.414V16a1 1 0 001 1h12a1 1 0 001-1V8.414l-4.293 4.293a3 3 0 01-4.242 0L3 8.414z"/>
              </svg>
            </div>
            <div class="flex-1">
              <p class="font-medium text-sm">Email Sent to ${email}</p>
              <p class="text-xs text-blue-100 mt-1">✅ Request Accepted - Track Your Service</p>
              <p class="text-xs text-blue-200 mt-2">Tracking ID: ${trackingId}</p>
            </div>
          </div>
        `;
        
        document.body.appendChild(emailDiv);
        setTimeout(() => {
          if (document.body.contains(emailDiv)) {
            document.body.removeChild(emailDiv);
          }
        }, 8000);
      }, 2000);
    } else {
      // SMS notification for rejection
      const smsDiv = document.createElement('div');
      smsDiv.className = 'fixed top-4 right-4 bg-red-600 text-white p-4 rounded-lg shadow-lg z-50 max-w-sm';
      smsDiv.innerHTML = `
        <div class="flex items-start space-x-3">
          <div class="bg-white/20 rounded-full p-1">
            <svg class="h-4 w-4 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"/>
              <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"/>
            </svg>
          </div>
          <div class="flex-1">
            <p class="font-medium text-sm">SMS Sent to ${phoneNumber}</p>
            <p class="text-xs text-red-100 mt-1">❌ Request Rejected by ${mechanicName}</p>
            <p class="text-xs text-red-200 mt-2">Reason: ${rejectionReason}</p>
          </div>
        </div>
      `;
      
      document.body.appendChild(smsDiv);
      setTimeout(() => {
        if (document.body.contains(smsDiv)) {
          document.body.removeChild(smsDiv);
        }
      }, 8000);

      // Email notification for rejection
      setTimeout(() => {
        const emailDiv = document.createElement('div');
        emailDiv.className = 'fixed top-20 right-4 bg-red-600 text-white p-4 rounded-lg shadow-lg z-50 max-w-sm';
        emailDiv.innerHTML = `
          <div class="flex items-start space-x-3">
            <div class="bg-white/20 rounded-full p-1">
              <svg class="h-4 w-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2.586l-4.293 4.293a1 1 0 01-1.414 0L7 6.586V4z"/>
                <path d="M3 8.414V16a1 1 0 001 1h12a1 1 0 001-1V8.414l-4.293 4.293a3 3 0 01-4.242 0L3 8.414z"/>
              </svg>
            </div>
            <div class="flex-1">
              <p class="font-medium text-sm">Email Sent to ${email}</p>
              <p class="text-xs text-red-100 mt-1">❌ Request Rejected - Try Another Mechanic</p>
              <p class="text-xs text-red-200 mt-2">Reason: ${rejectionReason}</p>
            </div>
          </div>
        `;
        
        document.body.appendChild(emailDiv);
        setTimeout(() => {
          if (document.body.contains(emailDiv)) {
            document.body.removeChild(emailDiv);
          }
        }, 8000);
      }, 2000);
    }
  };

  const handleBookingSubmit = async () => {
    if (!selectedMechanic || !currentLocation) return;

    setIsLoading(true);

    try {
      // Create breakdown request data
      const breakdownRequestData = {
        driverPhone: bookingData.phoneNumber,
        driverEmail: bookingData.email,
        driverName: bookingData.fullName || '',
        vehicleType: bookingData.vehicleType,
        vehicleMake: bookingData.vehicleMake,
        vehicleModel: bookingData.vehicleModel,
        vehicleYear: bookingData.vehicleYear,
        problemDescription: bookingData.problemDescription,
        urgencyLevel: bookingData.urgencyLevel,
        location: {
          lat: currentLocation.lat,
          lng: currentLocation.lng,
          address: `${currentLocation.lat.toFixed(6)}, ${currentLocation.lng.toFixed(6)}`,
        },
        photos: bookingData.photos,
        audioExplanation: bookingData.audioExplanation,
        additionalNotes: bookingData.additionalNotes,
        mechanic: selectedMechanic
      };

      // Submit to backend API
      const result = await apiService.createBreakdownRequest(breakdownRequestData);

      // Show tracking notification immediately
      setGeneratedTrackingId(result.trackingId);
      setShowTrackingNotification(true);
      
      // Reset form
      setBookingData({
        phoneNumber: '',
        email: '',
        vehicleType: '',
        vehicleMake: '',
        vehicleModel: '',
        vehicleYear: '',
        problemDescription: '',
        urgencyLevel: 'medium',
        photos: [],
        audioExplanation: '',
        additionalNotes: '',
      });
      setSelectedMechanic(null);
      setShowBookingForm(false);
      setAudioBlob(null);
      
    } catch (error) {
      console.error('Error submitting booking:', error);
      alert('Failed to submit booking. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleNavigateToTracking = () => {
    setShowTrackingNotification(false);
    navigate(`/track/${generatedTrackingId}`);
  };

  const handleCloseNotification = () => {
    setShowTrackingNotification(false);
    // Optionally redirect to home or stay on current page
  };

  const showEmailNotification = (type: string, email: string, message: string) => {
    // Create email notification popup
    const notification = document.createElement('div');
    notification.className = 'fixed top-4 right-4 bg-blue-600 text-white p-4 rounded-lg shadow-lg z-50 max-w-sm';
    notification.innerHTML = `
      <div class="flex items-start space-x-3">
        <div class="bg-white/20 rounded-full p-1">
          <svg class="h-4 w-4 text-white" fill="currentColor" viewBox="0 0 20 20">
            <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2.586l-4.293 4.293a1 1 0 01-1.414 0L7 6.586V4z"/>
            <path d="M3 8.414V16a1 1 0 001 1h12a1 1 0 001-1V8.414l-4.293 4.293a3 3 0 01-4.242 0L3 8.414z"/>
          </svg>
        </div>
        <div class="flex-1">
          <p class="font-medium text-sm">📧 Email Sent</p>
          <p class="text-xs text-blue-100 mt-1">${message}</p>
        </div>
      </div>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
      if (document.body.contains(notification)) {
        document.body.removeChild(notification);
      }
    }, 5000);
  };

  // Remove old localStorage logic
  const oldHandleBookingSubmit = async () => {
    if (!selectedMechanic || !currentLocation) return;

    setIsLoading(true);

    // Generate unique tracking ID
    const newTrackingId = generateTrackingId();
    const trackingUrl = `${window.location.origin}/track/${newTrackingId}`;

    // Create guest booking (legacy)
    const guestBooking: any = {
      id: newTrackingId,
      phoneNumber: bookingData.phoneNumber,
      email: bookingData.email,
      vehicleType: bookingData.vehicleType,
      vehicleMake: bookingData.vehicleMake,
      vehicleModel: bookingData.vehicleModel,
      vehicleYear: bookingData.vehicleYear,
      problemDescription: bookingData.problemDescription,
      urgencyLevel: bookingData.urgencyLevel,
      breakdownLocation: {
        lat: currentLocation.lat,
        lng: currentLocation.lng,
        address: `${currentLocation.lat.toFixed(6)}, ${currentLocation.lng.toFixed(6)}`,
      },
      mechanicId: selectedMechanic.id,
      status: 'pending',
      estimatedCost: calculateEstimatedCost(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      photos: bookingData.photos,
      audioExplanation: bookingData.audioExplanation,
      additionalNotes: bookingData.additionalNotes,
      trackingUrl,
      smsLinkSent: true,
    };

    // Save to localStorage
    const guestBookings = JSON.parse(localStorage.getItem('guestBookings') || '[]');
    guestBookings.push(guestBooking);
    localStorage.setItem('guestBookings', JSON.stringify(guestBookings));

    // Also add to regular service requests for mechanic dashboard
    const serviceRequests = JSON.parse(localStorage.getItem('serviceRequests') || '[]');
    const serviceRequest = {
      id: newTrackingId,
      driverId: `guest-${newTrackingId}`,
      mechanicId: selectedMechanic.id,
      vehicleType: bookingData.vehicleType,
      vehicleMake: bookingData.vehicleMake,
      vehicleModel: bookingData.vehicleModel,
      vehicleYear: bookingData.vehicleYear,
      problemDescription: bookingData.problemDescription,
      urgencyLevel: bookingData.urgencyLevel,
      breakdownLocation: guestBooking.breakdownLocation,
      photos: bookingData.photos,
      audioExplanation: bookingData.audioExplanation,
      additionalNotes: bookingData.additionalNotes,
      status: 'pending',
      estimatedCost: calculateEstimatedCost(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      isGuestBooking: true,
      guestPhone: bookingData.phoneNumber,
      guestEmail: bookingData.email,
    };
    serviceRequests.push(serviceRequest);
    localStorage.setItem('serviceRequests', JSON.stringify(serviceRequests));

    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setTrackingId(newTrackingId);
    setBookingConfirmed(true);
    setIsLoading(false);
  };

  // Show location request if no location
  if (!currentLocation && !locationError) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <div className="h-16 w-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <MapPin className="h-8 w-8 text-blue-600 animate-pulse" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Vehicle Repair Management System</h1>
          <p className="text-gray-600 mb-6">
            We need your location to show you nearby mechanics and provide accurate service estimates.
          </p>
          
          <Button
            onClick={requestLocation}
            variant="primary"
            fullWidth
            icon={MapPin}
            className="mb-4"
          >
            Enable Location Access
          </Button>
          
          <Link to="/" className="text-sm text-gray-500 hover:text-gray-700">
            ← Back to Home
          </Link>
        </Card>
      </div>
    );
  }

  // Show location error
  if (locationError) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <div className="h-16 w-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <AlertTriangle className="h-8 w-8 text-red-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Location Required</h1>
          <p className="text-gray-600 mb-6">{locationError}</p>
          
          <div className="space-y-3">
            <Button
              onClick={requestLocation}
              variant="primary"
              fullWidth
              icon={MapPin}
            >
              Try Again
            </Button>
            
            <Link to="/">
              <Button variant="secondary" fullWidth>
                Back to Home
              </Button>
            </Link>
          </div>
        </Card>
      </div>
    );
  }

  // Show booking confirmation
  if (bookingConfirmed) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-lg text-center">
          <div className="h-20 w-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="h-10 w-10 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Request Sent Successfully!</h1>
          <p className="text-gray-600 mb-6">
            Your service request has been sent to <span className="font-semibold">{selectedMechanic?.businessName}</span>. 
            You will receive SMS and email notifications when the mechanic responds.
          </p>
          
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
            <div className="flex items-center justify-center space-x-3 mb-4">
              <MessageSquare className="h-6 w-6 text-blue-600" />
              <Mail className="h-6 w-6 text-blue-600" />
            </div>
            <p className="text-sm font-medium text-blue-900 mb-2">Tracking Information</p>
            <p className="text-lg font-mono text-blue-700 mb-2">{trackingId}</p>
            <p className="text-xs text-blue-600">
              📱 SMS: {bookingData.phoneNumber}<br/>
              📧 Email: {bookingData.email}
            </p>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
            <p className="text-sm text-yellow-800">
              <strong>⏳ Waiting for mechanic response...</strong><br/>
              You'll receive notifications when {selectedMechanic?.businessName} accepts or rejects your request.
            </p>
          </div>

          <div className="space-y-3">
            <Button
              onClick={() => {
                // Reset form and go back to mechanic list
                setBookingConfirmed(false);
                setShowBookingForm(false);
                setSelectedMechanic(null);
                setBookingData({
                  phoneNumber: '',
                  email: '',
                  vehicleType: '',
                  vehicleMake: '',
                  vehicleModel: '',
                  vehicleYear: '',
                  problemDescription: '',
                  urgencyLevel: 'medium',
                  photos: [],
                  audioExplanation: '',
                  additionalNotes: '',
                });
                setTrackingId('');
              }}
              variant="primary"
              fullWidth
            >
              Book Another Service
            </Button>
            
            <Button
              onClick={() => navigate('/')}
              variant="secondary"
              fullWidth
            >
              Back to Home
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="h-10 w-10 bg-blue-600 rounded-full flex items-center justify-center">
                <Car className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">Vehicle RMS</h1>
                <p className="text-sm text-gray-600">Professional Vehicle Repair Management</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Link to="/login" className="text-sm text-gray-500 hover:text-gray-700">
                Login to Account
              </Link>
              <Link to="/mechanic/signup" className="text-sm text-blue-600 hover:text-blue-700">
                Join as Mechanic
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {!showBookingForm ? (
          // Mechanic Selection View
          <div>
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Available Mechanics</h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                Select a verified mechanic to request vehicle repair service. All mechanics are approved by our admin team.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Available Mechanics List */}
              <div>
                <Card>
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-xl font-semibold text-gray-900">Choose Your Mechanic</h3>
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <div className="h-3 w-3 bg-green-500 rounded-full animate-pulse"></div>
                      <span>Online ({availableMechanics.length})</span>
                    </div>
                  </div>

                  {availableMechanics.length === 0 ? (
                    <div className="text-center py-12 text-gray-500">
                      <AlertTriangle className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                      <p className="text-lg font-medium">No mechanics available</p>
                      <p className="text-sm">Please try again later or contact emergency services</p>
                    </div>
                  ) : (
                    <div className="space-y-4 max-h-96 overflow-y-auto">
                      {availableMechanics.map((mechanic) => (
                        <div
                          key={mechanic.id}
                          className="border-2 border-gray-200 rounded-xl p-6 hover:border-blue-300 hover:shadow-lg transition-all cursor-pointer"
                          onClick={() => handleMechanicSelect(mechanic)}
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-3 mb-3">
                                <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center">
                                  <Car className="h-6 w-6 text-blue-600" />
                                </div>
                                <div>
                                  <h4 className="text-lg font-bold text-gray-900">{mechanic.businessName}</h4>
                                  <p className="text-sm text-gray-600">{mechanic.username}</p>
                                  <div className="flex items-center space-x-1 mt-1">
                                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                                    <span className="text-sm font-medium text-gray-700">4.8</span>
                                    <span className="text-xs text-gray-500">(127 reviews)</span>
                                  </div>
                                </div>
                              </div>
                              
                              <div className="grid grid-cols-3 gap-4 mb-4 text-sm">
                                <div className="flex items-center text-gray-600">
                                  <MapPin className="h-4 w-4 mr-2 text-blue-500" />
                                  <span className="font-medium">{calculateDistance(mechanic).toFixed(1)} km</span>
                                </div>
                                <div className="flex items-center text-gray-600">
                                  <Clock className="h-4 w-4 mr-2 text-green-500" />
                                  <span className="font-medium">~{getEstimatedArrival(mechanic)} min</span>
                                </div>
                                <div className="flex items-center text-gray-600">
                                  <Phone className="h-4 w-4 mr-2 text-purple-500" />
                                  <span className="font-medium">{mechanic.phone}</span>
                                </div>
                              </div>
                              
                              <div className="mb-4">
                                <p className="text-sm font-medium text-gray-700 mb-2">Specializations:</p>
                                <div className="flex flex-wrap gap-2">
                                  {mechanic.specialties.slice(0, 4).map((specialty) => (
                                    <span
                                      key={specialty}
                                      className="px-3 py-1 bg-green-100 text-green-700 text-sm rounded-full font-medium"
                                    >
                                      {specialty}
                                    </span>
                                  ))}
                                  {mechanic.specialties.length > 4 && (
                                    <span className="px-3 py-1 bg-gray-100 text-gray-600 text-sm rounded-full">
                                      +{mechanic.specialties.length - 4} more
                                    </span>
                                  )}
                                </div>
                              </div>

                              <div className="flex items-center justify-between">
                                <div className="text-sm text-gray-600">
                                  <span className="font-medium">Base Rate:</span> Le 75,000/hour
                                </div>
                                <div className="flex items-center space-x-2">
                                  <div className="h-3 w-3 bg-green-500 rounded-full animate-pulse"></div>
                                  <span className="text-sm font-medium text-green-600">Available Now</span>
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          <div className="mt-4 pt-4 border-t border-gray-200">
                            <Button
                              onClick={() => handleMechanicSelect(mechanic)}
                              variant="primary"
                              fullWidth
                              icon={CheckCircle}
                            >
                              Select {mechanic.businessName}
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </Card>
              </div>

              {/* Google Maps View */}
              <div>
                <Card padding="none">
                  <div className="p-4 border-b">
                    <h3 className="text-lg font-semibold text-gray-900">Mechanics Near You</h3>
                    <p className="text-sm text-gray-600">Live satellite view of available mechanics</p>
                  </div>
                  
                  <GoogleMapView
                    currentLocation={currentLocation}
                    height="600px"
                    showNearbyMechanics={true}
                    nearbyMechanics={availableMechanics}
                    zoom={13}
                    className="rounded-b-lg overflow-hidden"
                  />
                </Card>
              </div>
            </div>
          </div>
        ) : (
          // Booking Form View
          <div className="max-w-4xl mx-auto">
            <Card>
              <div className="flex items-center space-x-3 mb-6">
                <Button
                  onClick={() => {
                    setShowBookingForm(false);
                    setSelectedMechanic(null);
                  }}
                  variant="secondary"
                  size="sm"
                  icon={ArrowLeft}
                >
                  Change Mechanic
                </Button>
                <h2 className="text-2xl font-bold text-gray-900">Complete Your Booking</h2>
              </div>

              {/* Selected Mechanic Summary */}
              {selectedMechanic && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-8">
                  <h3 className="text-lg font-bold text-blue-900 mb-3">Selected Mechanic</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-blue-800"><span className="font-semibold">{selectedMechanic.businessName}</span></p>
                      <p className="text-blue-700">{selectedMechanic.username} • {selectedMechanic.phone}</p>
                      <p className="text-blue-700">Distance: {calculateDistance(selectedMechanic).toFixed(1)} km • ETA: ~{getEstimatedArrival(selectedMechanic)} min</p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {selectedMechanic.specialties.slice(0, 3).map((specialty) => (
                        <span key={specialty} className="px-2 py-1 bg-blue-200 text-blue-800 text-xs rounded-full font-medium">
                          {specialty}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default DirectMechanicBooking;