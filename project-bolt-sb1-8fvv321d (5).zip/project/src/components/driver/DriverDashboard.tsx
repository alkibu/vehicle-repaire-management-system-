import React, { useState, useEffect } from 'react';
import { MapPin, Phone, Clock, Car, AlertTriangle, Search, Camera, Navigation, Users, Upload, X, Mic, MicOff, Play, Pause, User, FileText, Calendar, Download } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useLocation } from '../../context/LocationContext';
import { ServiceRequest, Mechanic } from '../../types';
import Card from '../ui/Card';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Modal from '../ui/Modal';
import Header from '../ui/Header';
import GoogleMapView from '../maps/GoogleMapView';
import NotificationSystem from '../notifications/NotificationSystem';
import PaymentModal from '../payment/PaymentModal';
import ProfileModal from '../profile/ProfileModal';
import ActivityReportModal from '../reports/ActivityReportModal';

const DriverDashboard: React.FC = () => {
  const { user, extendSession } = useAuth();
  const { currentLocation, requestLocation, locationError, watchLocation, stopWatching } = useLocation();
  const [mechanics, setMechanics] = useState<Mechanic[]>([]);
  const [currentRequest, setCurrentRequest] = useState<ServiceRequest | null>(null);
  const [assignedMechanic, setAssignedMechanic] = useState<Mechanic | null>(null);
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [selectedMechanic, setSelectedMechanic] = useState<Mechanic | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedJobForPayment, setSelectedJobForPayment] = useState<ServiceRequest | null>(null);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [completedJobs, setCompletedJobs] = useState<ServiceRequest[]>([]);
  const [paymentHistory, setPaymentHistory] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string>('');
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [requestForm, setRequestForm] = useState({
    vehicleType: '',
    vehicleMake: '',
    vehicleModel: '',
    vehicleYear: '',
    problemDescription: '',
    urgencyLevel: 'medium',
    photos: [] as string[],
    additionalNotes: '',
    audioExplanation: '',
  });

  const vehicleTypes = ['Sedan', 'SUV', 'Truck', 'Van', 'Motorcycle', 'Bus'];
  const urgencyLevels = [
    { value: 'low', label: 'Low - Can wait', color: 'green' },
    { value: 'medium', label: 'Medium - Soon as possible', color: 'yellow' },
    { value: 'high', label: 'High - Urgent', color: 'orange' },
    { value: 'emergency', label: 'Emergency - Immediate', color: 'red' },
  ];

  useEffect(() => {
    if (currentLocation) {
      watchLocation();
    }
    return () => stopWatching();
  }, [currentLocation]);

  useEffect(() => {
    loadData();
    const interval = setInterval(() => {
      loadData();
      extendSession();
    }, 5000);
    return () => clearInterval(interval);
  }, [user]);

  useEffect(() => {
    if (currentLocation && user) {
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const updatedUsers = users.map((u: any) => 
        u.id === user.id ? { ...u, currentLocation } : u
      );
      localStorage.setItem('users', JSON.stringify(updatedUsers));
    }
  }, [currentLocation, user]);

  const loadData = () => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const approvedMechanics = users.filter((u: any) => u.role === 'mechanic' && u.isApproved && u.isOnline);
    setMechanics(approvedMechanics);

    const requests = JSON.parse(localStorage.getItem('serviceRequests') || '[]');
    const userRequest = requests.find((r: ServiceRequest) => r.driverId === user?.id && !['completed', 'rejected'].includes(r.status));
    setCurrentRequest(userRequest || null);

    // Load completed jobs ready for payment
    const completedUserJobs = requests.filter((r: ServiceRequest) => 
      r.driverId === user?.id && r.status === 'completed' && !r.isPaid
    );
    setCompletedJobs(completedUserJobs);

    // Load payment history
    const payments = JSON.parse(localStorage.getItem('payments') || '[]');
    const userPayments = payments.filter((p: any) => p.driverId === user?.id);
    setPaymentHistory(userPayments);

    if (userRequest && userRequest.mechanicId) {
      const mechanic = users.find((u: any) => u.id === userRequest.mechanicId);
      setAssignedMechanic(mechanic || null);
    } else {
      setAssignedMechanic(null);
    }

    // Check for new notifications
    checkForNotifications();
  };

  const checkForNotifications = () => {
    const requests = JSON.parse(localStorage.getItem('serviceRequests') || '[]');
    const userRequests = requests.filter((r: ServiceRequest) => r.driverId === user?.id);
    
    userRequests.forEach((request: ServiceRequest) => {
      if (request.status === 'rejected' && request.rejectionReason && !request.notificationSent) {
        addNotification({
          type: 'rejection',
          title: 'Request Rejected',
          message: `Your service request was rejected. Reason: ${request.rejectionReason}`,
          timestamp: new Date().toISOString(),
        });
        
        // Mark notification as sent
        const updatedRequests = requests.map((r: ServiceRequest) =>
          r.id === request.id ? { ...r, notificationSent: true } : r
        );
        localStorage.setItem('serviceRequests', JSON.stringify(updatedRequests));
      }
      
      if (request.status === 'completed' && !request.completionNotificationSent) {
        addNotification({
          type: 'completion',
          title: 'Job Completed',
          message: `Your vehicle repair is complete and ready for payment!`,
          timestamp: new Date().toISOString(),
        });
        
        // Mark completion notification as sent
        const updatedRequests = requests.map((r: ServiceRequest) =>
          r.id === request.id ? { ...r, completionNotificationSent: true } : r
        );
        localStorage.setItem('serviceRequests', JSON.stringify(updatedRequests));
      }
    });
  };

  const addNotification = (notification: any) => {
    setNotifications(prev => [notification, ...prev.slice(0, 4)]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n !== notification));
    }, 5000);
  };

  const handleRequestAssistance = () => {
    if (!currentLocation) {
      requestLocation();
      return;
    }
    setShowRequestModal(true);
  };

  const handleMechanicSelect = (mechanic: Mechanic) => {
    setSelectedMechanic(mechanic);
  };

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      const newPhotos: string[] = [];
      Array.from(files).forEach((file) => {
        const reader = new FileReader();
        reader.onload = (e) => {
          if (e.target?.result) {
            newPhotos.push(e.target.result as string);
            if (newPhotos.length === files.length) {
              setRequestForm(prev => ({
                ...prev,
                photos: [...prev.photos, ...newPhotos].slice(0, 5) // Max 5 photos
              }));
            }
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const removePhoto = (index: number) => {
    setRequestForm(prev => ({
      ...prev,
      photos: prev.photos.filter((_, i) => i !== index)
    }));
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks: BlobPart[] = [];

      recorder.ondataavailable = (e) => chunks.push(e.data);
      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/wav' });
        setAudioBlob(blob);
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
        setRequestForm(prev => ({ ...prev, audioExplanation: url }));
      };

      recorder.start();
      setMediaRecorder(recorder);
      setIsRecording(true);
    } catch (error) {
      console.error('Error starting recording:', error);
      alert('Could not access microphone. Please check permissions.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorder && isRecording) {
      mediaRecorder.stop();
      mediaRecorder.stream.getTracks().forEach(track => track.stop());
      setIsRecording(false);
    }
  };

  const playAudio = () => {
    if (audioUrl) {
      const audio = new Audio(audioUrl);
      audio.play();
      setIsPlaying(true);
      audio.onended = () => setIsPlaying(false);
    }
  };

  const removeAudio = () => {
    setAudioBlob(null);
    setAudioUrl('');
    setRequestForm(prev => ({ ...prev, audioExplanation: '' }));
  };

  const handleSubmitRequest = () => {
    if (!selectedMechanic || !currentLocation) return;

    const newRequest: ServiceRequest = {
      id: Date.now().toString(),
      driverId: user!.id,
      mechanicId: selectedMechanic.id,
      vehicleType: requestForm.vehicleType,
      vehicleMake: requestForm.vehicleMake,
      vehicleModel: requestForm.vehicleModel,
      vehicleYear: requestForm.vehicleYear,
      problemDescription: requestForm.problemDescription,
      urgencyLevel: requestForm.urgencyLevel as 'low' | 'medium' | 'high' | 'emergency',
      breakdownLocation: {
        lat: currentLocation.lat,
        lng: currentLocation.lng,
        address: `${currentLocation.lat.toFixed(6)}, ${currentLocation.lng.toFixed(6)}`,
      },
      photos: requestForm.photos,
      additionalNotes: requestForm.additionalNotes,
      audioExplanation: requestForm.audioExplanation,
      status: 'pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      estimatedCost: calculateEstimatedCost(),
    };

    const requests = JSON.parse(localStorage.getItem('serviceRequests') || '[]');
    requests.push(newRequest);
    localStorage.setItem('serviceRequests', JSON.stringify(requests));

    setCurrentRequest(newRequest);
    setShowRequestModal(false);
    setRequestForm({
      vehicleType: '',
      vehicleMake: '',
      vehicleModel: '',
      vehicleYear: '',
      problemDescription: '',
      urgencyLevel: 'medium',
      photos: [],
      additionalNotes: '',
      audioExplanation: '',
    });
    setSelectedMechanic(null);
    setAudioBlob(null);
    setAudioUrl('');
    
    addNotification({
      type: 'success',
      title: 'Request Sent',
      message: `Your service request has been sent to ${selectedMechanic.businessName}`,
      timestamp: new Date().toISOString(),
    });
    
    extendSession();
  };

  const calculateEstimatedCost = () => {
    let baseCost = 50000; // Base service cost in Sierra Leone Leones
    
    // Adjust based on urgency
    switch (requestForm.urgencyLevel) {
      case 'high': baseCost *= 1.3; break;
      case 'emergency': baseCost *= 1.5; break;
    }
    
    // Adjust based on vehicle type
    switch (requestForm.vehicleType) {
      case 'Truck': baseCost *= 1.4; break;
      case 'Bus': baseCost *= 1.5; break;
      case 'SUV': baseCost *= 1.2; break;
    }
    
    // Add platform fees (17% total: 15% commission + 2% processing)
    const totalWithFees = baseCost * 1.17;
    return Math.round(totalWithFees);
  };

  const handlePayment = (job: ServiceRequest) => {
    setSelectedJobForPayment(job);
    setShowPaymentModal(true);
  };

  const handlePaymentSuccess = (paymentData: any) => {
    // Update job as paid
    const requests = JSON.parse(localStorage.getItem('serviceRequests') || '[]');
    const updatedRequests = requests.map((r: ServiceRequest) =>
      r.id === selectedJobForPayment?.id ? { ...r, isPaid: true, paidAt: new Date().toISOString() } : r
    );
    localStorage.setItem('serviceRequests', JSON.stringify(updatedRequests));

    // Save payment record
    const payments = JSON.parse(localStorage.getItem('payments') || '[]');
    payments.push({
      id: Date.now().toString(),
      driverId: user?.id,
      mechanicId: selectedJobForPayment?.mechanicId,
      jobId: selectedJobForPayment?.id,
      totalAmount: paymentData.totalAmount,
      mechanicAmount: paymentData.mechanicAmount,
      adminCommission: paymentData.adminCommission,
      processingFee: paymentData.processingFee,
      method: paymentData.method,
      transactionId: paymentData.transactionId,
      timestamp: new Date().toISOString(),
      status: 'completed',
    });
    localStorage.setItem('payments', JSON.stringify(payments));

    // Update mechanic balance (only mechanic portion)
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const updatedUsers = users.map((u: any) => {
      if (u.id === selectedJobForPayment?.mechanicId) {
        return { ...u, balance: (u.balance || 0) + paymentData.mechanicAmount };
      }
      return u;
    });
    localStorage.setItem('users', JSON.stringify(updatedUsers));

    // Update admin revenue
    const adminRevenue = JSON.parse(localStorage.getItem('adminRevenue') || '[]');
    adminRevenue.push({
      id: Date.now().toString(),
      transactionId: paymentData.transactionId,
      jobId: selectedJobForPayment?.id,
      commission: paymentData.adminCommission,
      processingFee: paymentData.processingFee,
      totalEarnings: paymentData.adminCommission + paymentData.processingFee,
      timestamp: new Date().toISOString(),
    });
    localStorage.setItem('adminRevenue', JSON.stringify(adminRevenue));
    setShowPaymentModal(false);
    setSelectedJobForPayment(null);
    loadData();

    addNotification({
      type: 'success',
      title: 'Payment Successful',
      message: `Payment of Le ${paymentData.totalAmount.toLocaleString()} completed successfully`,
      timestamp: new Date().toISOString(),
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-600 bg-yellow-100';
      case 'accepted': return 'text-blue-600 bg-blue-100';
      case 'en_route': return 'text-purple-600 bg-purple-100';
      case 'on_site': return 'text-green-600 bg-green-100';
      case 'completed': return 'text-gray-600 bg-gray-100';
      case 'rejected': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'Waiting for mechanic response';
      case 'accepted': return 'Mechanic accepted your request';
      case 'en_route': return 'Mechanic is on the way';
      case 'on_site': return 'Mechanic has arrived';
      case 'completed': return 'Service completed';
      case 'rejected': return 'Request rejected';
      default: return status;
    }
  };

  const getUrgencyColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-green-600 bg-green-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'high': return 'text-orange-600 bg-orange-100';
      case 'emergency': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const calculateDistance = (mechanic: Mechanic) => {
    if (!currentLocation || !mechanic.currentLocation) return 'Unknown';
    
    const lat1 = currentLocation.lat;
    const lng1 = currentLocation.lng;
    const lat2 = mechanic.currentLocation.lat;
    const lng2 = mechanic.currentLocation.lng;
    
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c;
    
    return `${distance.toFixed(1)} km`;
  };

  const getEstimatedArrival = (mechanic: Mechanic) => {
    if (!currentLocation || !mechanic.currentLocation) return 'Unknown';
    
    const distance = parseFloat(calculateDistance(mechanic).replace(' km', ''));
    const estimatedMinutes = Math.round(distance * 2);
    
    return `~${estimatedMinutes} min`;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <NotificationSystem notifications={notifications} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Actions */}
        <div className="mb-8">
          <Card>
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">Quick Actions</h2>
              <div className="flex space-x-3">
                <Button
                  onClick={() => setShowProfileModal(true)}
                  variant="secondary"
                  size="sm"
                  icon={User}
                >
                  Edit Profile
                </Button>
                <Button
                  onClick={() => setShowReportModal(true)}
                  variant="secondary"
                  size="sm"
                  icon={FileText}
                >
                  Activity Report
                </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* Jobs Ready for Payment */}
        {completedJobs.length > 0 && (
          <div className="mb-8">
            <Card>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-900">Jobs Ready for Payment</h2>
                <span className="px-3 py-1 bg-green-100 text-green-700 text-sm rounded-full">
                  {completedJobs.length} job{completedJobs.length !== 1 ? 's' : ''} completed
                </span>
              </div>
              
              <div className="space-y-4">
                {completedJobs.map((job) => (
                  <div key={job.id} className="border border-gray-200 rounded-lg p-4 bg-green-50">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">Vehicle Repair Completed</h3>
                        <div className="text-sm text-gray-600 mt-1">
                          <p><span className="font-medium">Vehicle:</span> {job.vehicleMake} {job.vehicleModel} ({job.vehicleType})</p>
                          <p><span className="font-medium">Problem:</span> {job.problemDescription}</p>
                          <p><span className="font-medium">Completed:</span> {new Date(job.updatedAt).toLocaleString()}</p>
                          <p><span className="font-medium">Amount:</span> Le {job.estimatedCost?.toLocaleString()}</p>
                        </div>
                      </div>
                      <Button
                        onClick={() => handlePayment(job)}
                        variant="success"
                        size="sm"
                      >
                        Pay Now
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Current Request Status */}
          {currentRequest && (
            <div className="lg:col-span-3">
              <Card className="mb-8">
                <div className="flex items-start justify-between mb-4">
                  <h2 className="text-lg font-semibold text-gray-900">Current Request</h2>
                  <div className="flex items-center space-x-2">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(currentRequest.status)}`}>
                      {getStatusText(currentRequest.status)}
                    </span>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getUrgencyColor(currentRequest.urgencyLevel || 'medium')}`}>
                      {currentRequest.urgencyLevel?.toUpperCase()}
                    </span>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-medium text-gray-900 mb-2">Request Details</h3>
                    <div className="space-y-2 text-sm text-gray-600">
                      <p><span className="font-medium">Vehicle:</span> {currentRequest.vehicleMake} {currentRequest.vehicleModel} ({currentRequest.vehicleType})</p>
                      {currentRequest.vehicleYear && <p><span className="font-medium">Year:</span> {currentRequest.vehicleYear}</p>}
                      <p><span className="font-medium">Problem:</span> {currentRequest.problemDescription}</p>
                      <p><span className="font-medium">Location:</span> {currentRequest.breakdownLocation.address}</p>
                      <p><span className="font-medium">Estimated Cost:</span> Le {currentRequest.estimatedCost?.toLocaleString()}</p>
                      <p><span className="font-medium">Requested:</span> {new Date(currentRequest.createdAt).toLocaleString()}</p>
                      {currentRequest.additionalNotes && (
                        <p><span className="font-medium">Notes:</span> {currentRequest.additionalNotes}</p>
                      )}
                      {assignedMechanic && (
                        <>
                          <p><span className="font-medium">Mechanic:</span> {assignedMechanic.businessName}</p>
                          <p><span className="font-medium">Contact:</span> {assignedMechanic.phone}</p>
                          {assignedMechanic.currentLocation && currentLocation && (
                            <>
                              <p><span className="font-medium">Distance:</span> {calculateDistance(assignedMechanic)}</p>
                              <p><span className="font-medium">ETA:</span> {getEstimatedArrival(assignedMechanic)}</p>
                            </>
                          )}
                        </>
                      )}
                    </div>

                    {/* Photos */}
                    {currentRequest.photos && currentRequest.photos.length > 0 && (
                      <div className="mt-4">
                        <h4 className="font-medium text-gray-900 mb-2">Photos</h4>
                        <div className="grid grid-cols-3 gap-2">
                          {currentRequest.photos.map((photo, index) => (
                            <img
                              key={index}
                              src={photo}
                              alt={`Problem photo ${index + 1}`}
                              className="w-full h-20 object-cover rounded-lg border"
                            />
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Audio Explanation */}
                    {currentRequest.audioExplanation && (
                      <div className="mt-4">
                        <h4 className="font-medium text-gray-900 mb-2">Audio Explanation</h4>
                        <div className="flex items-center space-x-2">
                          <Button
                            onClick={() => {
                              const audio = new Audio(currentRequest.audioExplanation);
                              audio.play();
                            }}
                            variant="secondary"
                            size="sm"
                            icon={Play}
                          >
                            Play Audio
                          </Button>
                          <span className="text-sm text-gray-500">Audio explanation provided</span>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <div>
                    <h3 className="font-medium text-gray-900 mb-2">Live Tracking</h3>
                    <GoogleMapView
                      currentLocation={currentLocation}
                      targetLocation={assignedMechanic?.currentLocation ? {
                        lat: assignedMechanic.currentLocation.lat,
                        lng: assignedMechanic.currentLocation.lng,
                        accuracy: 10,
                        timestamp: Date.now()
                      } : undefined}
                      showRoute={currentRequest.status === 'en_route'}
                      height="200px"
                      showBothLocations={true}
                      driverLocation={currentRequest.breakdownLocation}
                      mechanicLocation={assignedMechanic?.currentLocation}
                      zoom={16}
                    />
                    {assignedMechanic?.currentLocation && (
                      <div className="mt-2 text-xs text-gray-500">
                        <p>🔵 Your location • 🔴 Mechanic location</p>
                        <p>Last updated: {new Date().toLocaleTimeString()}</p>
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            </div>
          )}

          {/* Available Mechanics */}
          <div className="lg:col-span-2">
            <Card>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-900">Available Mechanics</h2>
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                  <span>Online ({mechanics.length})</span>
                </div>
              </div>

              {locationError && (
                <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                  {locationError}
                </div>
              )}

              {!currentRequest && (
                <div className="mb-4">
                  <Button
                    onClick={handleRequestAssistance}
                    variant="primary"
                    fullWidth
                    icon={AlertTriangle}
                    disabled={!currentLocation}
                  >
                    {currentLocation ? 'Request Assistance' : 'Enable Location to Request Help'}
                  </Button>
                </div>
              )}

              <div className="space-y-4">
                {mechanics.map((mechanic) => (
                  <div
                    key={mechanic.id}
                    className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                    onClick={() => !currentRequest && handleMechanicSelect(mechanic)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">{mechanic.businessName}</h3>
                        <p className="text-sm text-gray-600">{mechanic.username}</p>
                        <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                          <span className="flex items-center">
                            <MapPin className="h-4 w-4 mr-1" />
                            {calculateDistance(mechanic)}
                          </span>
                          <span className="flex items-center">
                            <Clock className="h-4 w-4 mr-1" />
                            {getEstimatedArrival(mechanic)}
                          </span>
                          <span className="flex items-center">
                            <Car className="h-4 w-4 mr-1" />
                            Available
                          </span>
                        </div>
                        <div className="mt-2">
                          <div className="flex flex-wrap gap-1">
                            {mechanic.specialties.slice(0, 3).map((specialty) => (
                              <span
                                key={specialty}
                                className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full"
                              >
                                {specialty}
                              </span>
                            ))}
                            {mechanic.specialties.length > 3 && (
                              <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">
                                +{mechanic.specialties.length - 3} more
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-col items-end space-y-1">
                        <div className="flex items-center space-x-2">
                          <div className="h-3 w-3 bg-green-500 rounded-full animate-pulse"></div>
                          <span className="text-sm text-green-600">Online</span>
                        </div>
                        {mechanic.currentLocation && (
                          <div className="text-xs text-gray-500">
                            GPS: {mechanic.currentLocation.lat.toFixed(4)}, {mechanic.currentLocation.lng.toFixed(4)}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}

                {mechanics.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Search className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                    <p>No mechanics available at the moment</p>
                    <p className="text-sm">Please try again later</p>
                  </div>
                )}
              </div>
            </Card>
          </div>

          {/* Current Location & Stats */}
          <div className="lg:col-span-1">
            <Card>
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Your Location</h2>
              
              {currentLocation ? (
                <div>
                  <GoogleMapView
                    currentLocation={currentLocation}
                    height="200px"
                    className="mb-4"
                    showNearbyMechanics={true}
                    nearbyMechanics={mechanics}
                    zoom={14}
                  />
                  <div className="text-sm text-gray-600 space-y-1">
                    <p><span className="font-medium">Coordinates:</span></p>
                    <p>{currentLocation.lat.toFixed(6)}, {currentLocation.lng.toFixed(6)}</p>
                    <p><span className="font-medium">Accuracy:</span> ±{Math.round(currentLocation.accuracy)}m</p>
                    <p><span className="font-medium">Last Update:</span> {new Date(currentLocation.timestamp).toLocaleTimeString()}</p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <MapPin className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                  <p className="text-gray-500 mb-3">Location not available</p>
                  <Button onClick={requestLocation} size="sm" variant="secondary">
                    Enable Location
                  </Button>
                </div>
              )}
            </Card>

            {/* Payment History */}
            {paymentHistory.length > 0 && (
              <Card className="mt-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Payment History</h2>
                <div className="space-y-3 max-h-60 overflow-y-auto">
                  {paymentHistory.slice(0, 5).map((payment) => (
                    <div key={payment.id} className="border-b border-gray-100 pb-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="text-sm font-medium text-gray-900">Le {payment.totalAmount.toLocaleString()}</p>
                          <p className="text-xs text-gray-500">{payment.method}</p>
                          <p className="text-xs text-gray-500">{new Date(payment.timestamp).toLocaleDateString()}</p>
                        </div>
                        <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
                          Paid
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {/* Quick Stats */}
            <Card className="mt-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Stats</h2>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Requests</span>
                  <span className="font-medium">{paymentHistory.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Completed</span>
                  <span className="font-medium">{paymentHistory.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Spent</span>
                  <span className="font-medium">Le {paymentHistory.reduce((sum, p) => sum + (p.totalAmount || 0), 0).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">GPS Status</span>
                  <span className={`font-medium ${currentLocation ? 'text-green-600' : 'text-red-600'}`}>
                    {currentLocation ? 'Active' : 'Inactive'}
                  </span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>

      {/* Enhanced Request Modal */}
      <Modal
        isOpen={showRequestModal}
        onClose={() => setShowRequestModal(false)}
        title="Request Vehicle Assistance"
        size="xl"
      >
        <div className="space-y-6">
          {selectedMechanic ? (
            <div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <h3 className="font-medium text-blue-900 mb-2">Selected Mechanic</h3>
                <div className="text-sm text-blue-800">
                  <p><span className="font-medium">{selectedMechanic.businessName}</span></p>
                  <p>{selectedMechanic.username} • {selectedMechanic.phone}</p>
                  <p>Distance: {calculateDistance(selectedMechanic)} • ETA: {getEstimatedArrival(selectedMechanic)}</p>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {selectedMechanic.specialties.map((specialty) => (
                      <span key={specialty} className="px-2 py-1 bg-blue-200 text-blue-800 text-xs rounded-full">
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Vehicle Type <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={requestForm.vehicleType}
                    onChange={(e) => setRequestForm(prev => ({ ...prev, vehicleType: e.target.value }))}
                    className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    required
                  >
                    <option value="">Select vehicle type</option>
                    {vehicleTypes.map((type) => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Urgency Level <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={requestForm.urgencyLevel}
                    onChange={(e) => setRequestForm(prev => ({ ...prev, urgencyLevel: e.target.value }))}
                    className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    {urgencyLevels.map((level) => (
                      <option key={level.value} value={level.value}>{level.label}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Input
                  label="Vehicle Make"
                  value={requestForm.vehicleMake}
                  onChange={(value) => setRequestForm(prev => ({ ...prev, vehicleMake: value }))}
                  placeholder="e.g., Toyota, Honda"
                />
                <Input
                  label="Vehicle Model"
                  value={requestForm.vehicleModel}
                  onChange={(value) => setRequestForm(prev => ({ ...prev, vehicleModel: value }))}
                  placeholder="e.g., Camry, Civic"
                />
                <Input
                  label="Year"
                  value={requestForm.vehicleYear}
                  onChange={(value) => setRequestForm(prev => ({ ...prev, vehicleYear: value }))}
                  placeholder="e.g., 2020"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Problem Description <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={requestForm.problemDescription}
                  onChange={(e) => setRequestForm(prev => ({ ...prev, problemDescription: e.target.value }))}
                  placeholder="Describe the problem with your vehicle in detail..."
                  rows={4}
                  className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Additional Notes
                </label>
                <textarea
                  value={requestForm.additionalNotes}
                  onChange={(e) => setRequestForm(prev => ({ ...prev, additionalNotes: e.target.value }))}
                  placeholder="Any additional information that might help the mechanic..."
                  rows={2}
                  className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Photos (Optional - Max 5)
                </label>
                <div className="space-y-4">
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                    <input
                      type="file"
                      multiple
                      accept="image/*"
                      onChange={handlePhotoUpload}
                      className="hidden"
                      id="photo-upload"
                    />
                    <label htmlFor="photo-upload" className="cursor-pointer">
                      <Upload className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                      <p className="text-sm text-gray-600">Click to upload photos of the problem</p>
                      <p className="text-xs text-gray-500 mt-1">Maximum 5 photos, 5MB each</p>
                    </label>
                  </div>
                  
                  {requestForm.photos.length > 0 && (
                    <div className="grid grid-cols-3 gap-2">
                      {requestForm.photos.map((photo, index) => (
                        <div key={index} className="relative">
                          <img
                            src={photo}
                            alt={`Upload ${index + 1}`}
                            className="w-full h-20 object-cover rounded-lg border"
                          />
                          <button
                            type="button"
                            onClick={() => removePhoto(index)}
                            className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Audio Explanation (Optional)
                </label>
                <div className="space-y-4">
                  {!audioUrl ? (
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                      <Mic className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                      <p className="text-sm text-gray-600 mb-3">Record an audio explanation of the problem</p>
                      <Button
                        onClick={isRecording ? stopRecording : startRecording}
                        variant={isRecording ? 'danger' : 'primary'}
                        size="sm"
                        icon={isRecording ? MicOff : Mic}
                      >
                        {isRecording ? 'Stop Recording' : 'Start Recording'}
                      </Button>
                      {isRecording && (
                        <div className="mt-2 flex items-center justify-center space-x-2">
                          <div className="h-2 w-2 bg-red-500 rounded-full animate-pulse"></div>
                          <span className="text-sm text-red-600">Recording...</span>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="border border-gray-300 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center">
                            <Mic className="h-5 w-5 text-blue-600" />
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-900">Audio Explanation</p>
                            <p className="text-xs text-gray-500">Ready to send</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button
                            onClick={playAudio}
                            variant="secondary"
                            size="sm"
                            icon={isPlaying ? Pause : Play}
                          >
                            {isPlaying ? 'Pause' : 'Play'}
                          </Button>
                          <Button
                            onClick={removeAudio}
                            variant="danger"
                            size="sm"
                            icon={X}
                          >
                            Remove
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 mb-2">Estimated Cost</h4>
                <p className="text-2xl font-bold text-green-600">Le {calculateEstimatedCost().toLocaleString()}</p>
                <p className="text-sm text-gray-500">Final cost may vary based on actual work required. Platform fee (17%) included.</p>
              </div>

              <div className="flex space-x-3">
                <Button
                  onClick={() => setSelectedMechanic(null)}
                  variant="secondary"
                  fullWidth
                >
                  Change Mechanic
                </Button>
                <Button
                  onClick={handleSubmitRequest}
                  variant="primary"
                  fullWidth
                  disabled={!requestForm.vehicleType || !requestForm.problemDescription}
                >
                  Send Request (Le {calculateEstimatedCost().toLocaleString()})
                </Button>
              </div>
            </div>
          ) : (
            <div>
              <p className="text-gray-600 mb-4">Select a mechanic to send your assistance request:</p>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {mechanics.map((mechanic) => (
                  <div
                    key={mechanic.id}
                    className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                    onClick={() => setSelectedMechanic(mechanic)}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-medium text-gray-900">{mechanic.businessName}</h3>
                        <p className="text-sm text-gray-600">{mechanic.username}</p>
                        <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                          <span>{calculateDistance(mechanic)}</span>
                          <span>{getEstimatedArrival(mechanic)}</span>
                          <span>{mechanic.phone}</span>
                        </div>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {mechanic.specialties.slice(0, 3).map((specialty) => (
                            <span key={specialty} className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full">
                              {specialty}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="h-3 w-3 bg-green-500 rounded-full animate-pulse"></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </Modal>

      {/* Payment Modal */}
      {showPaymentModal && selectedJobForPayment && (
        <PaymentModal
          isOpen={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          job={selectedJobForPayment}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}

      {/* Profile Modal */}
      {showProfileModal && (
        <ProfileModal
          isOpen={showProfileModal}
          onClose={() => setShowProfileModal(false)}
          user={user}
          onProfileUpdate={loadData}
        />
      )}

      {/* Activity Report Modal */}
      {showReportModal && (
        <ActivityReportModal
          isOpen={showReportModal}
          onClose={() => setShowReportModal(false)}
          userRole="driver"
          userId={user?.id}
        />
      )}
    </div>
  );
};

export default DriverDashboard;