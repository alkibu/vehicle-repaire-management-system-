import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { MapPin, Phone, MessageSquare, Clock, CheckCircle, AlertCircle, DollarSign, Star, Navigation, Car, Wrench, CreditCard } from 'lucide-react';
import Card from '../ui/Card';
import Button from '../ui/Button';
import Modal from '../ui/Modal';
import PaymentModal from '../payment/PaymentModal';
import { apiService } from '../../services/api';

interface TrackingData {
  id: string;
  trackingId: string;
  status: 'pending' | 'accepted' | 'en_route' | 'arrived' | 'working' | 'completed' | 'rejected';
  mechanic: {
    id: string;
    name: string;
    businessName: string;
    phone: string;
    photo: string;
    rating: number;
    specializations: string[];
  };
  driver: {
    phone: string;
    email: string;
    vehicleType: string;
    vehicleMake: string;
    vehicleModel: string;
    problemDescription: string;
    urgencyLevel: string;
    photos: string[];
    audioExplanation?: string;
  };
  location: {
    driver: { lat: number; lng: number };
    mechanic?: { lat: number; lng: number };
  };
  estimatedCost: number;
  estimatedArrival?: string;
  distance?: string;
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
  rejectionReason?: string;
  statusHistory: Array<{
    status: string;
    timestamp: string;
    message: string;
  }>;
}

const DriverTrackingDashboard: React.FC = () => {
  const { trackingId } = useParams<{ trackingId: string }>();
  const navigate = useNavigate();
  const [trackingData, setTrackingData] = useState<TrackingData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());

  useEffect(() => {
    if (trackingId) {
      loadTrackingData();
    }
  }, [trackingId]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (autoRefresh && trackingData && !['completed', 'rejected'].includes(trackingData.status)) {
      interval = setInterval(() => {
        loadTrackingData(false);
      }, 15000); // Refresh every 15 seconds
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [autoRefresh, trackingData]);

  const loadTrackingData = async (showLoading = true) => {
    if (!trackingId) return;

    try {
      if (showLoading) setLoading(true);
      setError(null);

      // Get tracking data from backend API
      const response = await apiService.getTrackingData(trackingId);
      
      // Transform API response to match component interface
      const transformedData: TrackingData = {
        id: response.id,
        trackingId: response.trackingId,
        status: response.status,
        mechanic: {
          id: response.mechanic.id,
          name: response.mechanic.name,
          businessName: response.mechanic.businessName,
          phone: response.mechanic.phone,
          photo: response.mechanic.photo,
          rating: response.mechanic.rating,
          specializations: response.mechanic.specializations
        },
        driver: {
          phone: response.driver.phone,
          email: response.driver.email,
          vehicleType: response.driver.vehicleType,
          vehicleMake: response.driver.vehicleMake,
          vehicleModel: response.driver.vehicleModel,
          problemDescription: response.driver.problemDescription,
          urgencyLevel: response.driver.urgencyLevel,
          photos: response.driver.photos || []
        },
        location: response.location,
        estimatedCost: response.estimatedCost,
        estimatedArrival: response.estimatedArrival,
        distance: response.distance,
        createdAt: response.createdAt,
        updatedAt: response.updatedAt,
        completedAt: response.completedAt,
        rejectionReason: response.rejectionReason,
        statusHistory: response.statusHistory
      };
      
      setTrackingData(transformedData);
      setLastUpdate(new Date());
    } catch (err: any) {
      setError(err.message || 'Failed to load tracking data');
    } finally {
      if (showLoading) setLoading(false);
    }
  };

  const handlePayment = () => {
    setShowPaymentModal(true);
  };

  const handlePaymentSuccess = (paymentData: any) => {
    setShowPaymentModal(false);
    // Refresh tracking data to show payment completed
    loadTrackingData();
  };

  const getStatusInfo = (status: string) => {
    const statusMap = {
      pending: { 
        color: 'text-yellow-600', 
        bg: 'bg-yellow-100', 
        icon: Clock, 
        text: 'Waiting for mechanic response',
        description: 'Your request has been sent to the mechanic. They will respond shortly.'
      },
      accepted: { 
        color: 'text-blue-600', 
        bg: 'bg-blue-100', 
        icon: CheckCircle, 
        text: 'Mechanic confirmed your request',
        description: 'Great! Your mechanic has accepted the job and will be with you soon.'
      },
      en_route: { 
        color: 'text-indigo-600', 
        bg: 'bg-indigo-100', 
        icon: Navigation, 
        text: 'Mechanic is traveling to your location',
        description: 'Your mechanic is on the way. You can track their live location below.'
      },
      arrived: { 
        color: 'text-green-600', 
        bg: 'bg-green-100', 
        icon: MapPin, 
        text: 'Mechanic has arrived at your location',
        description: 'Your mechanic has reached your location and will start the inspection.'
      },
      working: { 
        color: 'text-orange-600', 
        bg: 'bg-orange-100', 
        icon: Wrench, 
        text: 'Repair work is in progress',
        description: 'Your mechanic is actively working on your vehicle. Please wait nearby.'
      },
      completed: { 
        color: 'text-green-600', 
        bg: 'bg-green-100', 
        icon: CheckCircle, 
        text: 'Service has been completed',
        description: 'Excellent! Your vehicle repair is complete. Please make payment to finish.'
      },
      rejected: { 
        color: 'text-red-600', 
        bg: 'bg-red-100', 
        icon: AlertCircle, 
        text: 'Request was rejected',
        description: 'Unfortunately, this mechanic cannot help you right now. Try booking another mechanic.'
      }
    };
    return statusMap[status as keyof typeof statusMap] || statusMap.pending;
  };

  const getUrgencyColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-green-600 bg-green-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'high': return 'text-orange-600 bg-orange-100';
      case 'emergency': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your tracking dashboard...</p>
        </div>
      </div>
    );
  }

  if (error || !trackingData) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center max-w-md">
          <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Unable to Load Tracking Data</h2>
          <p className="text-gray-600 mb-4">{error || 'Tracking ID not found'}</p>
          <Button onClick={() => navigate('/driver-booking')} variant="primary">
            Book Another Mechanic
          </Button>
        </div>
      </div>
    );
  }

  const statusInfo = getStatusInfo(trackingData.status);
  const StatusIcon = statusInfo.icon;
  const canMakePayment = trackingData.status === 'completed';

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Track Your Service</h1>
              <p className="text-gray-600">Tracking ID: {trackingData.trackingId}</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="autoRefresh"
                  checked={autoRefresh}
                  onChange={(e) => setAutoRefresh(e.target.checked)}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor="autoRefresh" className="text-sm text-gray-600">
                  Auto-refresh
                </label>
              </div>
              <Button onClick={() => loadTrackingData()} variant="secondary" size="sm">
                Refresh Now
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Current Status */}
            <Card>
              <div className="flex items-center space-x-4 mb-6">
                <div className={`p-3 rounded-full ${statusInfo.bg}`}>
                  <StatusIcon className={`h-8 w-8 ${statusInfo.color}`} />
                </div>
                <div className="flex-1">
                  <h2 className="text-xl font-semibold text-gray-900 capitalize">
                    {trackingData.status.replace('_', ' ')}
                  </h2>
                  <p className="text-gray-600">{statusInfo.text}</p>
                  <p className="text-sm text-gray-500 mt-1">{statusInfo.description}</p>
                </div>
                {canMakePayment && (
                  <Button
                    onClick={handlePayment}
                    variant="success"
                    icon={CreditCard}
                  >
                    Make Payment
                  </Button>
                )}
              </div>

              {/* Status-specific content */}
              {trackingData.status === 'en_route' && trackingData.estimatedArrival && (
                <div className="bg-blue-50 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-blue-900">Estimated Arrival</p>
                      <p className="text-2xl font-bold text-blue-600">{trackingData.estimatedArrival}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-blue-900">Distance</p>
                      <p className="text-xl font-semibold text-blue-600">{trackingData.distance}</p>
                    </div>
                  </div>
                </div>
              )}

              {trackingData.status === 'rejected' && trackingData.rejectionReason && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <h3 className="font-medium text-red-900 mb-2">Rejection Reason</h3>
                  <p className="text-red-800 italic">"{trackingData.rejectionReason}"</p>
                  <div className="mt-4">
                    <Button
                      onClick={() => navigate('/driver-booking')}
                      variant="primary"
                      icon={Car}
                    >
                      Find Another Mechanic
                    </Button>
                  </div>
                </div>
              )}

              {canMakePayment && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium text-green-900">Service Completed!</h3>
                      <p className="text-green-800">Your vehicle repair is finished. Please make payment to complete the service.</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-green-700">Total Amount</p>
                      <p className="text-2xl font-bold text-green-600">Le {trackingData.estimatedCost.toLocaleString()}</p>
                    </div>
                  </div>
                </div>
              )}
            </Card>

            {/* Progress Timeline */}
            <Card>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Service Progress</h3>
              <div className="space-y-4">
                {[
                  { key: 'pending', label: 'Request Sent', icon: Clock },
                  { key: 'accepted', label: 'Request Accepted', icon: CheckCircle },
                  { key: 'en_route', label: 'Mechanic En Route', icon: Navigation },
                  { key: 'arrived', label: 'Mechanic Arrived', icon: MapPin },
                  { key: 'working', label: 'Repair Started', icon: Wrench },
                  { key: 'completed', label: 'Service Completed', icon: CheckCircle }
                ].map((step, index) => {
                  const isCompleted = trackingData.statusHistory.some(h => h.status === step.key);
                  const isCurrent = step.key === trackingData.status;
                  const StepIcon = step.icon;
                  
                  return (
                    <div key={step.key} className="flex items-center space-x-4">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        isCompleted ? 'bg-green-500 text-white' : 
                        isCurrent ? 'bg-blue-500 text-white' : 'bg-gray-300 text-gray-500'
                      }`}>
                        <StepIcon className="h-4 w-4" />
                      </div>
                      <div className="flex-1">
                        <p className={`font-medium ${
                          isCompleted || isCurrent ? 'text-gray-900' : 'text-gray-500'
                        }`}>
                          {step.label}
                        </p>
                        {trackingData.statusHistory.find(h => h.status === step.key) && (
                          <p className="text-sm text-gray-500">
                            {new Date(trackingData.statusHistory.find(h => h.status === step.key)!.timestamp).toLocaleString()}
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>

            {/* Service Details */}
            <Card>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Service Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium text-gray-900 mb-3">Vehicle Information</h4>
                  <div className="space-y-2 text-sm text-gray-600">
                    <p><span className="font-medium">Type:</span> {trackingData.driver.vehicleType}</p>
                    <p><span className="font-medium">Make:</span> {trackingData.driver.vehicleMake}</p>
                    <p><span className="font-medium">Model:</span> {trackingData.driver.vehicleModel}</p>
                    <p><span className="font-medium">Problem:</span> {trackingData.driver.problemDescription}</p>
                    <p><span className="font-medium">Urgency:</span> 
                      <span className={`ml-2 px-2 py-1 rounded-full text-xs font-medium ${getUrgencyColor(trackingData.driver.urgencyLevel)}`}>
                        {trackingData.driver.urgencyLevel.toUpperCase()}
                      </span>
                    </p>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium text-gray-900 mb-3">Cost Information</h4>
                  <div className="space-y-2 text-sm text-gray-600">
                    <p><span className="font-medium">Estimated Cost:</span> Le {trackingData.estimatedCost.toLocaleString()}</p>
                    <p><span className="font-medium">Requested:</span> {new Date(trackingData.createdAt).toLocaleString()}</p>
                    {trackingData.completedAt && (
                      <p><span className="font-medium">Completed:</span> {new Date(trackingData.completedAt).toLocaleString()}</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Photos */}
              {trackingData.driver.photos && trackingData.driver.photos.length > 0 && (
                <div className="mt-6">
                  <h4 className="font-medium text-gray-900 mb-3">Problem Photos</h4>
                  <div className="grid grid-cols-3 gap-3">
                    {trackingData.driver.photos.map((photo, index) => (
                      <img
                        key={index}
                        src={photo}
                        alt={`Problem photo ${index + 1}`}
                        className="w-full h-24 object-cover rounded-lg border cursor-pointer hover:opacity-75"
                        onClick={() => window.open(photo, '_blank')}
                      />
                    ))}
                  </div>
                </div>
              )}
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Mechanic Profile */}
            <Card>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Your Mechanic</h3>
              <div className="text-center">
                <img
                  src={trackingData.mechanic.photo}
                  alt={trackingData.mechanic.name}
                  className="w-20 h-20 rounded-full mx-auto mb-3 object-cover"
                />
                <h4 className="font-semibold text-gray-900">{trackingData.mechanic.name}</h4>
                <p className="text-gray-600 text-sm">{trackingData.mechanic.businessName}</p>
                <div className="flex items-center justify-center mt-2">
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className={`h-4 w-4 ${i < Math.floor(trackingData.mechanic.rating) ? 'fill-current' : ''}`} />
                    ))}
                  </div>
                  <span className="ml-2 text-sm text-gray-600">
                    {trackingData.mechanic.rating}/5
                  </span>
                </div>
                
                <div className="mt-3">
                  <div className="flex flex-wrap gap-1 justify-center">
                    {trackingData.mechanic.specializations.slice(0, 3).map((spec) => (
                      <span key={spec} className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">
                        {spec}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </Card>

            {/* Communication */}
            <Card>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact Mechanic</h3>
              <div className="space-y-3">
                <Button
                  onClick={() => window.open(`tel:${trackingData.mechanic.phone}`)}
                  variant="success"
                  fullWidth
                  icon={Phone}
                >
                  Call {trackingData.mechanic.name}
                </Button>
                <Button
                  onClick={() => window.open(`sms:${trackingData.mechanic.phone}`)}
                  variant="primary"
                  fullWidth
                  icon={MessageSquare}
                >
                  Send SMS
                </Button>
              </div>
            </Card>

            {/* Last Update */}
            <Card>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">System Status</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Auto-refresh</span>
                  <span className={`font-medium ${autoRefresh ? 'text-green-600' : 'text-gray-600'}`}>
                    {autoRefresh ? 'ON' : 'OFF'}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Last Update</span>
                  <span className="font-medium text-gray-900">
                    {lastUpdate.toLocaleTimeString()}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Status</span>
                  <span className="font-medium text-green-600">Connected</span>
                </div>
              </div>
            </Card>

            {/* Emergency Contact */}
            <div className="bg-red-50 rounded-lg p-4">
              <h4 className="font-semibold text-red-900 mb-2">Emergency Contact</h4>
              <p className="text-sm text-red-700 mb-3">
                If you need immediate assistance, call our emergency hotline.
              </p>
              <Button
                onClick={() => window.open('tel:+23299999999')}
                variant="danger"
                fullWidth
                size="sm"
              >
                Call Emergency: +232 99 999 999
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Payment Modal */}
      {showPaymentModal && trackingData && (
        <PaymentModal
          isOpen={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          job={{
            id: trackingData.id,
            estimatedCost: trackingData.estimatedCost,
            vehicleMake: trackingData.driver.vehicleMake,
            vehicleModel: trackingData.driver.vehicleModel,
            problemDescription: trackingData.driver.problemDescription,
          } as any}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}
    </div>
  );
};

export default DriverTrackingDashboard;