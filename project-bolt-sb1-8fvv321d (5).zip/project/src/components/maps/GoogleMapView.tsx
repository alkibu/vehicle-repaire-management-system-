import React, { useEffect, useRef, useState } from 'react';
import { Loader } from '@googlemaps/js-api-loader';
import { MapPin, Navigation, Car, Wrench, Satellite, Map as MapIcon, Layers } from 'lucide-react';
import { LocationData, Mechanic, Driver } from '../../types';
import Card from '../ui/Card';
import Button from '../ui/Button';

interface GoogleMapViewProps {
  currentLocation?: LocationData | null;
  targetLocation?: LocationData | null;
  showRoute?: boolean;
  height?: string;
  className?: string;
  showBothLocations?: boolean;
  driverLocation?: { lat: number; lng: number } | null;
  mechanicLocation?: { lat: number; lng: number } | null;
  showNearbyMechanics?: boolean;
  nearbyMechanics?: Mechanic[];
  showNearbyDrivers?: boolean;
  nearbyDrivers?: Driver[];
  zoom?: number;
}

const GoogleMapView: React.FC<GoogleMapViewProps> = ({
  currentLocation,
  targetLocation,
  showRoute = false,
  height = '400px',
  className = '',
  showBothLocations = false,
  driverLocation,
  mechanicLocation,
  showNearbyMechanics = false,
  nearbyMechanics = [],
  showNearbyDrivers = false,
  nearbyDrivers = [],
  zoom = 15,
}) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const [map, setMap] = useState<google.maps.Map | null>(null);
  const [mapType, setMapType] = useState<'roadmap' | 'satellite' | 'hybrid'>('satellite');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);
  const directionsRendererRef = useRef<google.maps.DirectionsRenderer | null>(null);

  // Google Maps API Key - In production, this should be in environment variables
  const GOOGLE_MAPS_API_KEY = 'YOUR_GOOGLE_MAPS_API_KEY'; // Replace with your actual API key

  useEffect(() => {
    initializeMap();
    return () => {
      // Cleanup markers and directions
      clearMarkers();
      if (directionsRendererRef.current) {
        directionsRendererRef.current.setMap(null);
      }
    };
  }, []);

  useEffect(() => {
    if (map) {
      updateMapContent();
    }
  }, [
    map,
    currentLocation,
    targetLocation,
    driverLocation,
    mechanicLocation,
    nearbyMechanics,
    nearbyDrivers,
    showRoute,
    showBothLocations,
    showNearbyMechanics,
    showNearbyDrivers,
  ]);

  const initializeMap = async () => {
    if (!mapRef.current) return;

    try {
      setIsLoading(true);
      setError(null);

      // For demo purposes, we'll show a fallback if no API key
      if (!GOOGLE_MAPS_API_KEY || GOOGLE_MAPS_API_KEY === 'YOUR_GOOGLE_MAPS_API_KEY') {
        setError('Google Maps API key not configured. Showing demo map.');
        setIsLoading(false);
        return;
      }

      const loader = new Loader({
        apiKey: GOOGLE_MAPS_API_KEY,
        version: 'weekly',
        libraries: ['places', 'geometry'],
      });

      const google = await loader.load();
      
      // Default to Freetown, Sierra Leone if no location
      const defaultCenter = currentLocation 
        ? { lat: currentLocation.lat, lng: currentLocation.lng }
        : { lat: 8.4657, lng: -13.2317 }; // Freetown coordinates

      const mapInstance = new google.maps.Map(mapRef.current, {
        center: defaultCenter,
        zoom: zoom,
        mapTypeId: mapType,
        mapTypeControl: true,
        mapTypeControlOptions: {
          style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
          position: google.maps.ControlPosition.TOP_CENTER,
        },
        zoomControl: true,
        streetViewControl: true,
        fullscreenControl: true,
        styles: [
          {
            featureType: 'poi',
            elementType: 'labels',
            stylers: [{ visibility: 'on' }],
          },
        ],
      });

      setMap(mapInstance);
      setIsLoading(false);
    } catch (err) {
      console.error('Error loading Google Maps:', err);
      setError('Failed to load Google Maps. Please check your internet connection.');
      setIsLoading(false);
    }
  };

  const clearMarkers = () => {
    markersRef.current.forEach(marker => marker.setMap(null));
    markersRef.current = [];
  };

  const addMarker = (
    position: { lat: number; lng: number },
    title: string,
    icon: string,
    color: string = '#4285F4'
  ) => {
    if (!map) return;

    const marker = new google.maps.Marker({
      position,
      map,
      title,
      icon: {
        path: google.maps.SymbolPath.CIRCLE,
        scale: 8,
        fillColor: color,
        fillOpacity: 1,
        strokeColor: '#ffffff',
        strokeWeight: 2,
      },
    });

    // Add info window
    const infoWindow = new google.maps.InfoWindow({
      content: `<div style="padding: 8px;"><strong>${title}</strong></div>`,
    });

    marker.addListener('click', () => {
      infoWindow.open(map, marker);
    });

    markersRef.current.push(marker);
    return marker;
  };

  const showDirections = (origin: { lat: number; lng: number }, destination: { lat: number; lng: number }) => {
    if (!map) return;

    const directionsService = new google.maps.DirectionsService();
    
    if (!directionsRendererRef.current) {
      directionsRendererRef.current = new google.maps.DirectionsRenderer({
        suppressMarkers: false,
        polylineOptions: {
          strokeColor: '#4285F4',
          strokeWeight: 4,
          strokeOpacity: 0.8,
        },
      });
    }

    directionsRendererRef.current.setMap(map);

    directionsService.route(
      {
        origin,
        destination,
        travelMode: google.maps.TravelMode.DRIVING,
      },
      (result, status) => {
        if (status === 'OK' && result) {
          directionsRendererRef.current?.setDirections(result);
        } else {
          console.error('Directions request failed:', status);
        }
      }
    );
  };

  const updateMapContent = () => {
    if (!map) return;

    clearMarkers();
    if (directionsRendererRef.current) {
      directionsRendererRef.current.setMap(null);
    }

    // Add current location marker
    if (currentLocation) {
      addMarker(
        { lat: currentLocation.lat, lng: currentLocation.lng },
        'Your Location',
        'current',
        '#4285F4'
      );
    }

    // Add driver location marker
    if (showBothLocations && driverLocation) {
      addMarker(
        driverLocation,
        'Driver Location',
        'driver',
        '#1E40AF'
      );
    }

    // Add mechanic location marker
    if (showBothLocations && mechanicLocation) {
      addMarker(
        mechanicLocation,
        'Mechanic Location',
        'mechanic',
        '#DC2626'
      );
    }

    // Add target location marker
    if (targetLocation && !showBothLocations) {
      addMarker(
        { lat: targetLocation.lat, lng: targetLocation.lng },
        'Target Location',
        'target',
        '#DC2626'
      );
    }

    // Add nearby mechanics
    if (showNearbyMechanics && nearbyMechanics) {
      nearbyMechanics.forEach((mechanic) => {
        if (mechanic.currentLocation) {
          addMarker(
            mechanic.currentLocation,
            `${mechanic.businessName} (Mechanic)`,
            'mechanic',
            '#059669'
          );
        }
      });
    }

    // Add nearby drivers
    if (showNearbyDrivers && nearbyDrivers) {
      nearbyDrivers.forEach((driver) => {
        if (driver.currentLocation) {
          addMarker(
            driver.currentLocation,
            `${driver.username} (Driver)`,
            'driver',
            '#2563EB'
          );
        }
      });
    }

    // Show route if requested
    if (showRoute && currentLocation && (targetLocation || mechanicLocation || driverLocation)) {
      const destination = targetLocation || mechanicLocation || driverLocation;
      if (destination) {
        showDirections(
          { lat: currentLocation.lat, lng: currentLocation.lng },
          destination
        );
      }
    }

    // Fit bounds to show all markers
    if (markersRef.current.length > 1) {
      const bounds = new google.maps.LatLngBounds();
      markersRef.current.forEach(marker => {
        const position = marker.getPosition();
        if (position) bounds.extend(position);
      });
      map.fitBounds(bounds);
    }
  };

  const changeMapType = (type: 'roadmap' | 'satellite' | 'hybrid') => {
    setMapType(type);
    if (map) {
      map.setMapTypeId(type);
    }
  };

  const renderFallbackMap = () => {
    return (
      <div className="relative bg-gradient-to-br from-blue-100 to-green-100 rounded-lg overflow-hidden" style={{ height }}>
        <div className="absolute inset-0 bg-gradient-to-br from-blue-100 to-green-100">
          {/* Grid pattern to simulate map */}
          <div className="absolute inset-0 opacity-20">
            <svg width="100%" height="100%">
              <defs>
                <pattern id="grid" width="50" height="50" patternUnits="userSpaceOnUse">
                  <path d="M 50 0 L 0 0 0 50" fill="none" stroke="#94a3b8" strokeWidth="1"/>
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>
          </div>

          {/* Location markers */}
          {currentLocation && (
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <div className="bg-blue-500 rounded-full p-2 shadow-lg animate-pulse">
                <MapPin className="h-6 w-6 text-white" />
              </div>
              <div className="absolute top-12 left-1/2 transform -translate-x-1/2 bg-white px-2 py-1 rounded shadow text-xs whitespace-nowrap">
                Your Location
              </div>
            </div>
          )}

          {/* Demo message */}
          <div className="absolute top-4 left-4 bg-yellow-100 border border-yellow-300 rounded-lg p-3">
            <p className="text-yellow-800 text-sm font-medium">Demo Mode</p>
            <p className="text-yellow-700 text-xs">Configure Google Maps API for live maps</p>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className={className}>
      <div className="relative">
        {/* Map Type Controls */}
        <div className="absolute top-4 right-4 z-10 flex space-x-2">
          <Button
            onClick={() => changeMapType('satellite')}
            variant={mapType === 'satellite' ? 'primary' : 'secondary'}
            size="sm"
            icon={Satellite}
            className="!p-2"
          />
          <Button
            onClick={() => changeMapType('hybrid')}
            variant={mapType === 'hybrid' ? 'primary' : 'secondary'}
            size="sm"
            icon={Layers}
            className="!p-2"
          />
          <Button
            onClick={() => changeMapType('roadmap')}
            variant={mapType === 'roadmap' ? 'primary' : 'secondary'}
            size="sm"
            icon={MapIcon}
            className="!p-2"
          />
        </div>

        {/* Loading State */}
        {isLoading && (
          <div className="flex items-center justify-center bg-gray-100 rounded-lg" style={{ height }}>
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <p className="text-gray-600">Loading Google Maps...</p>
            </div>
          </div>
        )}

        {/* Error State or Fallback */}
        {(error || !map) && !isLoading && renderFallbackMap()}

        {/* Google Map Container */}
        <div
          ref={mapRef}
          style={{ height }}
          className={`w-full rounded-lg ${isLoading || error ? 'hidden' : ''}`}
        />

        {/* Live tracking indicator */}
        {showBothLocations && (
          <div className="absolute top-4 left-4 bg-green-500 text-white px-3 py-1 rounded-full text-xs font-medium animate-pulse">
            🛰️ Live GPS Tracking
          </div>
        )}
      </div>

      {/* Location Info */}
      <div className="mt-4">
        <Card padding="sm" className="bg-white/90 backdrop-blur-sm">
          <div className="text-sm space-y-1">
            {currentLocation && (
              <p className="text-gray-600">
                <span className="font-medium">Current:</span> {currentLocation.lat.toFixed(4)}, {currentLocation.lng.toFixed(4)}
              </p>
            )}
            {targetLocation && !showBothLocations && (
              <p className="text-gray-600">
                <span className="font-medium">Target:</span> {targetLocation.lat.toFixed(4)}, {targetLocation.lng.toFixed(4)}
              </p>
            )}
            {showBothLocations && driverLocation && (
              <p className="text-gray-600">
                <span className="font-medium">Driver:</span> {driverLocation.lat.toFixed(4)}, {driverLocation.lng.toFixed(4)}
              </p>
            )}
            {showBothLocations && mechanicLocation && (
              <p className="text-gray-600">
                <span className="font-medium">Mechanic:</span> {mechanicLocation.lat.toFixed(4)}, {mechanicLocation.lng.toFixed(4)}
              </p>
            )}
            {showNearbyMechanics && nearbyMechanics.length > 0 && (
              <p className="text-gray-600">
                <span className="font-medium">Mechanics:</span> {nearbyMechanics.length} online
              </p>
            )}
            {showNearbyDrivers && nearbyDrivers.length > 0 && (
              <p className="text-gray-600">
                <span className="font-medium">Drivers:</span> {nearbyDrivers.length} in area
              </p>
            )}
            <div className="flex justify-between items-center">
              <div className="text-xs text-gray-500">
                {currentLocation?.accuracy && `±${Math.round(currentLocation.accuracy)}m`}
              </div>
              <div className="text-xs text-gray-500">
                Updated: {new Date().toLocaleTimeString()}
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default GoogleMapView;