import React, { useEffect, useRef } from 'react';
import { MapPin, Navigation, Car, Wrench } from 'lucide-react';
import { LocationData, Mechanic, Driver } from '../../types';
import Card from '../ui/Card';

interface MapViewProps {
  currentLocation?: LocationData | null;
  targetLocation?: LocationData | null;
  showRoute?: boolean;
  height?: string;
  className?: string;
  showBothLocations?: boolean;
  driverLocation?: { lat: number; lng: number } | null;
  mechanicLocation?: { lat: number; lng: number } | null;
  showNearbyMechanics?: boolean;
  nearbyMechanics?: Mechanic[];
  showNearbyDrivers?: boolean;
  nearbyDrivers?: Driver[];
}

const MapView: React.FC<MapViewProps> = ({
  currentLocation,
  targetLocation,
  showRoute = false,
  height = '400px',
  className = '',
  showBothLocations = false,
  driverLocation,
  mechanicLocation,
  showNearbyMechanics = false,
  nearbyMechanics = [],
  showNearbyDrivers = false,
  nearbyDrivers = [],
}) => {
  const mapRef = useRef<HTMLDivElement>(null);

  // Enhanced map placeholder with multiple location support
  const renderMapPlaceholder = () => {
    return (
      <div className="relative bg-gray-100 rounded-lg overflow-hidden\" style={{ height }}>
        <div className="absolute inset-0 bg-gradient-to-br from-blue-100 to-green-100">
          {/* Grid pattern to simulate map */}
          <div className="absolute inset-0 opacity-20">
            <svg width="100%" height="100%">
              <defs>
                <pattern id="grid" width="50" height="50" patternUnits="userSpaceOnUse">
                  <path d="M 50 0 L 0 0 0 50" fill="none" stroke="#94a3b8" strokeWidth="1"/>
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>
          </div>

          {/* Current location marker (primary user) */}
          {currentLocation && (
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <div className="bg-blue-500 rounded-full p-2 shadow-lg animate-pulse">
                <MapPin className="h-6 w-6 text-white" />
              </div>
              <div className="absolute top-12 left-1/2 transform -translate-x-1/2 bg-white px-2 py-1 rounded shadow text-xs whitespace-nowrap">
                Your Location
              </div>
            </div>
          )}

          {/* Driver location marker (for mechanics viewing) */}
          {showBothLocations && driverLocation && (
            <div className="absolute top-1/3 left-1/3 transform -translate-x-1/2 -translate-y-1/2">
              <div className="bg-blue-600 rounded-full p-2 shadow-lg">
                <Car className="h-5 w-5 text-white" />
              </div>
              <div className="absolute top-10 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white px-2 py-1 rounded shadow text-xs whitespace-nowrap">
                Driver
              </div>
            </div>
          )}

          {/* Mechanic location marker (for drivers viewing) */}
          {showBothLocations && mechanicLocation && (
            <div className="absolute top-2/3 right-1/3 transform translate-x-1/2 translate-y-1/2">
              <div className="bg-red-500 rounded-full p-2 shadow-lg animate-pulse">
                <Wrench className="h-5 w-5 text-white" />
              </div>
              <div className="absolute top-10 left-1/2 transform -translate-x-1/2 bg-red-500 text-white px-2 py-1 rounded shadow text-xs whitespace-nowrap">
                Mechanic
              </div>
            </div>
          )}

          {/* Target location marker (single target) */}
          {targetLocation && !showBothLocations && (
            <div className="absolute top-1/3 right-1/3 transform translate-x-1/2">
              <div className="bg-red-500 rounded-full p-2 shadow-lg animate-pulse">
                <MapPin className="h-6 w-6 text-white" />
              </div>
              <div className="absolute top-12 left-1/2 transform -translate-x-1/2 bg-white px-2 py-1 rounded shadow text-xs whitespace-nowrap">
                Target Location
              </div>
            </div>
          )}

          {/* Nearby mechanics markers */}
          {showNearbyMechanics && nearbyMechanics.map((mechanic, index) => (
            <div
              key={mechanic.id}
              className="absolute"
              style={{
                top: `${30 + (index * 15) % 40}%`,
                left: `${20 + (index * 20) % 60}%`,
              }}
            >
              <div className="bg-green-500 rounded-full p-1 shadow-md">
                <Wrench className="h-4 w-4 text-white" />
              </div>
              <div className="absolute top-8 left-1/2 transform -translate-x-1/2 bg-green-500 text-white px-1 py-0.5 rounded text-xs whitespace-nowrap">
                {mechanic.businessName.substring(0, 10)}...
              </div>
            </div>
          ))}

          {/* Nearby drivers markers */}
          {showNearbyDrivers && nearbyDrivers.map((driver, index) => (
            <div
              key={driver.id}
              className="absolute"
              style={{
                top: `${25 + (index * 18) % 50}%`,
                left: `${15 + (index * 25) % 70}%`,
              }}
            >
              <div className="bg-blue-500 rounded-full p-1 shadow-md">
                <Car className="h-4 w-4 text-white" />
              </div>
              <div className="absolute top-8 left-1/2 transform -translate-x-1/2 bg-blue-500 text-white px-1 py-0.5 rounded text-xs whitespace-nowrap">
                {driver.username}
              </div>
            </div>
          ))}

          {/* Route line */}
          {showRoute && currentLocation && (targetLocation || driverLocation) && (
            <svg className="absolute inset-0 w-full h-full">
              <path
                d="M 50% 50% Q 60% 30% 66% 33%"
                stroke="#3b82f6"
                strokeWidth="3"
                strokeDasharray="10,5"
                fill="none"
                className="animate-pulse"
              />
            </svg>
          )}

          {/* Live tracking indicator */}
          {showBothLocations && (
            <div className="absolute top-4 left-4 bg-green-500 text-white px-2 py-1 rounded-full text-xs font-medium animate-pulse">
              Live Tracking
            </div>
          )}
        </div>

        {/* Map controls */}
        <div className="absolute top-4 right-4 flex flex-col space-y-2">
          <button className="bg-white p-2 rounded-lg shadow hover:shadow-md transition-shadow">
            <Navigation className="h-5 w-5 text-gray-600" />
          </button>
        </div>

        {/* Location info */}
        <div className="absolute bottom-4 left-4 right-4">
          <Card padding="sm" className="bg-white/90 backdrop-blur-sm">
            <div className="text-sm space-y-1">
              {currentLocation && (
                <p className="text-gray-600">
                  <span className="font-medium">Current:</span> {currentLocation.lat.toFixed(4)}, {currentLocation.lng.toFixed(4)}
                </p>
              )}
              {targetLocation && !showBothLocations && (
                <p className="text-gray-600">
                  <span className="font-medium">Target:</span> {targetLocation.lat.toFixed(4)}, {targetLocation.lng.toFixed(4)}
                </p>
              )}
              {showBothLocations && driverLocation && (
                <p className="text-gray-600">
                  <span className="font-medium">Driver:</span> {driverLocation.lat.toFixed(4)}, {driverLocation.lng.toFixed(4)}
                </p>
              )}
              {showBothLocations && mechanicLocation && (
                <p className="text-gray-600">
                  <span className="font-medium">Mechanic:</span> {mechanicLocation.lat.toFixed(4)}, {mechanicLocation.lng.toFixed(4)}
                </p>
              )}
              {showNearbyMechanics && nearbyMechanics.length > 0 && (
                <p className="text-gray-600">
                  <span className="font-medium">Mechanics:</span> {nearbyMechanics.length} online
                </p>
              )}
              {showNearbyDrivers && nearbyDrivers.length > 0 && (
                <p className="text-gray-600">
                  <span className="font-medium">Drivers:</span> {nearbyDrivers.length} in area
                </p>
              )}
              <div className="flex justify-between items-center">
                <div className="text-xs text-gray-500">
                  {currentLocation?.accuracy && `±${Math.round(currentLocation.accuracy)}m`}
                </div>
                <div className="text-xs text-gray-500">
                  Updated: {new Date().toLocaleTimeString()}
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    );
  };

  return (
    <div className={className}>
      {renderMapPlaceholder()}
    </div>
  );
};

export default MapView;