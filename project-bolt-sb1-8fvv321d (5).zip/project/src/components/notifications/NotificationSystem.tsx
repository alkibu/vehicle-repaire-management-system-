import React from 'react';
import { CheckCircle, XCircle, AlertTriangle, Info, DollarSign, MessageSquare } from 'lucide-react';

interface Notification {
  type: 'success' | 'error' | 'warning' | 'info' | 'payment' | 'rejection' | 'completion';
  title: string;
  message: string;
  timestamp: string;
}

interface NotificationSystemProps {
  notifications: Notification[];
}

const NotificationSystem: React.FC<NotificationSystemProps> = ({ notifications }) => {
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'success':
      case 'completion':
        return CheckCircle;
      case 'error':
      case 'rejection':
        return XCircle;
      case 'warning':
        return AlertTriangle;
      case 'payment':
        return DollarSign;
      default:
        return Info;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case 'success':
      case 'completion':
        return 'bg-green-500';
      case 'error':
      case 'rejection':
        return 'bg-red-500';
      case 'warning':
        return 'bg-orange-500';
      case 'payment':
        return 'bg-green-600';
      default:
        return 'bg-blue-500';
    }
  };

  const getBorderColor = (type: string) => {
    switch (type) {
      case 'success':
      case 'completion':
        return 'border-green-200';
      case 'error':
      case 'rejection':
        return 'border-red-200';
      case 'warning':
        return 'border-orange-200';
      case 'payment':
        return 'border-green-200';
      default:
        return 'border-blue-200';
    }
  };

  if (notifications.length === 0) return null;

  return (
    <div className="fixed top-4 right-4 z-50 space-y-2">
      {notifications.map((notification, index) => {
        const Icon = getNotificationIcon(notification.type);
        const iconColor = getNotificationColor(notification.type);
        const borderColor = getBorderColor(notification.type);

        return (
          <div
            key={index}
            className={`bg-white border-2 ${borderColor} rounded-lg shadow-lg p-4 max-w-sm animate-slide-in-right`}
            style={{
              animation: 'slideInRight 0.3s ease-out',
            }}
          >
            <div className="flex items-start space-x-3">
              <div className={`${iconColor} rounded-full p-1 flex-shrink-0`}>
                <Icon className="h-4 w-4 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-gray-900 text-sm">
                  {notification.title}
                </p>
                <p className="text-gray-600 text-sm mt-1">
                  {notification.message}
                </p>
                <p className="text-gray-400 text-xs mt-2">
                  {new Date(notification.timestamp).toLocaleTimeString()}
                </p>
              </div>
            </div>
          </div>
        );
      })}
      
      <style jsx>{`
        @keyframes slideInRight {
          from {
            transform: translateX(100%);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }
        
        .animate-slide-in-right {
          animation: slideInRight 0.3s ease-out;
        }
      `}</style>
    </div>
  );
};

export default NotificationSystem;