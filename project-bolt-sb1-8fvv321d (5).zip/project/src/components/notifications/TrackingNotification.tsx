import React, { useState, useEffect } from 'react';
import { MapPin, ExternalLink, X, Clock } from 'lucide-react';

interface TrackingNotificationProps {
  trackingId: string;
  isVisible: boolean;
  onClose: () => void;
  onNavigate: () => void;
}

const TrackingNotification: React.FC<TrackingNotificationProps> = ({
  trackingId,
  isVisible,
  onClose,
  onNavigate,
}) => {
  const [timeLeft, setTimeLeft] = useState(15);

  useEffect(() => {
    if (isVisible && timeLeft > 0) {
      const timer = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            onClose();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [isVisible, timeLeft, onClose]);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden animate-bounce-in">
        {/* Header */}
        <div className="bg-gradient-to-r from-green-500 to-emerald-600 text-white p-6 text-center relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-white/80 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
          
          <div className="h-16 w-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <MapPin className="h-8 w-8 text-white" />
          </div>
          
          <h2 className="text-xl font-bold mb-2">✅ Request Submitted Successfully!</h2>
          <p className="text-green-100">Your breakdown request has been sent to the mechanic</p>
        </div>

        {/* Content */}
        <div className="p-6">
          <div className="text-center mb-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
              <p className="text-sm font-medium text-blue-900 mb-2">Your Tracking ID</p>
              <p className="text-lg font-bold text-blue-600 font-mono">{trackingId}</p>
            </div>
            
            <p className="text-gray-600 mb-4">
              Click the button below to access your personal tracking dashboard where you can:
            </p>
            
            <div className="text-left space-y-2 mb-6">
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                <span>Track your mechanic's real-time location</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <div className="h-2 w-2 bg-blue-500 rounded-full"></div>
                <span>Monitor repair progress status</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <div className="h-2 w-2 bg-purple-500 rounded-full"></div>
                <span>Communicate directly with your mechanic</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <div className="h-2 w-2 bg-orange-500 rounded-full"></div>
                <span>Make payment when service is completed</span>
              </div>
            </div>
          </div>

          {/* Countdown Timer */}
          <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 mb-4 text-center">
            <div className="flex items-center justify-center space-x-2 text-orange-700">
              <Clock className="h-4 w-4" />
              <span className="text-sm font-medium">
                This notification will close in {timeLeft} seconds
              </span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            <button
              onClick={onNavigate}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold py-3 px-4 rounded-lg transition-all duration-200 flex items-center justify-center space-x-2"
            >
              <MapPin className="h-5 w-5" />
              <span>Go to My Tracking Dashboard</span>
              <ExternalLink className="h-4 w-4" />
            </button>
            
            <button
              onClick={onClose}
              className="w-full bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium py-2 px-4 rounded-lg transition-colors"
            >
              I'll track it later
            </button>
          </div>

          <div className="mt-4 text-center">
            <p className="text-xs text-gray-500">
              💡 Tip: Bookmark your tracking dashboard or save the tracking ID for easy access
            </p>
          </div>
        </div>
      </div>
      
      <style jsx>{`
        @keyframes bounce-in {
          0% {
            transform: scale(0.3) translateY(-50px);
            opacity: 0;
          }
          50% {
            transform: scale(1.05);
          }
          70% {
            transform: scale(0.9);
          }
          100% {
            transform: scale(1) translateY(0);
            opacity: 1;
          }
        }
        
        .animate-bounce-in {
          animation: bounce-in 0.6s ease-out;
        }
      `}</style>
    </div>
  );
};

export default TrackingNotification;