import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { MapPin, Phone, MessageSquare, Clock, CheckCircle, AlertCircle } from 'lucide-react';

interface TrackingData {
  id: string;
  status: 'pending' | 'accepted' | 'en-route' | 'arrived' | 'working' | 'completed';
  mechanic: {
    name: string;
    business: string;
    phone: string;
    photo: string;
    rating: number;
  };
  driver: {
    phone: string;
    email: string;
    vehicleType: string;
    problem: string;
  };
  location: {
    lat: number;
    lng: number;
  };
  estimatedArrival: string;
  distance: string;
  createdAt: string;
}

const TrackingPage: React.FC = () => {
  const { trackingId } = useParams<{ trackingId: string }>();
  const [trackingData, setTrackingData] = useState<TrackingData | null>(null);
  const [loading, setLoading] = useState(true);
  const [autoRefresh, setAutoRefresh] = useState(true);

  // Mock tracking data - replace with actual API call
  useEffect(() => {
    const mockData: TrackingData = {
      id: trackingId || 'VRM-2024-AB123',
      status: 'en-route',
      mechanic: {
        name: 'Mohamed Kamara',
        business: 'Kamara Auto Repair',
        phone: '+232 76 123 456',
        photo: 'https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
        rating: 4.8
      },
      driver: {
        phone: '+232 77 987 654',
        email: 'driver@example.com',
        vehicleType: 'Car',
        problem: 'Engine overheating, steam coming from hood'
      },
      location: {
        lat: 8.4657,
        lng: -13.2317
      },
      estimatedArrival: '15 minutes',
      distance: '2.3 km',
      createdAt: new Date().toISOString()
    };

    setTimeout(() => {
      setTrackingData(mockData);
      setLoading(false);
    }, 1000);
  }, [trackingId]);

  const getStatusInfo = (status: string) => {
    const statusMap = {
      pending: { color: 'text-yellow-600', bg: 'bg-yellow-100', icon: Clock, text: 'Waiting for mechanic response' },
      accepted: { color: 'text-blue-600', bg: 'bg-blue-100', icon: CheckCircle, text: 'Mechanic confirmed your request' },
      'en-route': { color: 'text-indigo-600', bg: 'bg-indigo-100', icon: MapPin, text: 'Mechanic is traveling to your location' },
      arrived: { color: 'text-green-600', bg: 'bg-green-100', icon: CheckCircle, text: 'Mechanic has arrived at your location' },
      working: { color: 'text-orange-600', bg: 'bg-orange-100', icon: AlertCircle, text: 'Repair work is in progress' },
      completed: { color: 'text-green-600', bg: 'bg-green-100', icon: CheckCircle, text: 'Service has been completed' }
    };
    return statusMap[status as keyof typeof statusMap] || statusMap.pending;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading tracking information...</p>
        </div>
      </div>
    );
  }

  if (!trackingData) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Tracking ID Not Found</h2>
          <p className="text-gray-600">Please check your tracking ID and try again.</p>
        </div>
      </div>
    );
  }

  const statusInfo = getStatusInfo(trackingData.status);
  const StatusIcon = statusInfo.icon;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Track Your Service</h1>
              <p className="text-gray-600">Tracking ID: {trackingData.id}</p>
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="autoRefresh"
                checked={autoRefresh}
                onChange={(e) => setAutoRefresh(e.target.checked)}
                className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <label htmlFor="autoRefresh" className="text-sm text-gray-600">
                Auto-refresh
              </label>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Status and Progress */}
          <div className="lg:col-span-2 space-y-6">
            {/* Current Status */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center space-x-3 mb-4">
                <div className={`p-2 rounded-full ${statusInfo.bg}`}>
                  <StatusIcon className={`h-6 w-6 ${statusInfo.color}`} />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 capitalize">
                    {trackingData.status.replace('-', ' ')}
                  </h3>
                  <p className="text-gray-600">{statusInfo.text}</p>
                </div>
              </div>

              {trackingData.status === 'en-route' && (
                <div className="bg-blue-50 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-blue-900">Estimated Arrival</p>
                      <p className="text-2xl font-bold text-blue-600">{trackingData.estimatedArrival}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-blue-900">Distance</p>
                      <p className="text-xl font-semibold text-blue-600">{trackingData.distance}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Progress Timeline */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Service Progress</h3>
              <div className="space-y-4">
                {[
                  { key: 'pending', label: 'Request Sent', time: '10:30 AM' },
                  { key: 'accepted', label: 'Request Accepted', time: '10:35 AM' },
                  { key: 'en-route', label: 'Mechanic En Route', time: '10:45 AM' },
                  { key: 'arrived', label: 'Mechanic Arrived', time: '' },
                  { key: 'working', label: 'Repair Started', time: '' },
                  { key: 'completed', label: 'Service Completed', time: '' }
                ].map((step, index) => {
                  const isCompleted = ['pending', 'accepted', 'en-route'].includes(step.key);
                  const isCurrent = step.key === trackingData.status;
                  
                  return (
                    <div key={step.key} className="flex items-center space-x-3">
                      <div className={`w-4 h-4 rounded-full ${
                        isCompleted ? 'bg-green-500' : 
                        isCurrent ? 'bg-blue-500' : 'bg-gray-300'
                      }`} />
                      <div className="flex-1">
                        <p className={`font-medium ${
                          isCompleted || isCurrent ? 'text-gray-900' : 'text-gray-500'
                        }`}>
                          {step.label}
                        </p>
                        {step.time && (
                          <p className="text-sm text-gray-500">{step.time}</p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Map Placeholder */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Live Location</h3>
              <div className="bg-gray-100 rounded-lg h-64 flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-500">Google Maps integration will show live location here</p>
                </div>
              </div>
            </div>
          </div>

          {/* Mechanic Info and Actions */}
          <div className="space-y-6">
            {/* Mechanic Profile */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Your Mechanic</h3>
              <div className="text-center">
                <img
                  src={trackingData.mechanic.photo}
                  alt={trackingData.mechanic.name}
                  className="w-20 h-20 rounded-full mx-auto mb-3 object-cover"
                />
                <h4 className="font-semibold text-gray-900">{trackingData.mechanic.name}</h4>
                <p className="text-gray-600 text-sm">{trackingData.mechanic.business}</p>
                <div className="flex items-center justify-center mt-2">
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className={i < Math.floor(trackingData.mechanic.rating) ? 'text-yellow-400' : 'text-gray-300'}>
                        ★
                      </span>
                    ))}
                  </div>
                  <span className="ml-2 text-sm text-gray-600">
                    {trackingData.mechanic.rating}/5
                  </span>
                </div>
              </div>
            </div>

            {/* Communication */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact Mechanic</h3>
              <div className="space-y-3">
                <button className="w-full flex items-center justify-center space-x-2 bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition-colors">
                  <Phone className="h-5 w-5" />
                  <span>Call {trackingData.mechanic.name}</span>
                </button>
                <button className="w-full flex items-center justify-center space-x-2 bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors">
                  <MessageSquare className="h-5 w-5" />
                  <span>Send SMS</span>
                </button>
              </div>
            </div>

            {/* Service Details */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Service Details</h3>
              <div className="space-y-3">
                <div>
                  <p className="text-sm font-medium text-gray-700">Vehicle Type</p>
                  <p className="text-gray-900">{trackingData.driver.vehicleType}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-700">Problem Description</p>
                  <p className="text-gray-900">{trackingData.driver.problem}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-700">Request Time</p>
                  <p className="text-gray-900">
                    {new Date(trackingData.createdAt).toLocaleString()}
                  </p>
                </div>
              </div>
            </div>

            {/* Emergency Contact */}
            <div className="bg-red-50 rounded-lg p-4">
              <h4 className="font-semibold text-red-900 mb-2">Emergency Contact</h4>
              <p className="text-sm text-red-700 mb-3">
                If you need immediate assistance, call our emergency hotline.
              </p>
              <button className="w-full bg-red-600 text-white py-2 px-4 rounded-lg hover:bg-red-700 transition-colors">
                Call Emergency: +232 99 999 999
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrackingPage;