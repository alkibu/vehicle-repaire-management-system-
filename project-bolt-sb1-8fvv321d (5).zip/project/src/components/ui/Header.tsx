import React, { useState, useEffect } from 'react';
import { LogOut, User, Clock, Shield, Car, Wrench } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import Button from './Button';

const Header: React.FC = () => {
  const { user, logout, sessionTimeout } = useAuth();
  const [timeLeft, setTimeLeft] = useState<string>('');

  useEffect(() => {
    if (sessionTimeout > 0) {
      const interval = setInterval(() => {
        const minutes = Math.floor(sessionTimeout / 60000);
        const seconds = Math.floor((sessionTimeout % 60000) / 1000);
        setTimeLeft(`${minutes}:${seconds.toString().padStart(2, '0')}`);
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [sessionTimeout]);

  const handleLogout = () => {
    const confirmLogout = window.confirm('Are you sure you want to logout?');
    if (confirmLogout) {
      logout();
    }
  };

  const getRoleIcon = () => {
    switch (user?.role) {
      case 'admin':
        return Shield;
      case 'mechanic':
        return Wrench;
      case 'driver':
        return Car;
      default:
        return User;
    }
  };

  const getRoleColor = () => {
    switch (user?.role) {
      case 'admin':
        return 'purple';
      case 'mechanic':
        return 'green';
      case 'driver':
        return 'blue';
      default:
        return 'gray';
    }
  };

  if (!user) return null;

  const RoleIcon = getRoleIcon();
  const roleColor = getRoleColor();

  return (
    <div className="bg-white shadow-sm border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className={`h-10 w-10 bg-${roleColor}-100 rounded-full flex items-center justify-center`}>
              <RoleIcon className={`h-6 w-6 text-${roleColor}-600`} />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-gray-900">
                {user.role.charAt(0).toUpperCase() + user.role.slice(1)} Dashboard
              </h1>
              <p className="text-sm text-gray-600">Welcome back, {user.username}</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Session Timer */}
            {sessionTimeout > 0 && (
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Clock className="h-4 w-4" />
                <span>Session: {timeLeft}</span>
              </div>
            )}
            
            {/* User Info */}
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <User className="h-4 w-4" />
              <span>{user.email}</span>
            </div>
            
            {/* Logout Button */}
            <Button
              onClick={handleLogout}
              variant="danger"
              size="sm"
              icon={LogOut}
            >
              Logout
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;