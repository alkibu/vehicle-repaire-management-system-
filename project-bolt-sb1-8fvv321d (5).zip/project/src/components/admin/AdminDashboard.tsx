import React, { useState, useEffect } from 'react';
import { Shield, Users, Wrench, Car, CheckCircle, XCircle, AlertTriangle, TrendingUp, DollarSign, Clock, Activity, User, FileText, Download, Eye, BarChart3, PieChart, Calendar } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { User as UserType, ServiceRequest, Mechanic, Payment } from '../../types';
import Card from '../ui/Card';
import Button from '../ui/Button';
import Modal from '../ui/Modal';
import Header from '../ui/Header';
import ProfileModal from '../profile/ProfileModal';
import ActivityReportModal from '../reports/ActivityReportModal';

const AdminDashboard: React.FC = () => {
  const { user, extendSession } = useAuth();
  const [pendingMechanics, setPendingMechanics] = useState<Mechanic[]>([]);
  const [allUsers, setAllUsers] = useState<UserType[]>([]);
  const [allRequests, setAllRequests] = useState<ServiceRequest[]>([]);
  const [allPayments, setAllPayments] = useState<Payment[]>([]);
  const [selectedMechanic, setSelectedMechanic] = useState<Mechanic | null>(null);
  const [selectedUser, setSelectedUser] = useState<UserType | null>(null);
  const [selectedRequest, setSelectedRequest] = useState<ServiceRequest | null>(null);
  const [showMechanicModal, setShowMechanicModal] = useState(false);
  const [showUserModal, setShowUserModal] = useState(false);
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [showAnalyticsModal, setShowAnalyticsModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'requests' | 'payments'>('overview');
  const [stats, setStats] = useState({
    totalDrivers: 0,
    totalMechanics: 0,
    activeMechanics: 0,
    approvedMechanics: 0,
    pendingApprovals: 0,
    totalRequests: 0,
    activeRequests: 0,
    completedRequests: 0,
    rejectedRequests: 0,
    totalRevenue: 0,
    adminRevenue: 0,
    mechanicPayouts: 0,
    averageJobValue: 0,
    completionRate: 0,
    onlineMechanics: 0,
    todayRequests: 0,
    todayCompletions: 0,
    todayAdminEarnings: 0,
  });

  useEffect(() => {
    loadData();
    
    // Set up polling for real-time updates
    const interval = setInterval(() => {
      loadData();
      extendSession(); // Extend session on activity
    }, 10000); // Update every 10 seconds
    
    return () => clearInterval(interval);
  }, []);

  const loadData = () => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const requests = JSON.parse(localStorage.getItem('serviceRequests') || '[]');
    const payments = JSON.parse(localStorage.getItem('payments') || '[]');
    const adminRevenue = JSON.parse(localStorage.getItem('adminRevenue') || '[]');

    // Filter data
    const drivers = users.filter((u: UserType) => u.role === 'driver');
    const mechanics = users.filter((u: UserType) => u.role === 'mechanic');
    const pending = mechanics.filter((m: Mechanic) => !m.isApproved);
    const approved = mechanics.filter((m: Mechanic) => m.isApproved);
    const onlineMechanics = approved.filter((m: Mechanic) => m.isOnline);

    // Request statistics
    const activeRequests = requests.filter((r: ServiceRequest) => 
      ['pending', 'accepted', 'en_route', 'on_site'].includes(r.status)
    );
    const completedRequests = requests.filter((r: ServiceRequest) => r.status === 'completed');
    const rejectedRequests = requests.filter((r: ServiceRequest) => r.status === 'rejected');

    // Today's statistics
    const today = new Date().toDateString();
    const todayRequests = requests.filter((r: ServiceRequest) => 
      new Date(r.createdAt).toDateString() === today
    );
    const todayCompletions = requests.filter((r: ServiceRequest) => 
      r.status === 'completed' && new Date(r.updatedAt).toDateString() === today
    );

    // Financial statistics
    const totalRevenue = payments.reduce((sum: number, p: any) => sum + (p.totalAmount || p.amount || 0), 0);
    const adminTotalRevenue = adminRevenue.reduce((sum: number, r: any) => sum + r.totalEarnings, 0);
    const mechanicPayouts = payments.reduce((sum: number, p: any) => sum + (p.mechanicAmount || p.amount || 0), 0);
    const todayAdminEarnings = adminRevenue
      .filter((r: any) => new Date(r.timestamp).toDateString() === today)
      .reduce((sum: number, r: any) => sum + r.totalEarnings, 0);
    
    const averageJobValue = completedRequests.length > 0 
      ? completedRequests.reduce((sum: number, r: ServiceRequest) => sum + (r.estimatedCost || 0), 0) / completedRequests.length
      : 0;
    
    const completionRate = requests.length > 0 
      ? (completedRequests.length / requests.length) * 100 
      : 0;

    // Update state
    setAllUsers(users);
    setAllRequests(requests);
    setAllPayments(payments);
    setPendingMechanics(pending);

    // Calculate comprehensive stats
    setStats({
      totalDrivers: drivers.length,
      totalMechanics: mechanics.length,
      activeMechanics: approved.length,
      approvedMechanics: approved.length,
      pendingApprovals: pending.length,
      totalRequests: requests.length,
      activeRequests: activeRequests.length,
      completedRequests: completedRequests.length,
      rejectedRequests: rejectedRequests.length,
      totalRevenue: Math.round(totalRevenue),
      adminRevenue: Math.round(adminTotalRevenue),
      mechanicPayouts: Math.round(mechanicPayouts),
      averageJobValue: Math.round(averageJobValue),
      completionRate: Math.round(completionRate),
      onlineMechanics: onlineMechanics.length,
      todayRequests: todayRequests.length,
      todayCompletions: todayCompletions.length,
      todayAdminEarnings: Math.round(todayAdminEarnings),
    });
  };

  const handleMechanicApproval = (mechanicId: string, approved: boolean) => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const updatedUsers = users.map((u: UserType) =>
      u.id === mechanicId && u.role === 'mechanic'
        ? { ...u, isApproved: approved }
        : u
    );
    localStorage.setItem('users', JSON.stringify(updatedUsers));
    loadData();
    setShowMechanicModal(false);
    setSelectedMechanic(null);
    
    // Extend session on activity
    extendSession();
  };

  const handleUserAction = (userId: string, action: 'suspend' | 'activate' | 'delete') => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    let updatedUsers;

    switch (action) {
      case 'suspend':
        updatedUsers = users.map((u: UserType) =>
          u.id === userId ? { ...u, isSuspended: true } : u
        );
        break;
      case 'activate':
        updatedUsers = users.map((u: UserType) =>
          u.id === userId ? { ...u, isSuspended: false } : u
        );
        break;
      case 'delete':
        updatedUsers = users.filter((u: UserType) => u.id !== userId);
        break;
      default:
        return;
    }

    localStorage.setItem('users', JSON.stringify(updatedUsers));
    loadData();
    setShowUserModal(false);
    setSelectedUser(null);
    extendSession();
  };

  const exportData = (type: 'users' | 'requests' | 'payments') => {
    let data, filename;
    
    switch (type) {
      case 'users':
        data = allUsers;
        filename = 'users-export.json';
        break;
      case 'requests':
        data = allRequests;
        filename = 'requests-export.json';
        break;
      case 'payments':
        data = allPayments;
        filename = 'payments-export.json';
        break;
    }

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const exportAdminRevenue = () => {
    const adminRevenue = JSON.parse(localStorage.getItem('adminRevenue') || '[]');
    const reportContent = `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>On-Road Assist - Admin Revenue Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
        .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 30px; }
        .title { font-size: 24px; font-weight: bold; color: #2563eb; margin-bottom: 10px; }
        .subtitle { font-size: 18px; color: #666; }
        .section { margin: 30px 0; }
        .section-title { font-size: 16px; font-weight: bold; color: #333; border-bottom: 1px solid #ccc; padding-bottom: 5px; margin-bottom: 15px; }
        .stats-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin: 20px 0; }
        .stat-item { padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
        .stat-label { font-weight: bold; color: #555; }
        .stat-value { font-size: 18px; color: #2563eb; font-weight: bold; }
        .currency { color: #059669; font-weight: bold; }
        .footer { margin-top: 50px; text-align: center; font-size: 12px; color: #666; border-top: 1px solid #ccc; padding-top: 20px; }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">ON-ROAD ASSIST</div>
        <div class="subtitle">Vehicle Repair Management System</div>
        <div class="subtitle">ADMIN REVENUE REPORT</div>
    </div>
    
    <div class="section">
        <div class="section-title">REVENUE SUMMARY</div>
        <div class="stats-grid">
            <div class="stat-item">
                <div class="stat-label">Total Admin Revenue</div>
                <div class="stat-value currency">Le ${stats.adminRevenue.toLocaleString()}</div>
            </div>
            <div class="stat-item">
                <div class="stat-label">Total Platform Volume</div>
                <div class="stat-value currency">Le ${stats.totalRevenue.toLocaleString()}</div>
            </div>
            <div class="stat-item">
                <div class="stat-label">Mechanic Payouts</div>
                <div class="stat-value currency">Le ${stats.mechanicPayouts.toLocaleString()}</div>
            </div>
            <div class="stat-item">
                <div class="stat-label">Revenue Share</div>
                <div class="stat-value">${((stats.adminRevenue / Math.max(stats.totalRevenue, 1)) * 100).toFixed(1)}%</div>
            </div>
        </div>
    </div>

    <div class="section">
        <div class="section-title">COMMISSION BREAKDOWN</div>
        ${adminRevenue.map((revenue: any, index: number) => `
            <div style="margin: 10px 0; padding: 10px; border-left: 3px solid #2563eb; background: #f8f9fa;">
                <strong>${index + 1}. Transaction ID:</strong> ${revenue.transactionId}<br>
                <strong>Date:</strong> ${new Date(revenue.timestamp).toLocaleString()}<br>
                <strong>Commission (15%):</strong> <span class="currency">Le ${revenue.commission.toLocaleString()}</span><br>
                <strong>Processing Fee (2%):</strong> <span class="currency">Le ${revenue.processingFee.toLocaleString()}</span><br>
                <strong>Total Earnings:</strong> <span class="currency">Le ${revenue.totalEarnings.toLocaleString()}</span><br>
            </div>
        `).join('')}
    </div>
    
    <div class="footer">
        <p><strong>On-Road Assist</strong> - Vehicle Repair Management System</p>
        <p>Admin Revenue Report generated on ${new Date().toLocaleString()}</p>
    </div>
</body>
</html>`;

    const blob = new Blob([reportContent], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `OnRoad-Assist-Admin-Revenue-Report-${new Date().toISOString().split('T')[0]}.doc`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-600 bg-yellow-100';
      case 'accepted': return 'text-blue-600 bg-blue-100';
      case 'en_route': return 'text-purple-600 bg-purple-100';
      case 'on_site': return 'text-green-600 bg-green-100';
      case 'completed': return 'text-gray-600 bg-gray-100';
      case 'rejected': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getUrgencyColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-green-600 bg-green-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'high': return 'text-orange-600 bg-orange-100';
      case 'emergency': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-8">
            {/* Main Statistics Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* Total Drivers */}
              <Card>
                <div className="flex items-center">
                  <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <Car className="h-6 w-6 text-blue-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Total Drivers</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.totalDrivers}</p>
                    <p className="text-xs text-gray-500">Registered users</p>
                  </div>
                </div>
              </Card>

              {/* Active Mechanics */}
              <Card>
                <div className="flex items-center">
                  <div className="h-12 w-12 bg-green-100 rounded-full flex items-center justify-center">
                    <Wrench className="h-6 w-6 text-green-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Active Mechanics</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.activeMechanics}</p>
                    <p className="text-xs text-gray-500">
                      {stats.onlineMechanics} online • {stats.pendingApprovals} pending
                    </p>
                  </div>
                </div>
              </Card>

              {/* Active Requests */}
              <Card>
                <div className="flex items-center">
                  <div className="h-12 w-12 bg-purple-100 rounded-full flex items-center justify-center">
                    <Activity className="h-6 w-6 text-purple-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Active Requests</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.activeRequests}</p>
                    <p className="text-xs text-gray-500">
                      {stats.todayRequests} today • {stats.totalRequests} total
                    </p>
                  </div>
                </div>
              </Card>

              {/* Completed Jobs */}
              <Card>
                <div className="flex items-center">
                  <div className="h-12 w-12 bg-gray-100 rounded-full flex items-center justify-center">
                    <CheckCircle className="h-6 w-6 text-gray-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Completed</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.completedRequests}</p>
                    <p className="text-xs text-gray-500">
                      {stats.todayCompletions} today • {stats.completionRate}% success rate
                    </p>
                  </div>
                </div>
              </Card>
            </div>

            {/* Secondary Statistics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Financial Overview */}
              <Card>
                <div className="flex items-center">
                  <div className="h-12 w-12 bg-green-100 rounded-full flex items-center justify-center">
                    <DollarSign className="h-6 w-6 text-green-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Platform Revenue</p>
                    <p className="text-2xl font-bold text-gray-900">Le {stats.totalRevenue.toLocaleString()}</p>
                    <p className="text-xs text-gray-500">Admin: Le {stats.adminRevenue.toLocaleString()}</p>
                  </div>
                </div>
              </Card>

              {/* Admin Earnings */}
              <Card>
                <div className="flex items-center">
                  <div className="h-12 w-12 bg-purple-100 rounded-full flex items-center justify-center">
                    <TrendingUp className="h-6 w-6 text-purple-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Admin Earnings</p>
                    <p className="text-2xl font-bold text-gray-900">Le {stats.adminRevenue.toLocaleString()}</p>
                    <p className="text-xs text-gray-500">Today: Le {stats.todayAdminEarnings.toLocaleString()}</p>
                  </div>
                </div>
              </Card>
              {/* System Performance */}
              <Card>
                <div className="flex items-center">
                  <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <CheckCircle className="h-6 w-6 text-blue-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Success Rate</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.completionRate}%</p>
                    <p className="text-xs text-gray-500">{stats.rejectedRequests} rejected</p>
                  </div>
                </div>
              </Card>

            </div>

            {/* Pending Mechanic Approvals */}
            <Card>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-900">Pending Mechanic Approvals</h2>
                {stats.pendingApprovals > 0 && (
                  <span className="px-2 py-1 bg-orange-100 text-orange-700 text-sm rounded-full">
                    {stats.pendingApprovals} pending
                  </span>
                )}
              </div>

              <div className="space-y-4">
                {pendingMechanics.slice(0, 5).map((mechanic) => (
                  <div
                    key={mechanic.id}
                    className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">{mechanic.businessName}</h3>
                        <p className="text-sm text-gray-600">{mechanic.username} • {mechanic.email}</p>
                        <p className="text-sm text-gray-600">{mechanic.phone}</p>
                        <p className="text-sm text-gray-500 mt-1">{mechanic.workshopAddress}</p>
                        
                        <div className="mt-2">
                          <div className="flex flex-wrap gap-1">
                            {mechanic.specialties.slice(0, 3).map((specialty) => (
                              <span
                                key={specialty}
                                className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full"
                              >
                                {specialty}
                              </span>
                            ))}
                            {mechanic.specialties.length > 3 && (
                              <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">
                                +{mechanic.specialties.length - 3} more
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-4 flex space-x-2">
                      <Button
                        onClick={() => {
                          setSelectedMechanic(mechanic);
                          setShowMechanicModal(true);
                        }}
                        variant="primary"
                        size="sm"
                        icon={CheckCircle}
                      >
                        Review
                      </Button>
                    </div>
                  </div>
                ))}

                {pendingMechanics.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Users className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                    <p>No pending mechanic approvals</p>
                    <p className="text-sm">New mechanic registrations will appear here</p>
                  </div>
                )}
              </div>
            </Card>
          </div>
        );

      case 'users':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">User Management</h2>
              <Button
                onClick={() => exportData('users')}
                variant="secondary"
                size="sm"
                icon={Download}
              >
                Export Users
              </Button>
            </div>

            <div className="space-y-4">
              {allUsers.map((user) => (
                <Card key={user.id}>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h3 className="font-medium text-gray-900">{user.username}</h3>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          user.role === 'admin' ? 'bg-purple-100 text-purple-700' :
                          user.role === 'mechanic' ? 'bg-green-100 text-green-700' :
                          'bg-blue-100 text-blue-700'
                        }`}>
                          {user.role.toUpperCase()}
                        </span>
                        {(user as any).isSuspended && (
                          <span className="px-2 py-1 bg-red-100 text-red-700 rounded-full text-xs font-medium">
                            SUSPENDED
                          </span>
                        )}
                      </div>
                      <div className="text-sm text-gray-600">
                        <p><span className="font-medium">Email:</span> {user.email}</p>
                        <p><span className="font-medium">Phone:</span> {user.phone}</p>
                        <p><span className="font-medium">Joined:</span> {formatDate(user.createdAt)}</p>
                        {user.role === 'mechanic' && (
                          <>
                            <p><span className="font-medium">Business:</span> {(user as any).businessName}</p>
                            <p><span className="font-medium">Status:</span> {(user as any).isApproved ? 'Approved' : 'Pending'}</p>
                          </>
                        )}
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button
                        onClick={() => {
                          setSelectedUser(user);
                          setShowUserModal(true);
                        }}
                        variant="secondary"
                        size="sm"
                        icon={Eye}
                      >
                        View
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 'requests':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">Service Requests</h2>
              <Button
                onClick={() => exportData('requests')}
                variant="secondary"
                size="sm"
                icon={Download}
              >
                Export Requests
              </Button>
            </div>

            <div className="space-y-4">
              {allRequests.map((request, index) => (
                <Card key={request.id}>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h3 className="font-medium text-gray-900">Request #{index + 1}</h3>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(request.status)}`}>
                          {request.status.toUpperCase()}
                        </span>
                        {request.urgencyLevel && (
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getUrgencyColor(request.urgencyLevel)}`}>
                            {request.urgencyLevel.toUpperCase()}
                          </span>
                        )}
                      </div>
                      <div className="text-sm text-gray-600">
                        <p><span className="font-medium">Vehicle:</span> {request.vehicleMake} {request.vehicleModel} ({request.vehicleType})</p>
                        <p><span className="font-medium">Problem:</span> {request.problemDescription.substring(0, 100)}...</p>
                        <p><span className="font-medium">Cost:</span> Le {request.estimatedCost?.toLocaleString()}</p>
                        <p><span className="font-medium">Created:</span> {formatDate(request.createdAt)}</p>
                        {request.rejectionReason && (
                          <p><span className="font-medium">Rejection Reason:</span> {request.rejectionReason}</p>
                        )}
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button
                        onClick={() => {
                          setSelectedRequest(request);
                          setShowRequestModal(true);
                        }}
                        variant="secondary"
                        size="sm"
                        icon={Eye}
                      >
                        View Details
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 'payments':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">Payment History</h2>
              <Button
                onClick={() => exportData('payments')}
                variant="secondary"
                size="sm"
                icon={Download}
              >
                Export Payments
              </Button>
            </div>

            <div className="space-y-4">
              {allPayments.map((payment, index) => (
                <Card key={payment.id}>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h3 className="font-medium text-gray-900">Payment #{index + 1}</h3>
                        <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                          {payment.status.toUpperCase()}
                        </span>
                      </div>
                      <div className="text-sm text-gray-600">
                        <p><span className="font-medium">Amount:</span> Le {payment.amount.toLocaleString()}</p>
                        <p><span className="font-medium">Method:</span> {payment.method}</p>
                        <p><span className="font-medium">Transaction ID:</span> {payment.transactionId}</p>
                        <p><span className="font-medium">Date:</span> {formatDate(payment.timestamp)}</p>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Actions */}
        <div className="mb-8">
          <Card>
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">Admin Dashboard</h2>
              <div className="flex space-x-3">
                <Button
                  onClick={() => setShowProfileModal(true)}
                  variant="secondary"
                  size="sm"
                  icon={User}
                >
                  Edit Profile
                </Button>
                <Button
                  onClick={() => setShowReportModal(true)}
                  variant="secondary"
                  size="sm"
                  icon={FileText}
                >
                  System Report
                </Button>
                <Button
                  onClick={() => setShowAnalyticsModal(true)}
                  variant="secondary"
                  size="sm"
                  icon={BarChart3}
                >
                  Analytics
                </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* Navigation Tabs */}
        <div className="mb-8">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8">
              {[
                { id: 'overview', label: 'Overview', icon: TrendingUp },
                { id: 'users', label: 'Users', icon: Users },
                { id: 'requests', label: 'Requests', icon: AlertTriangle },
                { id: 'payments', label: 'Payments', icon: DollarSign },
              ].map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`flex items-center space-x-2 py-2 px-1 border-b-2 font-medium text-sm ${
                      activeTab === tab.id
                        ? 'border-blue-500 text-blue-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Tab Content */}
        {renderTabContent()}
      </div>

      {/* Mechanic Review Modal */}
      <Modal
        isOpen={showMechanicModal}
        onClose={() => setShowMechanicModal(false)}
        title="Review Mechanic Application"
        size="lg"
      >
        {selectedMechanic && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-medium text-gray-900 mb-3">Business Information</h3>
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium text-gray-700">Business Name:</span> {selectedMechanic.businessName}</p>
                  <p><span className="font-medium text-gray-700">Owner:</span> {selectedMechanic.username}</p>
                  <p><span className="font-medium text-gray-700">Email:</span> {selectedMechanic.email}</p>
                  <p><span className="font-medium text-gray-700">Phone:</span> {selectedMechanic.phone}</p>
                  <p><span className="font-medium text-gray-700">Address:</span> {selectedMechanic.workshopAddress}</p>
                  <p><span className="font-medium text-gray-700">Registered:</span> {formatDate(selectedMechanic.createdAt)}</p>
                </div>
              </div>
              
              <div>
                <h3 className="font-medium text-gray-900 mb-3">Specialties & Services</h3>
                <div className="flex flex-wrap gap-2">
                  {selectedMechanic.specialties.map((specialty) => (
                    <span
                      key={specialty}
                      className="px-3 py-1 bg-green-100 text-green-700 text-sm rounded-full"
                    >
                      {specialty}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="border-t pt-6">
              <h3 className="font-medium text-gray-900 mb-3">Approval Decision</h3>
              <p className="text-sm text-gray-600 mb-4">
                Review the mechanic's information carefully. Approved mechanics will be able to receive and respond to driver requests.
              </p>
              
              <div className="flex space-x-3">
                <Button
                  onClick={() => handleMechanicApproval(selectedMechanic.id, false)}
                  variant="danger"
                  fullWidth
                  icon={XCircle}
                >
                  Reject Application
                </Button>
                <Button
                  onClick={() => handleMechanicApproval(selectedMechanic.id, true)}
                  variant="success"
                  fullWidth
                  icon={CheckCircle}
                >
                  Approve Mechanic
                </Button>
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* User Details Modal */}
      <Modal
        isOpen={showUserModal}
        onClose={() => setShowUserModal(false)}
        title="User Details"
        size="lg"
      >
        {selectedUser && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-medium text-gray-900 mb-3">User Information</h3>
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium text-gray-700">Username:</span> {selectedUser.username}</p>
                  <p><span className="font-medium text-gray-700">Email:</span> {selectedUser.email}</p>
                  <p><span className="font-medium text-gray-700">Phone:</span> {selectedUser.phone}</p>
                  <p><span className="font-medium text-gray-700">Role:</span> {selectedUser.role}</p>
                  <p><span className="font-medium text-gray-700">Joined:</span> {formatDate(selectedUser.createdAt)}</p>
                  <p><span className="font-medium text-gray-700">Status:</span> {(selectedUser as any).isSuspended ? 'Suspended' : 'Active'}</p>
                </div>
              </div>
              
              <div>
                <h3 className="font-medium text-gray-900 mb-3">Additional Details</h3>
                <div className="space-y-2 text-sm">
                  {selectedUser.role === 'mechanic' && (
                    <>
                      <p><span className="font-medium text-gray-700">Business:</span> {(selectedUser as any).businessName}</p>
                      <p><span className="font-medium text-gray-700">Address:</span> {(selectedUser as any).workshopAddress}</p>
                      <p><span className="font-medium text-gray-700">Approved:</span> {(selectedUser as any).isApproved ? 'Yes' : 'No'}</p>
                    </>
                  )}
                  {selectedUser.role === 'driver' && (
                    <p><span className="font-medium text-gray-700">Vehicle:</span> {(selectedUser as any).vehicleType}</p>
                  )}
                </div>
              </div>
            </div>

            <div className="border-t pt-6">
              <h3 className="font-medium text-gray-900 mb-3">User Actions</h3>
              <div className="flex space-x-3">
                {!(selectedUser as any).isSuspended ? (
                  <Button
                    onClick={() => handleUserAction(selectedUser.id, 'suspend')}
                    variant="warning"
                    icon={XCircle}
                  >
                    Suspend User
                  </Button>
                ) : (
                  <Button
                    onClick={() => handleUserAction(selectedUser.id, 'activate')}
                    variant="success"
                    icon={CheckCircle}
                  >
                    Activate User
                  </Button>
                )}
                <Button
                  onClick={() => {
                    if (confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
                      handleUserAction(selectedUser.id, 'delete');
                    }
                  }}
                  variant="danger"
                  icon={XCircle}
                >
                  Delete User
                </Button>
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* Request Details Modal */}
      <Modal
        isOpen={showRequestModal}
        onClose={() => setShowRequestModal(false)}
        title="Request Details"
        size="lg"
      >
        {selectedRequest && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-medium text-gray-900 mb-3">Request Information</h3>
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium text-gray-700">Vehicle:</span> {selectedRequest.vehicleMake} {selectedRequest.vehicleModel}</p>
                  <p><span className="font-medium text-gray-700">Type:</span> {selectedRequest.vehicleType}</p>
                  <p><span className="font-medium text-gray-700">Problem:</span> {selectedRequest.problemDescription}</p>
                  <p><span className="font-medium text-gray-700">Urgency:</span> {selectedRequest.urgencyLevel}</p>
                  <p><span className="font-medium text-gray-700">Cost:</span> Le {selectedRequest.estimatedCost?.toLocaleString()}</p>
                  <p><span className="font-medium text-gray-700">Status:</span> {selectedRequest.status}</p>
                </div>
              </div>
              
              <div>
                <h3 className="font-medium text-gray-900 mb-3">Timeline</h3>
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium text-gray-700">Created:</span> {formatDate(selectedRequest.createdAt)}</p>
                  <p><span className="font-medium text-gray-700">Updated:</span> {formatDate(selectedRequest.updatedAt)}</p>
                  {selectedRequest.rejectionReason && (
                    <p><span className="font-medium text-gray-700">Rejection Reason:</span> {selectedRequest.rejectionReason}</p>
                  )}
                </div>
              </div>
            </div>

            {selectedRequest.photos && selectedRequest.photos.length > 0 && (
              <div>
                <h3 className="font-medium text-gray-900 mb-3">Photos</h3>
                <div className="grid grid-cols-3 gap-3">
                  {selectedRequest.photos.map((photo, index) => (
                    <img
                      key={index}
                      src={photo}
                      alt={`Problem photo ${index + 1}`}
                      className="w-full h-24 object-cover rounded-lg border cursor-pointer hover:opacity-75"
                      onClick={() => window.open(photo, '_blank')}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </Modal>

      {/* Profile Modal */}
      {showProfileModal && (
        <ProfileModal
          isOpen={showProfileModal}
          onClose={() => setShowProfileModal(false)}
          user={user}
          onProfileUpdate={loadData}
        />
      )}

      {/* Activity Report Modal */}
      {showReportModal && (
        <ActivityReportModal
          isOpen={showReportModal}
          onClose={() => setShowReportModal(false)}
          userRole="admin"
        />
      )}

      {/* Analytics Modal */}
      <Modal
        isOpen={showAnalyticsModal}
        onClose={() => setShowAnalyticsModal(false)}
        title="System Analytics"
        size="xl"
      >
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{stats.totalDrivers + stats.totalMechanics}</div>
                <div className="text-sm text-gray-600">Total Users</div>
                <div className="text-xs text-gray-500">
                  {stats.totalDrivers} drivers + {stats.totalMechanics} mechanics
                </div>
              </div>
            </Card>
            
            <Card>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{stats.onlineMechanics}</div>
                <div className="text-sm text-gray-600">Online Now</div>
                <div className="text-xs text-gray-500">
                  {Math.round((stats.onlineMechanics / Math.max(stats.activeMechanics, 1)) * 100)}% of active mechanics
                </div>
              </div>
            </Card>
            
            <Card>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">{stats.totalRequests}</div>
                <div className="text-sm text-gray-600">Total Requests</div>
                <div className="text-xs text-gray-500">
                  {stats.activeRequests} active • {stats.completedRequests} completed
                </div>
              </div>
            </Card>
            
            <Card>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600">Le {stats.averageJobValue.toLocaleString()}</div>
                <div className="text-sm text-gray-600">Avg Job Value</div>
                <div className="text-xs text-gray-500">
                  Le {stats.totalRevenue.toLocaleString()} total revenue
                </div>
              </div>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <h3 className="font-medium text-gray-900 mb-4">Request Status Distribution</h3>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Completed</span>
                  <span className="text-sm font-medium">{stats.completedRequests} ({stats.completionRate}%)</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Active</span>
                  <span className="text-sm font-medium">{stats.activeRequests}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Rejected</span>
                  <span className="text-sm font-medium">{stats.rejectedRequests}</span>
                </div>
              </div>
            </Card>

            <Card>
              <h3 className="font-medium text-gray-900 mb-4">Today's Performance</h3>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">New Requests</span>
                  <span className="text-sm font-medium">{stats.todayRequests}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Completions</span>
                  <span className="text-sm font-medium">{stats.todayCompletions}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Online Mechanics</span>
                  <span className="text-sm font-medium">{stats.onlineMechanics}</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default AdminDashboard;