import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, Lock, Car, Wrench, Shield, Eye, EyeOff, Key } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { UserRole } from '../../types';
import Button from '../ui/Button';

interface LoginFormProps {
  role: UserRole;
}

const LoginForm: React.FC<LoginFormProps> = ({ role }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const { login, isLoading } = useAuth();
  const navigate = useNavigate();

  const roleConfig = {
    driver: {
      title: 'Driver Login',
      icon: Car,
      color: 'blue',
      dashboardPath: '/driver/dashboard',
      signupPath: '/driver/signup',
    },
    mechanic: {
      title: 'Mechanic Login',
      icon: Wrench,
      color: 'green',
      dashboardPath: '/mechanic/dashboard',
      signupPath: '/mechanic/signup',
    },
    admin: {
      title: 'Admin Login',
      icon: Shield,
      color: 'purple',
      dashboardPath: '/admin/dashboard',
      signupPath: undefined,
    },
  };

  const config = roleConfig[role];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email || !password) {
      setError('Please fill in all fields');
      return;
    }

    try {
      const success = await login(email, password, role);
      if (success) {
        navigate(config.dashboardPath);
      } else {
        setError('Invalid credentials');
      }
    } catch (err: any) {
      setError(err.message || 'Login failed');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden">
        {/* Header with tabs */}
        <div className="flex">
          <div className="flex-1 bg-blue-600 text-white py-4 px-6 flex items-center justify-center space-x-2">
            <Key className="h-5 w-5" />
            <span className="font-semibold">Login</span>
          </div>
          {config.signupPath && (
            <Link 
              to={config.signupPath}
              className="flex-1 bg-gray-200 text-gray-700 py-4 px-6 flex items-center justify-center space-x-2 hover:bg-gray-300 transition-colors"
            >
              <Mail className="h-5 w-5" />
              <span className="font-semibold">Register</span>
            </Link>
          )}
        </div>

        {/* Form Content */}
        <div className="p-8">
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold text-gray-900 mb-2">On-Road Assist</h1>
            <p className="text-gray-600">{config.title}</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Email Input */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Mail className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="email"
                placeholder="Email Address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                required
              />
            </div>

            {/* Password Input */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Lock className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="block w-full pl-10 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
              >
                {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
              </button>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-red-700 text-sm">
                {error}
              </div>
            )}

            {/* Login Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg transition-colors flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              <Key className="h-5 w-5" />
              <span>{isLoading ? 'Signing In...' : 'Login'}</span>
            </button>
          </form>

          {/* Forgot Password Link */}
          <div className="mt-6 text-center">
            <Link to="#" className="text-blue-600 hover:text-blue-700 text-sm flex items-center justify-center space-x-1">
              <Key className="h-4 w-4" />
              <span>Forgot your password?</span>
            </Link>
          </div>

          {/* Back to Home */}
          <div className="mt-6 text-center">
            <Link to="/" className="text-sm text-gray-500 hover:text-gray-700">
              ← Back to Home
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginForm;