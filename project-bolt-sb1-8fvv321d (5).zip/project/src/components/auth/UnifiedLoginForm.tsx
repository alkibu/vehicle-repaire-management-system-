import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, Lock, Eye, EyeOff, LogIn, Car, Wrench, Shield } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import Button from '../ui/Button';

const UnifiedLoginForm: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    if (!email || !password) {
      setError('Please fill in all fields');
      setIsLoading(false);
      return;
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError('Please enter a valid email address');
      setIsLoading(false);
      return;
    }

    try {
      // Get users from localStorage
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const foundUser = users.find((u: any) => 
        u.email.toLowerCase() === email.toLowerCase()
      );
      
      if (!foundUser) {
        setError('No account found with this email address');
        setIsLoading(false);
        return;
      }

      // Verify password
      if (foundUser.password && foundUser.password !== password) {
        setError('Invalid password. Please check your credentials and try again.');
        setIsLoading(false);
        return;
      }

      // Check approval status for mechanics
      if (foundUser.role === 'mechanic' && !foundUser.isApproved) {
        setError('Your mechanic account is pending admin approval. Please wait for approval.');
        setIsLoading(false);
        return;
      }

      // Check if user is suspended
      if (foundUser.isSuspended) {
        setError('Your account has been suspended. Please contact support.');
        setIsLoading(false);
        return;
      }

      // Admin check for superuser
      if (foundUser.role === 'admin' && !foundUser.isSuperUser) {
        setError('Access denied. Admin privileges required.');
        setIsLoading(false);
        return;
      }

      // Attempt login with detected role
      const success = await login(email, password, foundUser.role);
      if (success) {
        // Navigate based on user role
        switch (foundUser.role) {
          case 'driver':
            navigate('/driver/dashboard');
            break;
          case 'mechanic':
            navigate('/mechanic/dashboard');
            break;
          case 'admin':
            navigate('/admin/dashboard');
            break;
          default:
            navigate('/');
        }
      } else {
        setError('Login failed. Please try again.');
      }
    } catch (err: any) {
      setError(err.message || 'Login failed');
    } finally {
      setIsLoading(false);
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'admin':
        return Shield;
      case 'mechanic':
        return Wrench;
      case 'driver':
        return Car;
      default:
        return LogIn;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin':
        return 'purple';
      case 'mechanic':
        return 'green';
      case 'driver':
        return 'blue';
      default:
        return 'gray';
    }
  };

  // Check if email exists and get user role for preview
  const previewUser = React.useMemo(() => {
    if (!email) return null;
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    return users.find((u: any) => u.email.toLowerCase() === email.toLowerCase());
  }, [email]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-6 px-8 text-center">
          <div className="h-12 w-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
            <LogIn className="h-6 w-6" />
          </div>
          <h1 className="text-2xl font-bold mb-1">On-Road Assist</h1>
          <p className="text-blue-100">Sign in to your account</p>
        </div>

        {/* Form Content */}
        <div className="p-8">
          {/* User Role Preview */}
          {previewUser && (
            <div className="mb-6 p-3 bg-gray-50 rounded-lg border">
              <div className="flex items-center space-x-2">
                {React.createElement(getRoleIcon(previewUser.role), {
                  className: `h-5 w-5 text-${getRoleColor(previewUser.role)}-600`
                })}
                <div>
                  <p className="text-sm font-medium text-gray-900">
                    {previewUser.username}
                  </p>
                  <p className="text-xs text-gray-500">
                    {previewUser.role.charAt(0).toUpperCase() + previewUser.role.slice(1)} Account
                    {previewUser.role === 'mechanic' && !previewUser.isApproved && (
                      <span className="ml-2 px-2 py-0.5 bg-orange-100 text-orange-700 rounded-full text-xs">
                        Pending Approval
                      </span>
                    )}
                    {previewUser.isSuspended && (
                      <span className="ml-2 px-2 py-0.5 bg-red-100 text-red-700 rounded-full text-xs">
                        Suspended
                      </span>
                    )}
                  </p>
                </div>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Email Input */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Mail className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="email"
                placeholder="Email Address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                required
              />
            </div>

            {/* Password Input */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Lock className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="block w-full pl-10 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
              >
                {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
              </button>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-red-700 text-sm">
                {error}
              </div>
            )}

            {/* Login Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold py-3 px-4 rounded-lg transition-all duration-200 flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              <LogIn className="h-5 w-5" />
              <span>{isLoading ? 'Signing In...' : 'Sign In'}</span>
            </button>
          </form>

          {/* Registration Links */}
          <div className="mt-8 space-y-4">
            <div className="text-center">
              <p className="text-sm text-gray-600 mb-4">Don't have an account?</p>
              <div className="grid grid-cols-2 gap-3">
                <Link
                  to="/driver/signup"
                  className="flex items-center justify-center space-x-2 px-4 py-2 border border-blue-300 text-blue-600 rounded-lg hover:bg-blue-50 transition-colors"
                >
                  <Car className="h-4 w-4" />
                  <span className="text-sm">Driver</span>
                </Link>
                <Link
                  to="/mechanic/signup"
                  className="flex items-center justify-center space-x-2 px-4 py-2 border border-green-300 text-green-600 rounded-lg hover:bg-green-50 transition-colors"
                >
                  <Wrench className="h-4 w-4" />
                  <span className="text-sm">Mechanic</span>
                </Link>
              </div>
            </div>
          </div>

          {/* Demo Credentials */}
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <h4 className="text-sm font-medium text-gray-900 mb-2">Demo Credentials:</h4>
            <div className="text-xs text-gray-600 space-y-1">
              <p><strong>Admin:</strong> admin@vehiclerms.com / admin123</p>
              <p><strong>Note:</strong> Create driver/mechanic accounts via registration</p>
            </div>
          </div>

          {/* Back to Home */}
          <div className="mt-6 text-center">
            <Link to="/" className="text-sm text-gray-500 hover:text-gray-700">
              ← Back to Home
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UnifiedLoginForm;