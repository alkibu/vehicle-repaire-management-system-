import React, { useState, useEffect } from 'react';
import { User, Mail, Phone, Car, Building, MapPin, Save, X } from 'lucide-react';
import { User as UserType } from '../../types';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input from '../ui/Input';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserType | null;
  onProfileUpdate: () => void;
}

const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  user,
  onProfileUpdate,
}) => {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    phone: '',
    vehicleType: '',
    businessName: '',
    specialties: [] as string[],
    workshopAddress: '',
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const specialtyOptions = [
    'Engine Repair',
    'Transmission',
    'Brakes',
    'Electrical Systems',
    'Air Conditioning',
    'Tire Services',
    'Battery Replacement',
    'Oil Change',
    'Suspension',
    'Exhaust System',
  ];

  const vehicleTypes = [
    'Sedan',
    'SUV',
    'Truck',
    'Van',
    'Motorcycle',
    'Bus',
  ];

  useEffect(() => {
    if (user) {
      setFormData({
        username: user.username || '',
        email: user.email || '',
        phone: user.phone || '',
        vehicleType: (user as any).vehicleType || '',
        businessName: (user as any).businessName || '',
        specialties: (user as any).specialties || [],
        workshopAddress: (user as any).workshopAddress || '',
      });
    }
  }, [user]);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSpecialtyToggle = (specialty: string) => {
    setFormData(prev => ({
      ...prev,
      specialties: prev.specialties.includes(specialty)
        ? prev.specialties.filter(s => s !== specialty)
        : [...prev.specialties, specialty]
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setIsLoading(true);

    try {
      // Get current users
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      
      // Update user data
      const updatedUsers = users.map((u: any) => {
        if (u.id === user?.id) {
          return {
            ...u,
            ...formData,
            updatedAt: new Date().toISOString(),
          };
        }
        return u;
      });

      // Save to localStorage
      localStorage.setItem('users', JSON.stringify(updatedUsers));

      // Update current user in localStorage
      const updatedUser = updatedUsers.find((u: any) => u.id === user?.id);
      if (updatedUser) {
        localStorage.setItem('currentUser', JSON.stringify(updatedUser));
      }

      setSuccess('Profile updated successfully!');
      onProfileUpdate();
      
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (err) {
      setError('Failed to update profile. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Edit Profile"
      size="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Username"
            icon={User}
            value={formData.username}
            onChange={(value) => handleInputChange('username', value)}
            placeholder="Enter username"
            required
          />

          <Input
            label="Phone Number"
            icon={Phone}
            value={formData.phone}
            onChange={(value) => handleInputChange('phone', value)}
            placeholder="Enter phone number"
            required
          />
        </div>

        <Input
          label="Email Address"
          type="email"
          icon={Mail}
          value={formData.email}
          onChange={(value) => handleInputChange('email', value)}
          placeholder="Enter your email"
          required
          disabled
        />

        {user.role === 'driver' && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Vehicle Type
            </label>
            <div className="grid grid-cols-2 gap-2">
              {vehicleTypes.map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => handleInputChange('vehicleType', type)}
                  className={`p-3 rounded-lg border-2 text-sm font-medium transition-colors ${
                    formData.vehicleType === type
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>
        )}

        {user.role === 'mechanic' && (
          <>
            <Input
              label="Business Name"
              icon={Building}
              value={formData.businessName}
              onChange={(value) => handleInputChange('businessName', value)}
              placeholder="Enter business name"
              required
            />

            <Input
              label="Workshop Address"
              icon={MapPin}
              value={formData.workshopAddress}
              onChange={(value) => handleInputChange('workshopAddress', value)}
              placeholder="Enter workshop address"
              required
            />

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Specialties
              </label>
              <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto">
                {specialtyOptions.map((specialty) => (
                  <button
                    key={specialty}
                    type="button"
                    onClick={() => handleSpecialtyToggle(specialty)}
                    className={`p-2 rounded-lg border text-xs font-medium transition-colors ${
                      formData.specialties.includes(specialty)
                        ? 'border-green-500 bg-green-50 text-green-700'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    {specialty}
                  </button>
                ))}
              </div>
              <p className="text-xs text-gray-500 mt-1">Select all services you can provide</p>
            </div>
          </>
        )}

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-red-700 text-sm">
            {error}
          </div>
        )}

        {success && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-3 text-green-700 text-sm">
            {success}
          </div>
        )}

        <div className="flex space-x-3">
          <Button
            type="button"
            onClick={onClose}
            variant="secondary"
            fullWidth
            icon={X}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            variant="primary"
            fullWidth
            loading={isLoading}
            icon={Save}
          >
            {isLoading ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </form>
    </Modal>
  );
};

export default ProfileModal;