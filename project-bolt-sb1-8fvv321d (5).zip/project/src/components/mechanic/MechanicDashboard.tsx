import React, { useState, useEffect } from 'react';
import { Wrench, MapPin, Phone, Clock, CheckCircle, XCircle, Navigation, Bell, Users, Car, DollarSign, Eye, AlertTriangle, User, FileText, Play, Volume2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useLocation } from '../../context/LocationContext';
import { ServiceRequest, Driver } from '../../types';
import { mechanicDashboardAPI, databaseAPI, BreakdownRequest } from '../../services/api';
import Card from '../ui/Card';
import Button from '../ui/Button';
import Modal from '../ui/Modal';
import Header from '../ui/Header';
import GoogleMapView from '../maps/GoogleMapView';
import NotificationSystem from '../notifications/NotificationSystem';
import ProfileModal from '../profile/ProfileModal';
import ActivityReportModal from '../reports/ActivityReportModal';

const MechanicDashboard: React.FC = () => {
  const { user, extendSession } = useAuth();
  const { currentLocation, requestLocation, watchLocation, stopWatching } = useLocation();
  const [isOnline, setIsOnline] = useState(false);
  const [pendingRequests, setPendingRequests] = useState<ServiceRequest[]>([]);
  const [activeJob, setActiveJob] = useState<ServiceRequest | null>(null);
  const [assignedDriver, setAssignedDriver] = useState<Driver | null>(null);
  const [selectedRequest, setSelectedRequest] = useState<ServiceRequest | null>(null);
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');
  const [nearbyDrivers, setNearbyDrivers] = useState<Driver[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [balance, setBalance] = useState(0);
  const [paymentHistory, setPaymentHistory] = useState<any[]>([]);
  const [completedJobs, setCompletedJobs] = useState<ServiceRequest[]>([]);

  useEffect(() => {
    if (isOnline && currentLocation) {
      watchLocation();
    } else {
      stopWatching();
    }
    return () => stopWatching();
  }, [isOnline, currentLocation]);

  useEffect(() => {
    if (user) {
      loadData();
      loadBreakdownRequests(); // Load new API-based requests
      const interval = setInterval(() => {
        loadData();
        loadBreakdownRequests();
        extendSession();
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [user]);

  useEffect(() => {
    if (currentLocation && user && isOnline) {
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const updatedUsers = users.map((u: any) => 
        u.id === user.id ? { ...u, currentLocation, isOnline } : u
      );
      localStorage.setItem('users', JSON.stringify(updatedUsers));
    }
  }, [currentLocation, user, isOnline]);

  const loadData = () => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const mechanic = users.find((u: any) => u.id === user?.id);
    setIsOnline(mechanic?.isOnline || false);
    setBalance(mechanic?.balance || 0);

    const requests = JSON.parse(localStorage.getItem('serviceRequests') || '[]');
    
    const activeRequest = requests.find((r: any) => 
      r.mechanicId === user?.id && ['accepted', 'en_route', 'arrived', 'working'].includes(r.status)
    );
    setActiveJob(activeRequest || null);

    // Load completed jobs
    const completed = requests.filter((r: any) => 
      r.mechanicId === user?.id && r.status === 'completed'
    );
    setCompletedJobs(completed);

    if (activeRequest && activeRequest.driverId) {
      const driver = users.find((u: any) => u.id === activeRequest.driverId);
      setAssignedDriver(driver || null);
    } else {
      setAssignedDriver(null);
    }

    const driversWithLocation = users.filter((u: any) => 
      u.role === 'driver' && u.currentLocation
    );
    setNearbyDrivers(driversWithLocation);

    // Load payment history
    const payments = JSON.parse(localStorage.getItem('payments') || '[]');
    const mechanicPayments = payments.filter((p: any) => p.mechanicId === user?.id);
    setPaymentHistory(mechanicPayments);

    // Check for new payment notifications
    checkForPaymentNotifications();
  };

  // New function to load breakdown requests from API
  const loadBreakdownRequests = async () => {
    if (!user?.id) return;

    try {
      // Get pending requests for this mechanic from backend API
      const pendingBreakdownRequests = await apiService.getMechanicPendingRequests(user.id);
      
      // Convert backend response to frontend format
      const convertedRequests: ServiceRequest[] = pendingBreakdownRequests.map((req: any) => ({
        id: req.id,
        driverId: `guest-${req.id}`,
        mechanicId: req.mechanicId,
        vehicleType: req.vehicleType,
        vehicleMake: req.vehicleMake || '',
        vehicleModel: req.vehicleModel || '',
        vehicleYear: req.vehicleYear || '',
        problemDescription: req.problemDescription,
        urgencyLevel: req.urgencyLevel,
        breakdownLocation: {
          lat: req.breakdownLat,
          lng: req.breakdownLng,
          address: req.breakdownAddress || ''
        },
        photos: req.photos || [],
        audioExplanation: req.audioExplanation,
        additionalNotes: req.additionalNotes || '',
        status: req.status,
        estimatedCost: req.estimatedCost,
        createdAt: req.createdAt,
        updatedAt: req.updatedAt,
        isGuestBooking: true,
        guestPhone: req.driverPhone,
        guestEmail: req.driverEmail,
      }));

      setPendingRequests(convertedRequests);
      
    } catch (error) {
      console.error('Error loading breakdown requests:', error);
    }
  };

  const checkForPaymentNotifications = () => {
    const payments = JSON.parse(localStorage.getItem('payments') || '[]');
    const recentPayments = payments.filter((p: any) => 
      p.mechanicId === user?.id && 
      !p.notificationSent &&
      p.status === 'completed'
    );

    recentPayments.forEach((payment: any) => {
      addNotification({
        type: 'payment',
        title: 'Payment Received',
        message: `You received $${payment.amount} for completed job`,
        timestamp: new Date().toISOString(),
      });

      // Mark notification as sent
      const updatedPayments = payments.map((p: any) =>
        p.id === payment.id ? { ...p, notificationSent: true } : p
      );
      localStorage.setItem('payments', JSON.stringify(updatedPayments));
    });
  };

  const addNotification = (notification: any) => {
    setNotifications(prev => [notification, ...prev.slice(0, 4)]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n !== notification));
    }, 5000);
  };

  const toggleOnlineStatus = async () => {
    if (!isOnline && !currentLocation) {
      await requestLocation();
    }

    const newStatus = !isOnline;
    setIsOnline(newStatus);

    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const updatedUsers = users.map((u: any) => 
      u.id === user?.id ? { ...u, isOnline: newStatus, currentLocation } : u
    );
    localStorage.setItem('users', JSON.stringify(updatedUsers));
    
    extendSession();
  };

  const handleRequestAction = (request: ServiceRequest, action: 'accept' | 'reject') => {
    handleRequestActionAPI(request, action);
  };

  // New API-based request handling
  const handleRequestActionAPI = async (request: ServiceRequest, action: 'accept' | 'reject') => {
    if (!user?.id) return;

    try {
      let success = false;
      
      if (action === 'accept') {
        success = await mechanicDashboardAPI.acceptRequest(request.id, user.id);
        
        if (success) {
          setActiveJob({ ...request, status: 'accepted' });
          setPendingRequests(prev => prev.filter(r => r.id !== request.id));
          
          addNotification({
            type: 'success',
            title: 'Request Accepted',
            message: `You accepted the service request. Driver has been notified via email.`,
            timestamp: new Date().toISOString(),
          });
        }
      } else {
        success = await mechanicDashboardAPI.rejectRequest(request.id, user.id, rejectionReason);
        
        if (success) {
          setPendingRequests(prev => prev.filter(r => r.id !== request.id));
          
          addNotification({
            type: 'info',
            title: 'Request Rejected',
            message: `Request rejected. Driver has been notified via email with the reason.`,
            timestamp: new Date().toISOString(),
          });
        }
      }
      
      if (!success) {
        addNotification({
          type: 'error',
          title: 'Action Failed',
          message: `Failed to ${action} the request. Please try again.`,
          timestamp: new Date().toISOString(),
        });
      }
      
    } catch (error) {
      console.error(`Error ${action}ing request:`, error);
      addNotification({
        type: 'error',
        title: 'Error',
        message: `An error occurred while ${action}ing the request.`,
        timestamp: new Date().toISOString(),
      });
    }

    setShowRequestModal(false);
    setSelectedRequest(null);
    setRejectionReason('');
    extendSession();
  };

  const updateJobStatus = (status: 'en_route' | 'arrived' | 'working' | 'completed') => {
    updateJobStatusAPI(status);
  };

  // New API-based status updates
  const updateJobStatusAPI = async (status: 'en_route' | 'arrived' | 'working' | 'completed') => {
    if (!activeJob || !user?.id) return;

    try {
      const success = await mechanicDashboardAPI.updateRequestStatus(activeJob.id, status);
      
      if (success) {
        if (status === 'completed') {
          setActiveJob(null);
          setAssignedDriver(null);
          
          addNotification({
            type: 'success',
            title: 'Job Completed',
            message: 'Job marked as completed. Driver has been notified via email.',
            timestamp: new Date().toISOString(),
          });
        } else {
          setActiveJob({ ...activeJob, status });
          
          const statusMessages = {
            'en_route': 'You are now en route to the driver. Email notification sent.',
            'arrived': 'You have arrived at the location. Driver has been notified.',
            'working': 'You have started working on the vehicle. Status updated.'
          };
          
          addNotification({
            type: 'info',
            title: 'Status Updated',
            message: statusMessages[status],
            timestamp: new Date().toISOString(),
          });
        }
      } else {
        addNotification({
          type: 'error',
          title: 'Update Failed',
          message: 'Failed to update job status. Please try again.',
          timestamp: new Date().toISOString(),
        });
      }
      
    } catch (error) {
      console.error('Error updating job status:', error);
      addNotification({
        type: 'error',
        title: 'Error',
        message: 'An error occurred while updating the job status.',
        timestamp: new Date().toISOString(),
      });
    }
    
    extendSession();
  };

  const playAudioExplanation = (audioUrl: string) => {
    const audio = new Audio(audioUrl);
    audio.play().catch(error => {
      console.error('Error playing audio:', error);
      alert('Could not play audio. Please check your browser settings.');
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-600 bg-yellow-100';
      case 'accepted': return 'text-blue-600 bg-blue-100';
      case 'en_route': return 'text-purple-600 bg-purple-100';
      case 'on_site': return 'text-green-600 bg-green-100';
      case 'completed': return 'text-gray-600 bg-gray-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getUrgencyColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-green-600 bg-green-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'high': return 'text-orange-600 bg-orange-100';
      case 'emergency': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const calculateDistance = (location: { lat: number; lng: number }) => {
    if (!currentLocation) return 'Unknown';
    
    const lat1 = currentLocation.lat;
    const lng1 = currentLocation.lng;
    const lat2 = location.lat;
    const lng2 = location.lng;
    
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c;
    
    return `${distance.toFixed(1)} km`;
  };

  const getEstimatedArrival = (location: { lat: number; lng: number }) => {
    if (!currentLocation) return 'Unknown';
    
    const distance = parseFloat(calculateDistance(location).replace(' km', ''));
    const estimatedMinutes = Math.round(distance * 2);
    
    return `~${estimatedMinutes} min`;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <NotificationSystem notifications={notifications} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Actions */}
        <div className="mb-8">
          <Card>
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">Quick Actions</h2>
              <div className="flex space-x-3">
                <Button
                  onClick={() => setShowProfileModal(true)}
                  variant="secondary"
                  size="sm"
                  icon={User}
                >
                  Edit Profile
                </Button>
                <Button
                  onClick={() => setShowReportModal(true)}
                  variant="secondary"
                  size="sm"
                  icon={FileText}
                >
                  Activity Report
                </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* Account Balance & Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <div className="flex items-center">
              <div className="h-12 w-12 bg-green-100 rounded-full flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Account Balance</p>
                <p className="text-2xl font-bold text-gray-900">Le {balance.toLocaleString()}</p>
              </div>
            </div>
          </Card>

          <Card>
            <div className="flex items-center">
              <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center">
                <CheckCircle className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Completed Jobs</p>
                <p className="text-2xl font-bold text-gray-900">{completedJobs.length}</p>
              </div>
            </div>
          </Card>

          <Card>
            <div className="flex items-center">
              <div className="h-12 w-12 bg-orange-100 rounded-full flex items-center justify-center">
                <Bell className="h-6 w-6 text-orange-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Pending Requests</p>
                <p className="text-2xl font-bold text-gray-900">{pendingRequests.length}</p>
              </div>
            </div>
          </Card>

          <Card>
            <div className="flex items-center">
              <div className="h-12 w-12 bg-purple-100 rounded-full flex items-center justify-center">
                <Car className="h-6 w-6 text-purple-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Active Jobs</p>
                <p className="text-2xl font-bold text-gray-900">{activeJob ? 1 : 0}</p>
              </div>
            </div>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Active Job */}
          {activeJob && (
            <div className="lg:col-span-3">
              <Card className="mb-8">
                <div className="flex items-start justify-between mb-4">
                  <h2 className="text-lg font-semibold text-gray-900">Active Job</h2>
                  <div className="flex items-center space-x-2">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(activeJob.status)}`}>
                      {activeJob.status.replace('_', ' ').toUpperCase()}
                    </span>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getUrgencyColor(activeJob.urgencyLevel || 'medium')}`}>
                      {activeJob.urgencyLevel?.toUpperCase()}
                    </span>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-medium text-gray-900 mb-2">Job Details</h3>
                    <div className="space-y-2 text-sm text-gray-600">
                      <p><span className="font-medium">Vehicle:</span> {activeJob.vehicleMake} {activeJob.vehicleModel} ({activeJob.vehicleType})</p>
                      {activeJob.vehicleYear && <p><span className="font-medium">Year:</span> {activeJob.vehicleYear}</p>}
                      <p><span className="font-medium">Problem:</span> {activeJob.problemDescription}</p>
                      <p><span className="font-medium">Distance:</span> {calculateDistance(activeJob.breakdownLocation)}</p>
                      <p><span className="font-medium">ETA:</span> {getEstimatedArrival(activeJob.breakdownLocation)}</p>
                      <p><span className="font-medium">Estimated Cost:</span> Le {activeJob.estimatedCost?.toLocaleString()}</p>
                      <p><span className="font-medium">Accepted:</span> {new Date(activeJob.updatedAt).toLocaleString()}</p>
                      {activeJob.additionalNotes && (
                        <p><span className="font-medium">Notes:</span> {activeJob.additionalNotes}</p>
                      )}
                      {assignedDriver && (
                        <>
                          <p><span className="font-medium">Driver:</span> {assignedDriver.username}</p>
                          <p><span className="font-medium">Contact:</span> {assignedDriver.phone}</p>
                        </>
                      )}
                    </div>
                    
                    {/* Photos */}
                    {activeJob.photos && activeJob.photos.length > 0 && (
                      <div className="mt-4">
                        <h4 className="font-medium text-gray-900 mb-2">Problem Photos</h4>
                        <div className="grid grid-cols-3 gap-2">
                          {activeJob.photos.map((photo, index) => (
                            <img
                              key={index}
                              src={photo}
                              alt={`Problem photo ${index + 1}`}
                              className="w-full h-20 object-cover rounded-lg border cursor-pointer hover:opacity-75"
                              onClick={() => window.open(photo, '_blank')}
                            />
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Audio Explanation */}
                    {activeJob.audioExplanation && (
                      <div className="mt-4">
                        <h4 className="font-medium text-gray-900 mb-2">Audio Explanation</h4>
                        <div className="flex items-center space-x-2">
                          <Button
                            onClick={() => playAudioExplanation(activeJob.audioExplanation!)}
                            variant="secondary"
                            size="sm"
                            icon={Volume2}
                          >
                            Play Audio
                          </Button>
                          <span className="text-sm text-gray-500">Driver's audio explanation</span>
                        </div>
                      </div>
                    )}
                    
                    <div className="mt-4 flex space-x-2">
                      {activeJob.status === 'accepted' && (
                        <Button onClick={() => updateJobStatus('en_route')} variant="primary" size="sm" icon={Navigation}>
                          En Route
                        </Button>
                      )}
                      {activeJob.status === 'en_route' && (
                        <Button onClick={() => updateJobStatus('arrived')} variant="success" size="sm" icon={MapPin}>
                          Arrived
                        </Button>
                      )}
                      {activeJob.status === 'arrived' && (
                        <Button onClick={() => updateJobStatus('working')} variant="primary" size="sm" icon={Wrench}>
                          Start Work
                        </Button>
                      )}
                      {activeJob.status === 'working' && (
                        <Button onClick={() => updateJobStatus('completed')} variant="success" size="sm" icon={CheckCircle}>
                          Complete Job
                        </Button>
                      )}
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="font-medium text-gray-900 mb-2">Live Navigation</h3>
                    <GoogleMapView
                      currentLocation={currentLocation}
                      targetLocation={activeJob.breakdownLocation}
                      showRoute={activeJob.status === 'en_route'}
                      height="200px"
                      showBothLocations={true}
                      driverLocation={activeJob.breakdownLocation}
                      mechanicLocation={currentLocation}
                      zoom={16}
                    />
                    <div className="mt-2 text-xs text-gray-500">
                      <p>🔴 Your location • 🔵 Driver location</p>
                      <p>Last updated: {new Date().toLocaleTimeString()}</p>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          )}

          {/* Pending Requests */}
          <div className="lg:col-span-2">
            <Card>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-900">Pending Requests</h2>
                {pendingRequests.length > 0 && (
                  <div className="flex items-center space-x-2">
                    <Bell className="h-5 w-5 text-orange-500" />
                    <span className="text-sm font-medium text-orange-600">
                      {pendingRequests.length} new request{pendingRequests.length !== 1 ? 's' : ''}
                    </span>
                  </div>
                )}
              </div>

              {!isOnline && (
                <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg text-yellow-700 text-sm">
                  You are currently offline. Go online to receive new requests.
                </div>
              )}

              <div className="space-y-4">
                {pendingRequests.map((request) => (
                  <div
                    key={request.id}
                    className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="font-medium text-gray-900">Service Request</h3>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getUrgencyColor(request.urgencyLevel || 'medium')}`}>
                            {request.urgencyLevel?.toUpperCase()}
                          </span>
                        </div>
                        <div className="flex items-center space-x-4 mt-1 text-sm text-gray-500">
                          <span className="flex items-center">
                            <MapPin className="h-4 w-4 mr-1" />
                            {calculateDistance(request.breakdownLocation)}
                          </span>
                          <span className="flex items-center">
                            <Clock className="h-4 w-4 mr-1" />
                            {getEstimatedArrival(request.breakdownLocation)}
                          </span>
                          <span className="flex items-center">
                            <DollarSign className="h-4 w-4 mr-1" />
                            Le {request.estimatedCost?.toLocaleString()}
                          </span>
                        </div>
                      </div>
                      <span className="px-2 py-1 bg-yellow-100 text-yellow-700 text-xs rounded-full">
                        PENDING
                      </span>
                    </div>
                    
                    <div className="text-sm text-gray-600 mb-3">
                      <p><span className="font-medium">Vehicle:</span> {request.vehicleMake} {request.vehicleModel} ({request.vehicleType})</p>
                      <p><span className="font-medium">Problem:</span> {request.problemDescription.substring(0, 100)}...</p>
                      <p><span className="font-medium">Contact:</span> {(request as any).isGuestBooking ? (request as any).guestPhone : 'Registered User'}</p>
                      <p><span className="font-medium">Requested:</span> {new Date(request.createdAt).toLocaleString()}</p>
                    </div>
                    
                    <div className="flex space-x-2">
                      <Button
                        onClick={() => {
                          setSelectedRequest(request);
                          setShowDetailsModal(true);
                        }}
                        variant="secondary"
                        size="sm"
                        icon={Eye}
                      >
                        View Details
                      </Button>
                      <Button
                        onClick={() => {
                          setSelectedRequest(request);
                          setShowRequestModal(true);
                        }}
                        variant="primary"
                        size="sm"
                        icon={CheckCircle}
                      >
                        Accept
                      </Button>
                      <Button
                        onClick={() => {
                          setSelectedRequest(request);
                          setShowRequestModal(true);
                        }}
                        variant="danger"
                        size="sm"
                        icon={XCircle}
                      >
                        Reject
                      </Button>
                    </div>
                  </div>
                ))}

                {pendingRequests.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Bell className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                    <p>No pending requests</p>
                    <p className="text-sm">New requests will appear here when drivers need assistance</p>
                  </div>
                )}
              </div>
            </Card>
          </div>

          {/* Status & Payment History */}
          <div className="lg:col-span-1">
            <Card className="mb-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Your Status</h2>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Availability</span>
                  <div className="flex items-center space-x-2">
                    <div className={`h-3 w-3 rounded-full ${isOnline ? 'bg-green-500' : 'bg-gray-400'}`}></div>
                    <span className="font-medium">{isOnline ? 'Online' : 'Offline'}</span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Active Jobs</span>
                  <span className="font-medium">{activeJob ? '1' : '0'}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Pending Requests</span>
                  <span className="font-medium">{pendingRequests.length}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-gray-600">GPS Status</span>
                  <span className={`font-medium ${currentLocation ? 'text-green-600' : 'text-red-600'}`}>
                    {currentLocation ? 'Active' : 'Inactive'}
                  </span>
                </div>
              </div>
              
              <div className="mt-4">
                <Button
                  onClick={toggleOnlineStatus}
                  variant={isOnline ? 'danger' : 'success'}
                  fullWidth
                >
                  {isOnline ? 'Go Offline' : 'Go Online'}
                </Button>
              </div>
            </Card>

            {/* Payment History */}
            <Card className="mb-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Recent Payments</h2>
              
              {paymentHistory.length > 0 ? (
                <div className="space-y-3 max-h-60 overflow-y-auto">
                  {paymentHistory.slice(0, 5).map((payment) => (
                    <div key={payment.id} className="border-b border-gray-100 pb-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="text-sm font-medium text-gray-900">Le {payment.amount.toLocaleString()}</p>
                          <p className="text-xs text-gray-500">{payment.method}</p>
                          <p className="text-xs text-gray-500">{new Date(payment.timestamp).toLocaleDateString()}</p>
                        </div>
                        <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
                          Received
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-4 text-gray-500">
                  <DollarSign className="h-8 w-8 mx-auto mb-2 text-gray-300" />
                  <p className="text-sm">No payments yet</p>
                </div>
              )}
            </Card>

            {/* Current Location */}
            <Card>
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Current Location</h2>
              
              {currentLocation ? (
                <div>
                  <GoogleMapView
                    currentLocation={currentLocation}
                    height="200px"
                    className="mb-4"
                    showNearbyDrivers={true}
                    nearbyDrivers={nearbyDrivers}
                    zoom={14}
                  />
                  <div className="text-sm text-gray-600 space-y-1">
                    <p><span className="font-medium">Coordinates:</span></p>
                    <p>{currentLocation.lat.toFixed(6)}, {currentLocation.lng.toFixed(6)}</p>
                    <p><span className="font-medium">Accuracy:</span> ±{Math.round(currentLocation.accuracy)}m</p>
                    <p><span className="font-medium">Last Update:</span> {new Date(currentLocation.timestamp).toLocaleTimeString()}</p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <MapPin className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                  <p className="text-gray-500 mb-3">Location not available</p>
                  <Button onClick={requestLocation} size="sm" variant="secondary">
                    Enable Location
                  </Button>
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>

      {/* Request Details Modal */}
      <Modal
        isOpen={showDetailsModal}
        onClose={() => setShowDetailsModal(false)}
        title="Request Details"
        size="lg"
      >
        {selectedRequest && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-medium text-gray-900 mb-3">Vehicle Information</h3>
                <div className="space-y-2 text-sm text-gray-600">
                  <p><span className="font-medium">Type:</span> {selectedRequest.vehicleType}</p>
                  <p><span className="font-medium">Make:</span> {selectedRequest.vehicleMake}</p>
                  <p><span className="font-medium">Model:</span> {selectedRequest.vehicleModel}</p>
                  {selectedRequest.vehicleYear && <p><span className="font-medium">Year:</span> {selectedRequest.vehicleYear}</p>}
                  <p><span className="font-medium">Problem:</span> {selectedRequest.problemDescription}</p>
                  {selectedRequest.additionalNotes && (
                    <p><span className="font-medium">Additional Notes:</span> {selectedRequest.additionalNotes}</p>
                  )}
                  <p><span className="font-medium">Urgency:</span> 
                    <span className={`ml-2 px-2 py-1 rounded-full text-xs font-medium ${getUrgencyColor(selectedRequest.urgencyLevel || 'medium')}`}>
                      {selectedRequest.urgencyLevel?.toUpperCase()}
                    </span>
                  </p>
                  <p><span className="font-medium">Estimated Cost:</span> Le {selectedRequest.estimatedCost?.toLocaleString()}</p>
                  <p><span className="font-medium">Distance:</span> {calculateDistance(selectedRequest.breakdownLocation)}</p>
                  <p><span className="font-medium">ETA:</span> {getEstimatedArrival(selectedRequest.breakdownLocation)}</p>
                  <p><span className="font-medium">Requested:</span> {new Date(selectedRequest.createdAt).toLocaleString()}</p>
                </div>
              </div>
              
              <div>
                <h3 className="font-medium text-gray-900 mb-3">Location & Route</h3>
                <GoogleMapView
                  currentLocation={currentLocation}
                  targetLocation={selectedRequest.breakdownLocation}
                  showRoute={true}
                  height="200px"
                  showBothLocations={true}
                  driverLocation={selectedRequest.breakdownLocation}
                  mechanicLocation={currentLocation}
                  zoom={15}
                />
                <div className="mt-2 text-xs text-gray-500">
                  <p>🔴 Your location • 🔵 Driver location</p>
                  <p>GPS: {selectedRequest.breakdownLocation.lat.toFixed(4)}, {selectedRequest.breakdownLocation.lng.toFixed(4)}</p>
                </div>
              </div>
            </div>

            {/* Photos */}
            {selectedRequest.photos && selectedRequest.photos.length > 0 && (
              <div>
                <h3 className="font-medium text-gray-900 mb-3">Problem Photos</h3>
                <div className="grid grid-cols-3 gap-3">
                  {selectedRequest.photos.map((photo, index) => (
                    <img
                      key={index}
                      src={photo}
                      alt={`Problem photo ${index + 1}`}
                      className="w-full h-24 object-cover rounded-lg border cursor-pointer hover:opacity-75"
                      onClick={() => window.open(photo, '_blank')}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Audio Explanation */}
            {selectedRequest.audioExplanation && (
              <div>
                <h3 className="font-medium text-gray-900 mb-3">Audio Explanation</h3>
                <div className="border border-gray-300 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <Volume2 className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">Driver's Audio Explanation</p>
                        <p className="text-xs text-gray-500">Click to listen to the problem description</p>
                      </div>
                    </div>
                    <Button
                      onClick={() => playAudioExplanation(selectedRequest.audioExplanation!)}
                      variant="primary"
                      size="sm"
                      icon={Play}
                    >
                      Play Audio
                    </Button>
                  </div>
                </div>
              </div>
            )}

            <div className="flex space-x-3">
              <Button
                onClick={() => setShowDetailsModal(false)}
                variant="secondary"
                fullWidth
              >
                Close
              </Button>
              <Button
                onClick={() => {
                  setShowDetailsModal(false);
                  setShowRequestModal(true);
                }}
                variant="primary"
                fullWidth
              >
                Accept/Reject Request
              </Button>
            </div>
          </div>
        )}
      </Modal>

      {/* Request Action Modal */}
      <Modal
        isOpen={showRequestModal}
        onClose={() => setShowRequestModal(false)}
        title="Request Action"
        size="md"
      >
        {selectedRequest && (
          <div className="space-y-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h3 className="font-medium text-blue-900 mb-2">Request Summary</h3>
              <div className="text-sm text-blue-800">
                <p><span className="font-medium">Vehicle:</span> {selectedRequest.vehicleMake} {selectedRequest.vehicleModel}</p>
                <p><span className="font-medium">Problem:</span> {selectedRequest.problemDescription.substring(0, 100)}...</p>
                <p><span className="font-medium">Distance:</span> {calculateDistance(selectedRequest.breakdownLocation)}</p>
                <p><span className="font-medium">Estimated Payment:</span> Le {selectedRequest.estimatedCost?.toLocaleString()}</p>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Rejection Reason (if rejecting)
              </label>
              <textarea
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder="e.g., Too far from my location, Not my specialty, Currently busy, Vehicle type not supported..."
                rows={3}
                className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              <p className="text-xs text-gray-500 mt-1">This feedback will be sent to the driver</p>
            </div>

            <div className="flex space-x-3">
              <Button
                onClick={() => handleRequestAction(selectedRequest, 'reject')}
                variant="danger"
                fullWidth
                icon={XCircle}
                disabled={!rejectionReason.trim()}
              >
                Reject Request
              </Button>
              <Button
                onClick={() => handleRequestAction(selectedRequest, 'accept')}
                variant="success"
                fullWidth
                icon={CheckCircle}
              >
                Accept Request
              </Button>
            </div>
          </div>
        )}
      </Modal>

      {/* Profile Modal */}
      {showProfileModal && (
        <ProfileModal
          isOpen={showProfileModal}
          onClose={() => setShowProfileModal(false)}
          user={user}
          onProfileUpdate={loadData}
        />
      )}

      {/* Activity Report Modal */}
      {showReportModal && (
        <ActivityReportModal
          isOpen={showReportModal}
          onClose={() => setShowReportModal(false)}
          userRole="mechanic"
          userId={user?.id}
        />
      )}
    </div>
  );
};

export default MechanicDashboard;