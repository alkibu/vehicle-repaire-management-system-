import React, { useState } from 'react';
import { CreditCard, Smartphone, DollarSign, Lock, CheckCircle } from 'lucide-react';
import { ServiceRequest } from '../../types';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input from '../ui/Input';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  job: ServiceRequest;
  onPaymentSuccess: (paymentData: any) => void;
}

const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  job,
  onPaymentSuccess,
}) => {
  const [step, setStep] = useState<'details' | 'verification' | 'success'>('details');
  const [paymentData, setPaymentData] = useState({
    phoneNumber: '',
    fullName: '',
    paymentMethod: 'orange',
    pin: '',
  });
  const [verificationCode, setVerificationCode] = useState('');
  const [generatedCode, setGeneratedCode] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const paymentMethods = [
    { id: 'orange', name: 'Orange Money', color: 'orange', icon: '🟠' },
    { id: 'qcell', name: 'Qcell Money', color: 'blue', icon: '🔵' },
    { id: 'afrimoney', name: 'Afrimoney', color: 'green', icon: '🟢' },
  ];

  const handlePaymentSubmit = async () => {
    if (!paymentData.phoneNumber || !paymentData.fullName || !paymentData.pin) {
      alert('Please fill in all required fields');
      return;
    }

    if (paymentData.pin.length !== 4) {
      alert('PIN must be 4 digits');
      return;
    }

    setIsProcessing(true);

    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Generate verification code
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedCode(code);
    
    // Calculate commission breakdown
    const totalAmount = job.estimatedCost || 0;
    const adminCommission = Math.round(totalAmount * 0.15); // 15% admin commission
    const mechanicAmount = totalAmount - adminCommission;
    
    // Simulate SMS notification
    const notification = {
      type: 'sms',
      title: 'Payment Verification',
      message: `Your verification code is: ${code}. Enter this code to complete your payment of Le ${totalAmount.toLocaleString()}.`,
      timestamp: new Date().toISOString(),
    };

    // Show SMS-like notification
    showSMSNotification(notification);

    setIsProcessing(false);
    setStep('verification');
  };

  const showSMSNotification = (notification: any) => {
    // Create SMS-style notification
    const smsDiv = document.createElement('div');
    smsDiv.className = 'fixed top-4 right-4 bg-gray-800 text-white p-4 rounded-lg shadow-lg z-50 max-w-sm';
    smsDiv.innerHTML = `
      <div class="flex items-start space-x-3">
        <div class="bg-green-500 rounded-full p-1">
          <svg class="h-4 w-4 text-white" fill="currentColor" viewBox="0 0 20 20">
            <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"/>
            <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"/>
          </svg>
        </div>
        <div class="flex-1">
          <p class="font-medium text-sm">SMS Message</p>
          <p class="text-xs text-gray-300 mt-1">${notification.message}</p>
          <p class="text-xs text-gray-400 mt-2">${new Date().toLocaleTimeString()}</p>
        </div>
      </div>
    `;
    
    document.body.appendChild(smsDiv);
    
    // Auto remove after 8 seconds
    setTimeout(() => {
      if (document.body.contains(smsDiv)) {
        document.body.removeChild(smsDiv);
      }
    }, 8000);
  };

  const handleVerificationSubmit = async () => {
    if (verificationCode !== generatedCode) {
      alert('Invalid verification code. Please try again.');
      return;
    }

    setIsProcessing(true);

    // Simulate final payment processing
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Calculate payment breakdown
    const totalAmount = job.estimatedCost || 0;
    const adminCommission = Math.round(totalAmount * 0.15); // 15% admin commission
    const mechanicAmount = totalAmount - adminCommission;
    const processingFee = Math.round(totalAmount * 0.02); // 2% processing fee

    const transactionId = `TXN${Date.now()}`;
    const finalPaymentData = {
      ...paymentData,
      totalAmount: totalAmount,
      mechanicAmount: mechanicAmount,
      adminCommission: adminCommission,
      processingFee: processingFee,
      transactionId,
      method: paymentMethods.find(m => m.id === paymentData.paymentMethod)?.name,
      timestamp: new Date().toISOString(),
    };

    // Show success SMS
    showSMSNotification({
      type: 'sms',
      title: 'Payment Successful',
      message: `Payment of Le ${totalAmount.toLocaleString()} completed successfully. Transaction ID: ${transactionId}. Thank you for using On-Road Assist!`,
      timestamp: new Date().toISOString(),
    });

    setIsProcessing(false);
    setStep('success');

    // Call success callback after a short delay
    setTimeout(() => {
      onPaymentSuccess(finalPaymentData);
    }, 2000);
  };

  const resetModal = () => {
    setStep('details');
    setPaymentData({
      phoneNumber: '',
      fullName: '',
      paymentMethod: 'orange',
      pin: '',
    });
    setVerificationCode('');
    setGeneratedCode('');
    setIsProcessing(false);
  };

  const handleClose = () => {
    resetModal();
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={handleClose}
      title="Payment for Vehicle Repair"
      size="md"
    >
      <div className="space-y-6">
        {/* Payment Summary */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h3 className="font-medium text-blue-900 mb-2">Payment Summary</h3>
          <div className="text-sm text-blue-800">
            <p><span className="font-medium">Service:</span> Vehicle Repair</p>
            <p><span className="font-medium">Vehicle:</span> {job.vehicleMake} {job.vehicleModel}</p>
            <p><span className="font-medium">Problem:</span> {job.problemDescription.substring(0, 50)}...</p>
            <p className="text-lg font-bold mt-2">Total Amount: Le {job.estimatedCost?.toLocaleString()}</p>
          </div>
        </div>

        {step === 'details' && (
          <div className="space-y-4">
            <h3 className="font-medium text-gray-900">Payment Details</h3>
            
            {/* Payment Breakdown */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-medium text-blue-900 mb-2">Payment Breakdown</h4>
              <div className="text-sm text-blue-800 space-y-1">
                <div className="flex justify-between">
                  <span>Service Cost:</span>
                  <span>Le {job.estimatedCost?.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Platform Fee (15%):</span>
                  <span>Le {Math.round((job.estimatedCost || 0) * 0.15).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Processing Fee (2%):</span>
                  <span>Le {Math.round((job.estimatedCost || 0) * 0.02).toLocaleString()}</span>
                </div>
                <div className="border-t border-blue-300 pt-1 mt-2">
                  <div className="flex justify-between font-medium">
                    <span>Total Amount:</span>
                    <span>Le {Math.round((job.estimatedCost || 0) * 1.17).toLocaleString()}</span>
                  </div>
                </div>
                <div className="text-xs text-blue-600 mt-2">
                  Mechanic receives: Le {Math.round((job.estimatedCost || 0) * 0.85).toLocaleString()}
                </div>
              </div>
            </div>

            <Input
              label="Phone Number"
              type="tel"
              icon={Smartphone}
              value={paymentData.phoneNumber}
              onChange={(value) => setPaymentData(prev => ({ ...prev, phoneNumber: value }))}
              placeholder="Enter your phone number"
              required
            />

            <Input
              label="Full Name"
              icon={CreditCard}
              value={paymentData.fullName}
              onChange={(value) => setPaymentData(prev => ({ ...prev, fullName: value }))}
              placeholder="Enter your full name"
              required
            />

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Payment Method <span className="text-red-500">*</span>
              </label>
              <div className="grid grid-cols-1 gap-2">
                {paymentMethods.map((method) => (
                  <button
                    key={method.id}
                    type="button"
                    onClick={() => setPaymentData(prev => ({ ...prev, paymentMethod: method.id }))}
                    className={`p-3 rounded-lg border-2 text-left transition-colors ${
                      paymentData.paymentMethod === method.id
                        ? `border-${method.color}-500 bg-${method.color}-50`
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <span className="text-lg">{method.icon}</span>
                      <span className="font-medium">{method.name}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <Input
              label="4-Digit PIN"
              type="password"
              icon={Lock}
              value={paymentData.pin}
              onChange={(value) => setPaymentData(prev => ({ ...prev, pin: value.replace(/\D/g, '').slice(0, 4) }))}
              placeholder="Enter your 4-digit PIN"
              maxLength={4}
              required
            />

            <Button
              onClick={handlePaymentSubmit}
              variant="primary"
              fullWidth
              loading={isProcessing}
              disabled={!paymentData.phoneNumber || !paymentData.fullName || paymentData.pin.length !== 4}
            >
              {isProcessing ? 'Processing Payment...' : `Pay Le ${job.estimatedCost?.toLocaleString()}`}
            </Button>
          </div>
        )}

        {step === 'verification' && (
          <div className="space-y-4">
            <div className="text-center">
              <div className="h-16 w-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Smartphone className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="font-medium text-gray-900 mb-2">Verification Required</h3>
              <p className="text-sm text-gray-600">
                We've sent a 6-digit verification code to your phone number ending in 
                <span className="font-medium"> ***{paymentData.phoneNumber.slice(-3)}</span>
              </p>
            </div>

            <Input
              label="Verification Code"
              type="text"
              icon={Lock}
              value={verificationCode}
              onChange={(value) => setVerificationCode(value.replace(/\D/g, '').slice(0, 6))}
              placeholder="Enter 6-digit code"
              maxLength={6}
              required
            />

            <div className="text-xs text-gray-500 text-center">
              Didn't receive the code? Check your SMS messages or wait 60 seconds to resend.
            </div>

            <Button
              onClick={handleVerificationSubmit}
              variant="primary"
              fullWidth
              loading={isProcessing}
              disabled={verificationCode.length !== 6}
            >
              {isProcessing ? 'Verifying...' : 'Verify & Complete Payment'}
            </Button>
          </div>
        )}

        {step === 'success' && (
          <div className="text-center space-y-4">
            <div className="h-16 w-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="font-medium text-gray-900">Payment Successful!</h3>
            <p className="text-sm text-gray-600">
              Your payment of <span className="font-medium">Le {job.estimatedCost?.toLocaleString()}</span> has been processed successfully.
              The mechanic has been notified and will receive the payment.
            </p>
            <div className="bg-green-50 border border-green-200 rounded-lg p-3">
              <p className="text-sm text-green-800">
                <span className="font-medium">Transaction ID:</span> TXN{Date.now()}
              </p>
              <p className="text-sm text-green-800">
                <span className="font-medium">Payment Method:</span> {paymentMethods.find(m => m.id === paymentData.paymentMethod)?.name}
              </p>
            </div>
            <Button
              onClick={handleClose}
              variant="primary"
              fullWidth
            >
              Close
            </Button>
          </div>
        )}
      </div>
    </Modal>
  );
};

export default PaymentModal;