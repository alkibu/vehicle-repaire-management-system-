import React, { useState, useEffect } from 'react';
import { Calendar, Download, FileText, Filter, TrendingUp, DollarSign, Clock, CheckCircle, FileDown } from 'lucide-react';
import { ServiceRequest, Payment } from '../../types';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Card from '../ui/Card';

interface ActivityReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  userRole: 'driver' | 'mechanic' | 'admin';
  userId?: string;
}

const ActivityReportModal: React.FC<ActivityReportModalProps> = ({
  isOpen,
  onClose,
  userRole,
  userId,
}) => {
  const [reportType, setReportType] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [reportData, setReportData] = useState<any>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    if (isOpen) {
      generateReport();
    }
  }, [isOpen, reportType, selectedDate, userId]);

  const generateReport = async () => {
    setIsGenerating(true);
    
    // Simulate report generation delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    const requests = JSON.parse(localStorage.getItem('serviceRequests') || '[]');
    const payments = JSON.parse(localStorage.getItem('payments') || '[]');
    const users = JSON.parse(localStorage.getItem('users') || '[]');

    let filteredRequests: ServiceRequest[] = [];
    let filteredPayments: Payment[] = [];

    const startDate = new Date(selectedDate);
    const endDate = new Date(selectedDate);

    // Set date range based on report type
    if (reportType === 'weekly') {
      startDate.setDate(startDate.getDate() - startDate.getDay()); // Start of week
      endDate.setDate(startDate.getDate() + 6); // End of week
    } else if (reportType === 'monthly') {
      startDate.setDate(1); // Start of month
      endDate.setMonth(endDate.getMonth() + 1);
      endDate.setDate(0); // End of month
    }

    // Filter data based on user role and date range
    if (userRole === 'admin') {
      filteredRequests = requests.filter((r: ServiceRequest) => {
        const requestDate = new Date(r.createdAt);
        return requestDate >= startDate && requestDate <= endDate;
      });
      filteredPayments = payments.filter((p: Payment) => {
        const paymentDate = new Date(p.timestamp);
        return paymentDate >= startDate && paymentDate <= endDate;
      });
    } else {
      const userIdField = userRole === 'driver' ? 'driverId' : 'mechanicId';
      filteredRequests = requests.filter((r: ServiceRequest) => {
        const requestDate = new Date(r.createdAt);
        return r[userIdField] === userId && requestDate >= startDate && requestDate <= endDate;
      });
      filteredPayments = payments.filter((p: Payment) => {
        const paymentDate = new Date(p.timestamp);
        return p[userIdField] === userId && paymentDate >= startDate && paymentDate <= endDate;
      });
    }

    // Calculate statistics
    const stats = {
      totalRequests: filteredRequests.length,
      completedRequests: filteredRequests.filter(r => r.status === 'completed').length,
      pendingRequests: filteredRequests.filter(r => ['pending', 'accepted', 'en_route', 'on_site'].includes(r.status)).length,
      rejectedRequests: filteredRequests.filter(r => r.status === 'rejected').length,
      totalRevenue: filteredPayments.reduce((sum, p) => sum + p.amount, 0),
      averageJobValue: filteredRequests.length > 0 ? 
        filteredRequests.reduce((sum, r) => sum + (r.estimatedCost || 0), 0) / filteredRequests.length : 0,
      completionRate: filteredRequests.length > 0 ? 
        (filteredRequests.filter(r => r.status === 'completed').length / filteredRequests.length) * 100 : 0,
    };

    // Group data by date for charts
    const dailyData = {};
    filteredRequests.forEach(request => {
      const date = new Date(request.createdAt).toDateString();
      if (!dailyData[date]) {
        dailyData[date] = { requests: 0, completed: 0, revenue: 0 };
      }
      dailyData[date].requests++;
      if (request.status === 'completed') {
        dailyData[date].completed++;
      }
    });

    filteredPayments.forEach(payment => {
      const date = new Date(payment.timestamp).toDateString();
      if (!dailyData[date]) {
        dailyData[date] = { requests: 0, completed: 0, revenue: 0 };
      }
      dailyData[date].revenue += payment.amount;
    });

    setReportData({
      stats,
      requests: filteredRequests,
      payments: filteredPayments,
      dailyData,
      dateRange: {
        start: startDate.toDateString(),
        end: endDate.toDateString(),
      },
    });

    setIsGenerating(false);
  };

  const downloadReport = () => {
    if (!reportData) return;

    // Create Word document content with proper formatting
    const reportContent = `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>On-Road Assist - Activity Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
        .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 30px; }
        .title { font-size: 24px; font-weight: bold; color: #2563eb; margin-bottom: 10px; }
        .subtitle { font-size: 18px; color: #666; }
        .section { margin: 30px 0; }
        .section-title { font-size: 16px; font-weight: bold; color: #333; border-bottom: 1px solid #ccc; padding-bottom: 5px; margin-bottom: 15px; }
        .stats-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin: 20px 0; }
        .stat-item { padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
        .stat-label { font-weight: bold; color: #555; }
        .stat-value { font-size: 18px; color: #2563eb; font-weight: bold; }
        .item-list { margin: 10px 0; }
        .item { margin: 10px 0; padding: 10px; border-left: 3px solid #2563eb; background: #f8f9fa; }
        .currency { color: #059669; font-weight: bold; }
        .footer { margin-top: 50px; text-align: center; font-size: 12px; color: #666; border-top: 1px solid #ccc; padding-top: 20px; }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">ON-ROAD ASSIST</div>
        <div class="subtitle">Vehicle Repair Management System</div>
        <div class="subtitle">${userRole.toUpperCase()} ACTIVITY REPORT</div>
    </div>
    
    <div class="section">
        <div class="section-title">REPORT INFORMATION</div>
        <p><strong>Generated:</strong> ${new Date().toLocaleString()}</p>
        <p><strong>Report Type:</strong> ${reportType.charAt(0).toUpperCase() + reportType.slice(1)}</p>
        <p><strong>Date Range:</strong> ${reportData.dateRange.start} - ${reportData.dateRange.end}</p>
        <p><strong>User Role:</strong> ${userRole.toUpperCase()}</p>
    </div>

    <div class="section">
        <div class="section-title">SUMMARY STATISTICS</div>
        <div class="stats-grid">
            <div class="stat-item">
                <div class="stat-label">Total Requests</div>
                <div class="stat-value">${reportData.stats.totalRequests}</div>
            </div>
            <div class="stat-item">
                <div class="stat-label">Completed Requests</div>
                <div class="stat-value">${reportData.stats.completedRequests}</div>
            </div>
            <div class="stat-item">
                <div class="stat-label">Pending Requests</div>
                <div class="stat-value">${reportData.stats.pendingRequests}</div>
            </div>
            <div class="stat-item">
                <div class="stat-label">Total Revenue</div>
                <div class="stat-value currency">Le ${reportData.stats.totalRevenue.toLocaleString()}</div>
            </div>
            <div class="stat-item">
                <div class="stat-label">Average Job Value</div>
                <div class="stat-value currency">Le ${reportData.stats.averageJobValue.toLocaleString()}</div>
            </div>
            <div class="stat-item">
                <div class="stat-label">Completion Rate</div>
                <div class="stat-value">${reportData.stats.completionRate.toFixed(1)}%</div>
            </div>
        </div>
    </div>

    <div class="section">
        <div class="section-title">DETAILED REQUESTS</div>
        <div class="item-list">
            ${reportData.requests.map((request: ServiceRequest, index: number) => `
                <div class="item">
                    <strong>${index + 1}. Request ID:</strong> ${request.id}<br>
                    <strong>Date:</strong> ${new Date(request.createdAt).toLocaleString()}<br>
                    <strong>Vehicle:</strong> ${request.vehicleMake} ${request.vehicleModel} (${request.vehicleType})<br>
                    <strong>Problem:</strong> ${request.problemDescription}<br>
                    <strong>Status:</strong> ${request.status.toUpperCase()}<br>
                    <strong>Cost:</strong> <span class="currency">Le ${(request.estimatedCost || 0).toLocaleString()}</span><br>
                    ${request.status === 'rejected' && request.rejectionReason ? `<strong>Rejection Reason:</strong> ${request.rejectionReason}<br>` : ''}
                </div>
            `).join('')}
        </div>
    </div>

    ${reportData.payments.length > 0 ? `
    <div class="section">
        <div class="section-title">PAYMENT HISTORY</div>
        <div class="item-list">
            ${reportData.payments.map((payment: Payment, index: number) => `
                <div class="item">
                    <strong>${index + 1}. Payment ID:</strong> ${payment.id}<br>
                    <strong>Date:</strong> ${new Date(payment.timestamp).toLocaleString()}<br>
                    <strong>Amount:</strong> <span class="currency">Le ${payment.amount.toLocaleString()}</span><br>
                    <strong>Method:</strong> ${payment.method}<br>
                    <strong>Transaction ID:</strong> ${payment.transactionId}<br>
                    <strong>Status:</strong> ${payment.status.toUpperCase()}<br>
                </div>
            `).join('')}
        </div>
    </div>
    ` : ''}

    <div class="section">
        <div class="section-title">DAILY BREAKDOWN</div>
        <div class="item-list">
            ${Object.entries(reportData.dailyData).map(([date, data]: [string, any]) => `
                <div class="item">
                    <strong>${date}:</strong><br>
                    • Requests: ${data.requests}<br>
                    • Completed: ${data.completed}<br>
                    • Revenue: <span class="currency">Le ${data.revenue.toLocaleString()}</span>
                </div>
            `).join('')}
        </div>
    </div>
    
    <div class="footer">
        <p><strong>On-Road Assist</strong> - Vehicle Repair Management System</p>
        <p>Connecting drivers and mechanics on the Freetown to Mile 91 highway</p>
        <p>Report generated on ${new Date().toLocaleString()}</p>
    </div>
</body>
</html>`;

    const blob = new Blob([reportContent], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `OnRoad-Assist-${userRole}-report-${reportType}-${selectedDate}.doc`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getReportTypeOptions = () => {
    if (userRole === 'driver') {
      return [{ value: 'daily', label: 'Daily Report' }];
    }
    return [
      { value: 'daily', label: 'Daily Report' },
      { value: 'weekly', label: 'Weekly Report' },
      { value: 'monthly', label: 'Monthly Report' },
    ];
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`${userRole.charAt(0).toUpperCase() + userRole.slice(1)} Activity Report`}
      size="xl"
    >
      <div className="space-y-6">
        {/* Report Controls */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Report Type
            </label>
            <select
              value={reportType}
              onChange={(e) => setReportType(e.target.value as 'daily' | 'weekly' | 'monthly')}
              className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              {getReportTypeOptions().map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {reportType === 'daily' ? 'Date' : reportType === 'weekly' ? 'Week of' : 'Month of'}
            </label>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-end">
            <Button
              onClick={downloadReport}
              variant="primary"
              icon={FileDown}
              disabled={!reportData || isGenerating}
              fullWidth
            >
              Download Word Report
            </Button>
          </div>
        </div>

        {isGenerating ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Generating report...</p>
          </div>
        ) : reportData ? (
          <div className="space-y-6">
            {/* Summary Statistics */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Summary Statistics</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card>
                  <div className="flex items-center">
                    <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <FileText className="h-6 w-6 text-blue-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Total Requests</p>
                      <p className="text-2xl font-bold text-gray-900">{reportData.stats.totalRequests}</p>
                    </div>
                  </div>
                </Card>

                <Card>
                  <div className="flex items-center">
                    <div className="h-12 w-12 bg-green-100 rounded-full flex items-center justify-center">
                      <CheckCircle className="h-6 w-6 text-green-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Completed</p>
                      <p className="text-2xl font-bold text-gray-900">{reportData.stats.completedRequests}</p>
                    </div>
                  </div>
                </Card>

                <Card>
                  <div className="flex items-center">
                    <div className="h-12 w-12 bg-purple-100 rounded-full flex items-center justify-center">
                      <DollarSign className="h-6 w-6 text-purple-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Total Revenue</p>
                      <p className="text-2xl font-bold text-gray-900">Le {reportData.stats.totalRevenue.toLocaleString()}</p>
                    </div>
                  </div>
                </Card>

                <Card>
                  <div className="flex items-center">
                    <div className="h-12 w-12 bg-orange-100 rounded-full flex items-center justify-center">
                      <TrendingUp className="h-6 w-6 text-orange-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Success Rate</p>
                      <p className="text-2xl font-bold text-gray-900">{reportData.stats.completionRate.toFixed(1)}%</p>
                    </div>
                  </div>
                </Card>
              </div>
            </div>

            {/* Date Range Info */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center space-x-2">
                <Calendar className="h-5 w-5 text-blue-600" />
                <span className="font-medium text-blue-900">
                  Report Period: {reportData.dateRange.start} - {reportData.dateRange.end}
                </span>
              </div>
            </div>

            {/* Recent Requests */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Requests</h3>
              <div className="space-y-3 max-h-60 overflow-y-auto">
                {reportData.requests.slice(0, 10).map((request: ServiceRequest, index: number) => (
                  <div key={request.id} className="border border-gray-200 rounded-lg p-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <span className="text-sm font-medium text-gray-900">
                            Request #{index + 1}
                          </span>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            request.status === 'completed' ? 'bg-green-100 text-green-700' :
                            request.status === 'rejected' ? 'bg-red-100 text-red-700' :
                            'bg-yellow-100 text-yellow-700'
                          }`}>
                            {request.status.toUpperCase()}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600">
                          {request.vehicleMake} {request.vehicleModel} - {request.problemDescription.substring(0, 50)}...
                        </p>
                        <p className="text-xs text-gray-500">
                          {new Date(request.createdAt).toLocaleString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-gray-900">Le {(request.estimatedCost || 0).toLocaleString()}</p>
                      </div>
                    </div>
                  </div>
                ))}
                
                {reportData.requests.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <FileText className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                    <p>No requests found for this period</p>
                  </div>
                )}
              </div>
            </div>

            {/* Payment History */}
            {reportData.payments.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Payment History</h3>
                <div className="space-y-3 max-h-60 overflow-y-auto">
                  {reportData.payments.slice(0, 10).map((payment: Payment, index: number) => (
                    <div key={payment.id} className="border border-gray-200 rounded-lg p-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <span className="text-sm font-medium text-gray-900">
                              Payment #{index + 1}
                            </span>
                            <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                              {payment.status.toUpperCase()}
                            </span>
                          </div>
                          <p className="text-sm text-gray-600">{payment.method}</p>
                          <p className="text-xs text-gray-500">
                            {new Date(payment.timestamp).toLocaleString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium text-gray-900">Le {payment.amount.toLocaleString()}</p>
                          <p className="text-xs text-gray-500">{payment.transactionId}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Daily Breakdown Chart */}
            {Object.keys(reportData.dailyData).length > 0 && (
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Daily Breakdown</h3>
                <div className="space-y-2">
                  {Object.entries(reportData.dailyData).map(([date, data]: [string, any]) => (
                    <div key={date} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <span className="text-sm font-medium text-gray-900">{date}</span>
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <span>Requests: {data.requests}</span>
                        <span>Completed: {data.completed}</span>
                        <span>Revenue: Le {data.revenue.toLocaleString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : null}
      </div>
    </Modal>
  );
};

export default ActivityReportModal;