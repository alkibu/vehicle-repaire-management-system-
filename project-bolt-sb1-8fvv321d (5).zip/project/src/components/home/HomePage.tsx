import React from 'react';
import { Link } from 'react-router-dom';
import { Car, Wrench, Shield, MapPin, Clock, Phone, CheckCircle, Star } from 'lucide-react';
import Card from '../ui/Card';
import Button from '../ui/Button';

const HomePage: React.FC = () => {
  const features = [
    {
      icon: MapPin,
      title: 'Real-Time GPS Tracking',
      description: 'Track mechanic location and get live updates on their arrival time.',
    },
    {
      icon: Clock,
      title: '24/7 Availability',
      description: 'Get help whenever you need it, day or night on the highway.',
    },
    {
      icon: Phone,
      title: 'Direct Communication',
      description: 'Communicate directly with your assigned mechanic for updates.',
    },
    {
      icon: CheckCircle,
      title: 'Verified Mechanics',
      description: 'All mechanics are verified and approved by our admin team.',
    },
  ];

  const testimonials = [
    {
      name: 'Sarah Johnson',
      role: 'Driver',
      content: 'Amazing service! My car broke down on Mile 91 highway and I got help within 30 minutes.',
      rating: 5,
    },
    {
      name: 'Mike Chen',
      role: 'Mechanic',
      content: 'Great platform to connect with drivers who need help. Easy to use and reliable.',
      rating: 5,
    },
    {
      name: 'David Williams',
      role: 'Driver',
      content: 'The real-time tracking feature is incredible. I could see exactly when help was coming.',
      rating: 5,
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="h-8 w-8 bg-blue-600 rounded-full flex items-center justify-center">
                <Car className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">On-Road Assist</span>
              <span className="text-xl font-bold text-gray-900">Vehicle RMS</span>
            </div>
            
            <div className="flex items-center space-x-4">
              <Link to="/login" className="text-gray-600 hover:text-gray-900 font-medium">
                Login
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-indigo-100 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Professional Vehicle Repair Management
            </h1>
            <p className="text-lg text-gray-600 mb-6 max-w-2xl mx-auto">
              Advanced vehicle repair management system connecting drivers with verified mechanics. 
              Real-time GPS tracking, instant communication, and comprehensive service management.
            </p>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">How It Works</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Simple steps to get the help you need or provide services as a mechanic.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {/* For Drivers */}
            <div className="text-center">
              <div className="h-16 w-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Car className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Emergency Service</h3>
              <div className="space-y-3 text-gray-600">
                <p className="flex items-center"><span className="bg-blue-100 text-blue-600 rounded-full h-6 w-6 flex items-center justify-center text-sm font-medium mr-3">1</span>See available mechanics instantly</p>
                <p className="flex items-center"><span className="bg-blue-100 text-blue-600 rounded-full h-6 w-6 flex items-center justify-center text-sm font-medium mr-3">2</span>Book service with phone & email</p>
                <p className="flex items-center"><span className="bg-blue-100 text-blue-600 rounded-full h-6 w-6 flex items-center justify-center text-sm font-medium mr-3">3</span>Get SMS/email with tracking link</p>
              </div>
            </div>

            {/* For Mechanics */}
            <div className="text-center">
              <div className="h-16 w-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Wrench className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">For Mechanics</h3>
              <div className="space-y-3 text-gray-600">
                <p className="flex items-center"><span className="bg-green-100 text-green-600 rounded-full h-6 w-6 flex items-center justify-center text-sm font-medium mr-3">1</span>Register and wait for admin approval</p>
                <p className="flex items-center"><span className="bg-green-100 text-green-600 rounded-full h-6 w-6 flex items-center justify-center text-sm font-medium mr-3">2</span>Go online to receive job requests</p>
                <p className="flex items-center"><span className="bg-green-100 text-green-600 rounded-full h-6 w-6 flex items-center justify-center text-sm font-medium mr-3">3</span>Accept jobs and help drivers</p>
              </div>
            </div>

            {/* Quality Control */}
            <div className="text-center">
              <div className="h-16 w-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Shield className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Quality Assured</h3>
              <div className="space-y-3 text-gray-600">
                <p className="flex items-center"><span className="bg-purple-100 text-purple-600 rounded-full h-6 w-6 flex items-center justify-center text-sm font-medium mr-3">1</span>Admin reviews all mechanic applications</p>
                <p className="flex items-center"><span className="bg-purple-100 text-purple-600 rounded-full h-6 w-6 flex items-center justify-center text-sm font-medium mr-3">2</span>Only verified mechanics can provide services</p>
                <p className="flex items-center"><span className="bg-purple-100 text-purple-600 rounded-full h-6 w-6 flex items-center justify-center text-sm font-medium mr-3">3</span>Continuous monitoring and quality control</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Choose On-Road Assist?</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Advanced features designed to make roadside assistance fast, reliable, and transparent.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">What Our Users Say</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Real experiences from drivers and mechanics using our platform.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="text-center">
                <div className="flex justify-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4 italic">"{testimonial.content}"</p>
                <div>
                  <p className="font-semibold text-gray-900">{testimonial.name}</p>
                  <p className="text-sm text-gray-500">{testimonial.role}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to Get Started?</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Join thousands of drivers and mechanics who trust On-Road Assist for reliable roadside assistance.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/driver-booking">
              <Button size="lg" variant="secondary" icon={Car} className="w-full sm:w-auto">
                Book Vehicle Service
              </Button>
            </Link>
            <Link to="/mechanic/signup">
              <Button size="lg" variant="secondary" icon={Wrench} className="w-full sm:w-auto">
                Join as Mechanic
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="h-8 w-8 bg-blue-600 rounded-full flex items-center justify-center">
                <Car className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold text-white">Vehicle RMS</span>
            </div>
            
            <div className="text-gray-400 text-sm">
              © 2024 Vehicle RMS. All rights reserved.
            </div>
          </div>
          
          <div className="mt-8 pt-8 border-t border-gray-800 text-center text-gray-400 text-sm">
            <p>Vehicle Repair Management System for Sierra Leone</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;