export type UserRole = 'driver' | 'mechanic' | 'admin';

export interface User {
  id: string;
  username: string;
  email: string;
  phone: string;
  role: UserRole;
  isApproved?: boolean;
  isSuspended?: boolean;
  createdAt: string;
  updatedAt?: string;
  currentLocation?: {
    lat: number;
    lng: number;
  };
  balance?: number;
}

export interface Driver extends User {
  role: 'driver';
  vehicleType: string;
}

export interface Mechanic extends User {
  role: 'mechanic';
  businessName: string;
  specialties: string[];
  workshopAddress: string;
  isOnline: boolean;
  currentLocation?: {
    lat: number;
    lng: number;
  };
}

export interface Admin extends User {
  role: 'admin';
  isSuperUser: boolean;
}

export interface ServiceRequest {
  id: string;
  driverId: string;
  mechanicId?: string;
  vehicleType: string;
  vehicleMake?: string;
  vehicleModel?: string;
  vehicleYear?: string;
  problemDescription: string;
  urgencyLevel?: 'low' | 'medium' | 'high' | 'emergency';
  breakdownLocation: {
    lat: number;
    lng: number;
    address: string;
  };
  photos?: string[];
  audioExplanation?: string;
  additionalNotes?: string;
  status: 'pending' | 'accepted' | 'en_route' | 'on_site' | 'completed' | 'rejected';
  rejectionReason?: string;
  estimatedCost?: number;
  isPaid?: boolean;
  paidAt?: string;
  createdAt: string;
  updatedAt: string;
  notificationSent?: boolean;
  completionNotificationSent?: boolean;
}

export interface LocationData {
  lat: number;
  lng: number;
  accuracy: number;
  timestamp: number;
}

export interface Payment {
  id: string;
  driverId: string;
  mechanicId: string;
  jobId: string;
  amount: number; // Amount in Sierra Leone Leones (SLE)
  method: string;
  transactionId: string;
  timestamp: string;
  status: 'pending' | 'completed' | 'failed';
  verificationCode?: string;
  notificationSent?: boolean;
}

export interface Notification {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning' | 'payment' | 'rejection' | 'completion';
  title: string;
  message: string;
  timestamp: string;
  read?: boolean;
}

// No-Login Booking System Types
export interface GuestBooking {
  id: string; // Tracking ID (e.g., VRM-2024-AB123)
  phoneNumber: string;
  vehicleType: string;
  problemDescription: string;
  urgencyLevel: 'low' | 'medium' | 'high' | 'emergency';
  breakdownLocation: {
    lat: number;
    lng: number;
    address: string;
  };
  mechanicId: string;
  status: 'pending' | 'accepted' | 'en_route' | 'arrived' | 'working' | 'completed' | 'rejected';
  estimatedCost: number;
  createdAt: string;
  updatedAt: string;
  rejectionReason?: string;
  completionNotes?: string;
  photos?: string[];
  smsLinkSent?: boolean;
  trackingUrl?: string;
}

export interface GuestDriver {
  phoneNumber: string;
  currentLocation: {
    lat: number;
    lng: number;
  };
  sessionId: string;
  lastActivity: string;
}