// Complete Frontend API Integration with Node.js Backend
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api';

export interface BreakdownRequest {
  id: string;
  trackingId: string;
  driverPhone: string;
  driverEmail: string;
  driverName?: string;
  vehicleType: string;
  vehicleMake?: string;
  vehicleModel?: string;
  vehicleYear?: string;
  problemDescription: string;
  urgencyLevel: 'low' | 'medium' | 'high' | 'emergency';
  additionalNotes?: string;
  location: {
    lat: number;
    lng: number;
    address: string;
  };
  photos?: string[];
  audioExplanation?: string;
  mechanic: {
    id: string;
    name: string;
    businessName: string;
    phone: string;
    photo: string;
    rating: number;
    specializations: string[];
    currentLocation?: { lat: number; lng: number };
  };
  status: 'pending' | 'accepted' | 'rejected' | 'en_route' | 'arrived' | 'working' | 'completed';
  rejectionReason?: string;
  estimatedCost: number;
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
  statusHistory: Array<{
    status: string;
    message: string;
    timestamp: string;
  }>;
  distance?: string;
  estimatedArrival?: string;
  trackingUrl?: string;
  lastUpdate?: string;
}

export interface Mechanic {
  id: string;
  username: string;
  email: string;
  phone: string;
  businessName: string;
  workshopAddress: string;
  specialties: string[];
  isOnline: boolean;
  hourlyRate: number;
  rating: number;
  totalJobs: number;
  currentLocation?: { lat: number; lng: number };
  distance?: number;
  etaMinutes?: number;
  balance?: number;
}

class ApiService {
  private baseURL: string;

  constructor() {
    this.baseURL = API_BASE_URL;
  }

  // Helper method for API calls
  private async makeRequest(endpoint: string, options: RequestInit = {}): Promise<any> {
    const url = `${this.baseURL}${endpoint}`;
    
    const defaultHeaders: Record<string, string> = {};

    // Only add Content-Type for JSON requests
    if (options.body && typeof options.body === 'string') {
      defaultHeaders['Content-Type'] = 'application/json';
    }

    // Add auth token if available
    const token = localStorage.getItem('access_token');
    if (token) {
      defaultHeaders['Authorization'] = `Bearer ${token}`;
    }

    const config: RequestInit = {
      headers: { ...defaultHeaders, ...options.headers },
      ...options,
    };

    try {
      const response = await fetch(url, config);
      
      if (!response.ok) {
        const errorText = await response.text();
        let errorMessage = `HTTP error! status: ${response.status}`;
        
        try {
          const errorData = JSON.parse(errorText);
          errorMessage = errorData.message || errorData.detail || errorMessage;
        } catch {
          errorMessage = errorText || errorMessage;
        }
        
        throw new Error(errorMessage);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error(`API Error (${endpoint}):`, error);
      throw error;
    }
  }

  // Authentication APIs
  async login(email: string, password: string, lat?: number, lng?: number) {
    const payload: any = { email, password };
    if (lat && lng) {
      payload.lat = lat;
      payload.lng = lng;
    }

    const response = await this.makeRequest('/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    });

    if (response.success) {
      localStorage.setItem('access_token', response.tokens.access);
      localStorage.setItem('refresh_token', response.tokens.refresh);
      localStorage.setItem('user', JSON.stringify(response.user));
    }

    return response;
  }

  async logout() {
    const refreshToken = localStorage.getItem('refresh_token');
    if (refreshToken) {
      try {
        await this.makeRequest('/auth/logout', {
          method: 'POST',
          body: JSON.stringify({ refresh: refreshToken }),
        });
      } catch (error) {
        console.error('Logout error:', error);
      }
    }
    
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    localStorage.removeItem('user');
  }

  // Mechanic APIs
  async getAvailableMechanics(lat: number, lng: number): Promise<Mechanic[]> {
    try {
      const response = await this.makeRequest(`/mechanics/available?lat=${lat}&lng=${lng}`);
      return response.mechanics || [];
    } catch (error) {
      console.error('Error fetching mechanics:', error);
      return [];
    }
  }

  async getMechanicDetail(mechanicId: string, lat?: number, lng?: number): Promise<Mechanic | null> {
    try {
      const params = lat && lng ? `?lat=${lat}&lng=${lng}` : '';
      const response = await this.makeRequest(`/mechanics/${mechanicId}${params}`);
      return response.mechanic;
    } catch (error) {
      console.error('Error fetching mechanic detail:', error);
      return null;
    }
  }

  // Booking APIs
  async createBreakdownRequest(requestData: any): Promise<{ trackingId: string; trackingUrl: string }> {
    const formData = new FormData();
    
    // Add text fields
    Object.keys(requestData).forEach(key => {
      if (key !== 'photos' && key !== 'audio' && requestData[key] !== null && requestData[key] !== undefined) {
        if (key === 'mechanic') {
          formData.append('mechanicId', requestData[key].id || requestData[key]);
        } else if (key === 'location') {
          formData.append('breakdownLat', requestData[key].lat.toString());
          formData.append('breakdownLng', requestData[key].lng.toString());
          formData.append('breakdownAddress', requestData[key].address || '');
        } else {
          formData.append(key, requestData[key].toString());
        }
      }
    });

    // Add photos as base64 strings converted to files
    if (requestData.photos && requestData.photos.length > 0) {
      requestData.photos.forEach((photoBase64: string, index: number) => {
        try {
          // Convert base64 to blob
          const byteCharacters = atob(photoBase64.split(',')[1]);
          const byteNumbers = new Array(byteCharacters.length);
          for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
          }
          const byteArray = new Uint8Array(byteNumbers);
          const blob = new Blob([byteArray], { type: 'image/jpeg' });
          const file = new File([blob], `photo_${index}.jpg`, { type: 'image/jpeg' });
          formData.append('photos', file);
        } catch (error) {
          console.error('Error converting photo:', error);
        }
      });
    }

    // Add audio if provided
    if (requestData.audioExplanation && requestData.audioExplanation.startsWith('blob:')) {
      try {
        const audioResponse = await fetch(requestData.audioExplanation);
        const audioBlob = await audioResponse.blob();
        const audioFile = new File([audioBlob], 'audio_explanation.wav', { type: 'audio/wav' });
        formData.append('audio', audioFile);
      } catch (error) {
        console.error('Error converting audio:', error);
      }
    }

    const response = await fetch(`${this.baseURL}/bookings/create`, {
      method: 'POST',
      body: formData,
    });

    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.message || 'Failed to create breakdown request');
    }

    return data;
  }

  async getMechanicPendingRequests(mechanicId: string): Promise<BreakdownRequest[]> {
    try {
      const response = await this.makeRequest(`/bookings/mechanic/${mechanicId}/pending`);
      return response.requests || [];
    } catch (error) {
      console.error('Error fetching pending requests:', error);
      return [];
    }
  }

  async acceptBreakdownRequest(requestId: string) {
    return await this.makeRequest(`/bookings/${requestId}/accept`, {
      method: 'PATCH',
    });
  }

  async rejectBreakdownRequest(requestId: string, reason: string) {
    return await this.makeRequest(`/bookings/${requestId}/reject`, {
      method: 'PATCH',
      body: JSON.stringify({ reason }),
    });
  }

  async updateRequestStatus(requestId: string, status: string) {
    return await this.makeRequest(`/bookings/${requestId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
  }

  // Tracking APIs
  async getTrackingData(trackingId: string): Promise<BreakdownRequest> {
    const response = await this.makeRequest(`/tracking/${trackingId}`);
    return response.trackingData;
  }

  async updateMechanicLocation(trackingId: string, lat: number, lng: number, accuracy: number = 10) {
    return await this.makeRequest(`/tracking/${trackingId}/location`, {
      method: 'PATCH',
      body: JSON.stringify({ lat, lng, accuracy }),
    });
  }

  // Payment APIs
  async processPayment(requestId: string, paymentData: any) {
    return await this.makeRequest(`/bookings/${requestId}/payment`, {
      method: 'POST',
      body: JSON.stringify(paymentData),
    });
  }

  async verifyPayment(paymentId: string, verificationCode: string) {
    return await this.makeRequest(`/payments/${paymentId}/verify`, {
      method: 'POST',
      body: JSON.stringify({ verificationCode }),
    });
  }

  // Utility APIs
  async testEmail(email: string) {
    return await this.makeRequest('/notifications/test-email', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  }
}

// Export singleton instance
export const apiService = new ApiService();

// Legacy exports for backward compatibility
export const databaseAPI = {
  saveBreakdownRequest: async (request: any) => {
    try {
      return await apiService.createBreakdownRequest(request);
    } catch (error) {
      console.error('Error saving breakdown request:', error);
      throw error;
    }
  },
};

export const mechanicDashboardAPI = {
  getPendingRequests: async (mechanicId: string) => {
    try {
      return await apiService.getMechanicPendingRequests(mechanicId);
    } catch (error) {
      console.error('Error getting pending requests:', error);
      return [];
    }
  },
  acceptRequest: async (requestId: string, mechanicId: string) => {
    try {
      const result = await apiService.acceptBreakdownRequest(requestId);
      return result.success;
    } catch (error) {
      console.error('Error accepting request:', error);
      return false;
    }
  },
  rejectRequest: async (requestId: string, mechanicId: string, reason: string) => {
    try {
      const result = await apiService.rejectBreakdownRequest(requestId, reason);
      return result.success;
    } catch (error) {
      console.error('Error rejecting request:', error);
      return false;
    }
  },
  updateRequestStatus: async (requestId: string, status: string) => {
    try {
      const result = await apiService.updateRequestStatus(requestId, status);
      return result.success;
    } catch (error) {
      console.error('Error updating request status:', error);
      return false;
    }
  },
};

export function generateTrackingId(): string {
  const timestamp = Date.now().toString().slice(-6);
  const random = Math.random().toString(36).substring(2, 5).toUpperCase();
  return `VRM-${new Date().getFullYear()}-${random}${timestamp}`;
}