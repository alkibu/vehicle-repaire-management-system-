import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, UserRole } from '../types';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string, role: UserRole) => Promise<boolean>;
  signup: (userData: any) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
  sessionTimeout: number;
  extendSession: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [sessionTimeout, setSessionTimeout] = useState(0);

  // Session timeout duration (30 minutes)
  const SESSION_DURATION = 30 * 60 * 1000; // 30 minutes in milliseconds
  const WARNING_TIME = 5 * 60 * 1000; // 5 minutes warning

  useEffect(() => {
    // Check for existing session
    const savedUser = localStorage.getItem('currentUser');
    const sessionStart = localStorage.getItem('sessionStart');
    
    if (savedUser && sessionStart) {
      const sessionAge = Date.now() - parseInt(sessionStart);
      
      if (sessionAge < SESSION_DURATION) {
        setUser(JSON.parse(savedUser));
        setSessionTimeout(SESSION_DURATION - sessionAge);
      } else {
        // Session expired
        logout();
      }
    }
    setIsLoading(false);
  }, []);

  useEffect(() => {
    let timeoutId: NodeJS.Timeout;
    let warningId: NodeJS.Timeout;

    if (user && sessionTimeout > 0) {
      // Set warning 5 minutes before session expires
      if (sessionTimeout > WARNING_TIME) {
        warningId = setTimeout(() => {
          const shouldExtend = window.confirm(
            'Your session will expire in 5 minutes. Would you like to extend it?'
          );
          if (shouldExtend) {
            extendSession();
          }
        }, sessionTimeout - WARNING_TIME);
      }

      // Set automatic logout
      timeoutId = setTimeout(() => {
        alert('Your session has expired. You will be logged out.');
        logout();
      }, sessionTimeout);
    }

    return () => {
      if (timeoutId) clearTimeout(timeoutId);
      if (warningId) clearTimeout(warningId);
    };
  }, [user, sessionTimeout]);

  const login = async (email: string, password: string, role: UserRole): Promise<boolean> => {
    setIsLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Get users from localStorage
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const foundUser = users.find((u: User) => u.email === email && u.role === role);
      
      if (!foundUser) {
        setIsLoading(false);
        return false;
      }

      // Check approval status for mechanics
      if (role === 'mechanic' && !foundUser.isApproved) {
        setIsLoading(false);
        throw new Error('Your account is pending admin approval');
      }

      // Admin check for superuser
      if (role === 'admin' && !foundUser.isSuperUser) {
        setIsLoading(false);
        return false;
      }

      // Set session data
      const sessionStart = Date.now().toString();
      setUser(foundUser);
      setSessionTimeout(SESSION_DURATION);
      localStorage.setItem('currentUser', JSON.stringify(foundUser));
      localStorage.setItem('sessionStart', sessionStart);
      localStorage.setItem('lastActivity', sessionStart);
      
      setIsLoading(false);
      return true;
    } catch (error) {
      setIsLoading(false);
      throw error;
    }
  };

  const signup = async (userData: any): Promise<boolean> => {
    setIsLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      
      // Check if user already exists
      const existingUser = users.find((u: User) => u.email === userData.email);
      if (existingUser) {
        setIsLoading(false);
        throw new Error('User with this email already exists');
      }

      const newUser: User = {
        id: Date.now().toString(),
        username: userData.username,
        email: userData.email,
        phone: userData.phone,
        role: userData.role,
        createdAt: new Date().toISOString(),
        ...userData,
        isApproved: userData.role === 'mechanic' ? false : true,
      };

      users.push(newUser);
      localStorage.setItem('users', JSON.stringify(users));

      // Auto-login for drivers, mechanics need approval
      if (userData.role === 'driver') {
        const sessionStart = Date.now().toString();
        setUser(newUser);
        setSessionTimeout(SESSION_DURATION);
        localStorage.setItem('currentUser', JSON.stringify(newUser));
        localStorage.setItem('sessionStart', sessionStart);
        localStorage.setItem('lastActivity', sessionStart);
      }

      setIsLoading(false);
      return true;
    } catch (error) {
      setIsLoading(false);
      throw error;
    }
  };

  const logout = () => {
    // Clear user state
    setUser(null);
    setSessionTimeout(0);
    
    // Clear localStorage
    localStorage.removeItem('currentUser');
    localStorage.removeItem('sessionStart');
    localStorage.removeItem('lastActivity');
    
    // Update user's online status if they were a mechanic
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    if (user && user.role === 'mechanic') {
      const updatedUsers = users.map((u: any) => 
        u.id === user.id ? { ...u, isOnline: false, currentLocation: null } : u
      );
      localStorage.setItem('users', JSON.stringify(updatedUsers));
    }
    
    // Clear any active location tracking
    if (navigator.geolocation) {
      // This will be handled by the LocationContext cleanup
    }
  };

  const extendSession = () => {
    const newSessionStart = Date.now().toString();
    setSessionTimeout(SESSION_DURATION);
    localStorage.setItem('sessionStart', newSessionStart);
    localStorage.setItem('lastActivity', newSessionStart);
  };

  // Track user activity to extend session
  useEffect(() => {
    const trackActivity = () => {
      if (user) {
        localStorage.setItem('lastActivity', Date.now().toString());
      }
    };

    const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click'];
    events.forEach(event => {
      document.addEventListener(event, trackActivity, true);
    });

    return () => {
      events.forEach(event => {
        document.removeEventListener(event, trackActivity, true);
      });
    };
  }, [user]);

  const value = {
    user,
    isAuthenticated: !!user,
    login,
    signup,
    logout,
    isLoading,
    sessionTimeout,
    extendSession,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};