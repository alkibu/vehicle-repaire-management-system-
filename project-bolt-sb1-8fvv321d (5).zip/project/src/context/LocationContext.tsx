import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { LocationData } from '../types';

interface LocationContextType {
  currentLocation: LocationData | null;
  isLocationEnabled: boolean;
  locationError: string | null;
  requestLocation: () => Promise<void>;
  watchLocation: () => void;
  stopWatching: () => void;
  isWatching: boolean;
}

const LocationContext = createContext<LocationContextType | undefined>(undefined);

export const useLocation = () => {
  const context = useContext(LocationContext);
  if (context === undefined) {
    throw new Error('useLocation must be used within a LocationProvider');
  }
  return context;
};

interface LocationProviderProps {
  children: ReactNode;
}

export const LocationProvider: React.FC<LocationProviderProps> = ({ children }) => {
  const [currentLocation, setCurrentLocation] = useState<LocationData | null>(null);
  const [isLocationEnabled, setIsLocationEnabled] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [watchId, setWatchId] = useState<number | null>(null);
  const [isWatching, setIsWatching] = useState(false);

  useEffect(() => {
    if ('geolocation' in navigator) {
      setIsLocationEnabled(true);
    } else {
      setLocationError('Geolocation is not supported by this browser');
    }

    // Cleanup on unmount
    return () => {
      if (watchId !== null) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, []);

  const requestLocation = async (): Promise<void> => {
    if (!isLocationEnabled) {
      throw new Error('Geolocation is not available');
    }

    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const locationData: LocationData = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
            accuracy: position.coords.accuracy,
            timestamp: position.timestamp,
          };
          setCurrentLocation(locationData);
          setLocationError(null);
          resolve();
        },
        (error) => {
          let errorMessage = 'Failed to get location';
          switch (error.code) {
            case error.PERMISSION_DENIED:
              errorMessage = 'Location access denied by user';
              break;
            case error.POSITION_UNAVAILABLE:
              errorMessage = 'Location information is unavailable';
              break;
            case error.TIMEOUT:
              errorMessage = 'Location request timed out';
              break;
          }
          setLocationError(errorMessage);
          reject(new Error(errorMessage));
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 60000,
        }
      );
    });
  };

  const watchLocation = () => {
    if (!isLocationEnabled || watchId !== null) return;

    const id = navigator.geolocation.watchPosition(
      (position) => {
        const locationData: LocationData = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          accuracy: position.coords.accuracy,
          timestamp: position.timestamp,
        };
        setCurrentLocation(locationData);
        setLocationError(null);
      },
      (error) => {
        let errorMessage = 'Failed to track location';
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = 'Location tracking denied by user';
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = 'Location tracking unavailable';
            break;
          case error.TIMEOUT:
            errorMessage = 'Location tracking timed out';
            break;
        }
        setLocationError(errorMessage);
      },
      {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 30000,
      }
    );

    setWatchId(id);
    setIsWatching(true);
  };

  const stopWatching = () => {
    if (watchId !== null) {
      navigator.geolocation.clearWatch(watchId);
      setWatchId(null);
      setIsWatching(false);
    }
  };

  const value = {
    currentLocation,
    isLocationEnabled,
    locationError,
    requestLocation,
    watchLocation,
    stopWatching,
    isWatching,
  };

  return <LocationContext.Provider value={value}>{children}</LocationContext.Provider>;
};