import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { LocationProvider } from './context/LocationContext';
import HomePage from './components/home/HomePage';
import UnifiedLoginForm from './components/auth/UnifiedLoginForm';
import SignupForm from './components/auth/SignupForm';
import DriverDashboard from './components/driver/DriverDashboard';
import MechanicDashboard from './components/mechanic/MechanicDashboard';
import AdminDashboard from './components/admin/AdminDashboard';
import DirectMechanicBooking from './components/driver/DirectMechanicBooking';
import DriverTrackingDashboard from './components/driver/DriverTrackingDashboard';
import TrackingPage from './components/tracking/TrackingPage';

// Protected Route Component
const ProtectedRoute: React.FC<{ children: React.ReactNode; requiredRole: string }> = ({ 
  children, 
  requiredRole 
}) => {
  const { user, isAuthenticated } = useAuth();
  
  if (!isAuthenticated) {
    return <Navigate to="/" replace />;
  }
  
  if (user?.role !== requiredRole) {
    return <Navigate to="/" replace />;
  }
  
  return <>{children}</>;
};

// Initialize demo data
const initializeData = () => {
  const users = localStorage.getItem('users');
  if (!users) {
    // Create demo admin user
    const demoUsers = [
      {
        id: 'admin-1',
        username: 'admin',
        email: 'admin@vehiclerms.com',
        phone: '+1234567890',
        password: 'admin123', // Demo password
        role: 'admin',
        isSuperUser: true,
        isApproved: true,
        isSuspended: false,
        createdAt: new Date().toISOString(),
      }
    ];
    localStorage.setItem('users', JSON.stringify(demoUsers));
  }
};

function App() {
  React.useEffect(() => {
    initializeData();
  }, []);

  return (
    <AuthProvider>
      <LocationProvider>
        <Router>
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<UnifiedLoginForm />} />
            
            {/* Driver No-Login Routes */}
            <Route path="/driver-booking" element={<DirectMechanicBooking />} />
            <Route path="/driver-track/:trackingId" element={<DriverTrackingDashboard />} />
            <Route path="/track/:trackingId" element={<TrackingPage />} />
            
            {/* Driver Routes */}
            <Route path="/driver/signup" element={<SignupForm role="driver" />} />
            <Route 
              path="/driver/dashboard" 
              element={
                <ProtectedRoute requiredRole="driver">
                  <DriverDashboard />
                </ProtectedRoute>
              } 
            />
            
            {/* Mechanic Routes */}
            <Route path="/mechanic/signup" element={<SignupForm role="mechanic" />} />
            <Route 
              path="/mechanic/dashboard" 
              element={
                <ProtectedRoute requiredRole="mechanic">
                  <MechanicDashboard />
                </ProtectedRoute>
              } 
            />
            
            {/* Admin Routes */}
            <Route 
              path="/admin/dashboard" 
              element={
                <ProtectedRoute requiredRole="admin">
                  <AdminDashboard />
                </ProtectedRoute>
              } 
            />
            
            {/* Fallback */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Router>
      </LocationProvider>
    </AuthProvider>
  );
}

export default App;