const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 8000;

// Middleware
app.use(cors({
  origin: ['http://localhost:5173', 'http://127.0.0.1:5173'],
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Static file serving
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Database file path
const DB_FILE = path.join(__dirname, 'database.json');

// Initialize database
const initializeDatabase = () => {
  if (!fs.existsSync(DB_FILE)) {
    const initialData = {
      users: [
        {
          id: 'admin-1',
          username: 'admin',
          email: 'admin@vehiclerms.com',
          phone: '+23276123456',
          password: bcrypt.hashSync('admin123', 10),
          role: 'admin',
          isApproved: true,
          isSuspended: false,
          isSuperUser: true,
          balance: 0,
          createdAt: new Date().toISOString()
        }
      ],
      mechanics: [
        {
          id: 'mech-1',
          userId: 'user-mech-1',
          businessName: 'QuickFix Auto Services',
          username: 'Mohamed Kamara',
          email: 'mohamed@quickfixauto.com',
          phone: '+23276234567',
          password: bcrypt.hashSync('mechanic123', 10),
          role: 'mechanic',
          workshopAddress: 'Kissy Street, Freetown, Sierra Leone',
          specialties: ['Engine Repair', 'Electrical Systems', 'Tire Services', 'Oil Change'],
          isOnline: true,
          isApproved: true,
          isSuspended: false,
          hourlyRate: 85000,
          rating: 4.8,
          totalJobs: 25,
          currentLocation: { lat: 8.4657, lng: -13.2317 },
          balance: 450000,
          createdAt: new Date().toISOString()
        },
        {
          id: 'mech-2',
          userId: 'user-mech-2',
          businessName: 'Reliable Motors',
          username: 'Fatima Sesay',
          email: 'fatima@reliablemotors.com',
          phone: '+23276345678',
          password: bcrypt.hashSync('mechanic123', 10),
          role: 'mechanic',
          workshopAddress: 'Wilberforce Street, Freetown, Sierra Leone',
          specialties: ['Brakes', 'Transmission', 'Air Conditioning', 'Suspension'],
          isOnline: true,
          isApproved: true,
          isSuspended: false,
          hourlyRate: 90000,
          rating: 4.9,
          totalJobs: 32,
          currentLocation: { lat: 8.4700, lng: -13.2400 },
          balance: 680000,
          createdAt: new Date().toISOString()
        },
        {
          id: 'mech-3',
          userId: 'user-mech-3',
          businessName: 'Express Auto Repair',
          username: 'Ibrahim Bangura',
          email: 'ibrahim@expressauto.com',
          phone: '+23276456789',
          password: bcrypt.hashSync('mechanic123', 10),
          role: 'mechanic',
          workshopAddress: 'Circular Road, Freetown, Sierra Leone',
          specialties: ['Engine Repair', 'Suspension', 'Electrical Systems', 'Battery Replacement'],
          isOnline: true,
          isApproved: true,
          isSuspended: false,
          hourlyRate: 80000,
          rating: 4.7,
          totalJobs: 18,
          currentLocation: { lat: 8.4600, lng: -13.2200 },
          balance: 320000,
          createdAt: new Date().toISOString()
        }
      ],
      breakdownRequests: [],
      payments: [],
      statusHistory: [],
      trackingSessions: []
    };
    
    fs.writeFileSync(DB_FILE, JSON.stringify(initialData, null, 2));
    console.log('✅ Database initialized with sample data');
  }
};

// Database helper functions
const readDatabase = () => {
  try {
    const data = fs.readFileSync(DB_FILE, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading database:', error);
    return { users: [], mechanics: [], breakdownRequests: [], payments: [], statusHistory: [], trackingSessions: [] };
  }
};

const writeDatabase = (data) => {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error('Error writing database:', error);
    return false;
  }
};

// Email service setup
const createEmailTransporter = () => {
  if (process.env.NODE_ENV === 'production') {
    return nodemailer.createTransporter({
      service: 'gmail',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      }
    });
  }
  
  // Development mode - log emails to console
  return {
    sendMail: (options) => {
      console.log('\n📧 EMAIL SENT:');
      console.log('To:', options.to);
      console.log('Subject:', options.subject);
      console.log('Content:', options.html || options.text);
      console.log('---\n');
      return Promise.resolve({ messageId: 'dev-' + Date.now() });
    }
  };
};

const emailTransporter = createEmailTransporter();

// Email templates
const emailTemplates = {
  bookingConfirmation: (request) => ({
    subject: '🚗 Breakdown Request Submitted - Vehicle RMS',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #3b82f6, #1d4ed8); padding: 30px; text-align: center; color: white;">
          <h1 style="margin: 0; font-size: 24px;">🚗 Request Submitted Successfully!</h1>
          <p style="margin: 10px 0 0 0; opacity: 0.9;">Your breakdown request has been sent to the mechanic</p>
        </div>
        
        <div style="padding: 30px; background: white;">
          <h2 style="color: #1d4ed8; margin-top: 0;">Request Details</h2>
          
          <div style="background: #f0f9ff; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p><strong>Tracking ID:</strong> ${request.trackingId}</p>
            <p><strong>Vehicle:</strong> ${request.vehicleMake} ${request.vehicleModel} (${request.vehicleType})</p>
            <p><strong>Problem:</strong> ${request.problemDescription}</p>
            <p><strong>Mechanic:</strong> ${request.mechanicName}</p>
            <p><strong>Estimated Cost:</strong> Le ${request.estimatedCost.toLocaleString()}</p>
          </div>
          
          <p style="color: #666;">
            You will receive email notifications when the mechanic responds to your request.
          </p>
        </div>
        
        <div style="background: #f9fafb; padding: 20px; text-align: center; color: #666; font-size: 12px;">
          <p>Vehicle Repair Management System | Professional Roadside Assistance</p>
        </div>
      </div>
    `
  }),

  acceptance: (request, trackingUrl) => ({
    subject: '✅ Request Accepted - Vehicle RMS',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #10b981, #059669); padding: 30px; text-align: center; color: white;">
          <h1 style="margin: 0; font-size: 24px;">✅ Request Accepted!</h1>
          <p style="margin: 10px 0 0 0; opacity: 0.9;">Your vehicle repair request has been accepted</p>
        </div>
        
        <div style="padding: 30px; background: white;">
          <h2 style="color: #059669; margin-top: 0;">Great News!</h2>
          <p><strong>${request.mechanicName}</strong> has accepted your vehicle repair request.</p>
          
          <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #059669;">Service Details:</h3>
            <p><strong>Tracking ID:</strong> ${request.trackingId}</p>
            <p><strong>Vehicle:</strong> ${request.vehicleMake} ${request.vehicleModel} (${request.vehicleType})</p>
            <p><strong>Problem:</strong> ${request.problemDescription}</p>
            <p><strong>Mechanic:</strong> ${request.mechanicName}</p>
            <p><strong>Contact:</strong> ${request.mechanicPhone}</p>
            <p><strong>Estimated Cost:</strong> Le ${request.estimatedCost.toLocaleString()}</p>
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${trackingUrl}" style="background: #059669; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">
              🗺️ Track Your Service
            </a>
          </div>
          
          <p style="color: #666; font-size: 14px;">
            Use the tracking link above to monitor your mechanic's location and service progress in real-time.
          </p>
        </div>
        
        <div style="background: #f9fafb; padding: 20px; text-align: center; color: #666; font-size: 12px;">
          <p>Vehicle Repair Management System | Professional Roadside Assistance</p>
        </div>
      </div>
    `
  }),

  rejection: (request, rejectionReason, bookingUrl) => ({
    subject: '❌ Request Update',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #ef4444, #dc2626); padding: 30px; text-align: center; color: white;">
          <h1 style="margin: 0; font-size: 24px;">❌ Request Update</h1>
          <p style="margin: 10px 0 0 0; opacity: 0.9;">Your vehicle repair request status</p>
        </div>
        
        <div style="padding: 30px; background: white;">
          <p style="font-size: 18px; color: #333; margin-bottom: 20px;">
            <strong>${request.mechanicName}</strong> was unable to accept your request.
          </p>
          
          <div style="background: #fef2f2; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 0; color: #dc2626; font-weight: bold;">Reason:</p>
            <p style="margin: 5px 0 0 0; font-style: italic;">"${rejectionReason}"</p>
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${bookingUrl}" style="background: #2563eb; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">
              🔍 Find Another Mechanic
            </a>
          </div>
          
          <div style="background: #f0f9ff; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 0; color: #2563eb; font-weight: bold;">Don't worry! You can try booking with another available mechanic.</p>
          </div>
        </div>
        
        <div style="background: #f9fafb; padding: 20px; text-align: center; color: #666; font-size: 12px;">
          <p>Vehicle Repair Management System | Professional Roadside Assistance</p>
        </div>
      </div>
    `
  })
};

// Multer configuration for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = path.join(__dirname, 'uploads');
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true });
    }
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.fieldname === 'photos') {
      if (file.mimetype.startsWith('image/')) {
        cb(null, true);
      } else {
        cb(new Error('Only image files are allowed for photos'));
      }
    } else if (file.fieldname === 'audio') {
      if (file.mimetype.startsWith('audio/')) {
        cb(null, true);
      } else {
        cb(new Error('Only audio files are allowed'));
      }
    } else {
      cb(new Error('Unexpected field'));
    }
  }
});

// Utility functions
const generateTrackingId = () => {
  const timestamp = Date.now().toString().slice(-6);
  const random = Math.random().toString(36).substring(2, 5).toUpperCase();
  return `VRM-${new Date().getFullYear()}-${random}${timestamp}`;
};

const calculateDistance = (lat1, lng1, lat2, lng2) => {
  const R = 6371; // Earth's radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
};

const calculateEstimatedCost = (vehicleType, urgencyLevel) => {
  let baseCost = 75000; // Base cost in Sierra Leone Leones
  
  // Urgency multipliers
  const urgencyMultipliers = {
    'low': 1.0,
    'medium': 1.2,
    'high': 1.4,
    'emergency': 1.6,
  };
  
  // Vehicle type multipliers
  const vehicleMultipliers = {
    'sedan': 1.0,
    'suv': 1.2,
    'truck': 1.5,
    'van': 1.3,
    'motorcycle': 0.8,
    'bus': 1.6,
  };
  
  const urgencyMult = urgencyMultipliers[urgencyLevel] || 1.0;
  const vehicleMult = vehicleMultipliers[vehicleType.toLowerCase()] || 1.0;
  
  return Math.round(baseCost * urgencyMult * vehicleMult);
};

// Email sending function
const sendEmail = async (to, template) => {
  try {
    await emailTransporter.sendMail({
      from: process.env.EMAIL_FROM || 'noreply@vehiclerms.com',
      to: to,
      subject: template.subject,
      html: template.html
    });
    return true;
  } catch (error) {
    console.error('Email sending error:', error);
    return false;
  }
};

// API Routes

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    message: 'Vehicle RMS API is running',
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

// Get available mechanics
app.get('/api/mechanics/available', (req, res) => {
  try {
    const { lat, lng } = req.query;
    const db = readDatabase();
    
    // Get online, approved mechanics
    const availableMechanics = db.mechanics.filter(m => 
      m.isOnline && m.isApproved && !m.isSuspended
    );
    
    // Calculate distances if driver location provided
    if (lat && lng) {
      const driverLat = parseFloat(lat);
      const driverLng = parseFloat(lng);
      
      availableMechanics.forEach(mechanic => {
        if (mechanic.currentLocation) {
          const distance = calculateDistance(
            driverLat, driverLng,
            mechanic.currentLocation.lat, mechanic.currentLocation.lng
          );
          mechanic.distance = Math.round(distance * 10) / 10; // Round to 1 decimal
          mechanic.etaMinutes = Math.round(distance * 2.5); // Assume 24km/h average
        }
      });
      
      // Sort by distance
      availableMechanics.sort((a, b) => (a.distance || 999) - (b.distance || 999));
    }
    
    res.json({
      success: true,
      mechanics: availableMechanics,
      count: availableMechanics.length
    });
  } catch (error) {
    console.error('Error fetching mechanics:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get specific mechanic
app.get('/api/mechanics/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { lat, lng } = req.query;
    const db = readDatabase();
    
    const mechanic = db.mechanics.find(m => m.id === id);
    if (!mechanic) {
      return res.status(404).json({ success: false, message: 'Mechanic not found' });
    }
    
    // Calculate distance if driver location provided
    if (lat && lng && mechanic.currentLocation) {
      const distance = calculateDistance(
        parseFloat(lat), parseFloat(lng),
        mechanic.currentLocation.lat, mechanic.currentLocation.lng
      );
      mechanic.distance = Math.round(distance * 10) / 10;
      mechanic.etaMinutes = Math.round(distance * 2.5);
    }
    
    res.json({
      success: true,
      mechanic: mechanic
    });
  } catch (error) {
    console.error('Error fetching mechanic:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Create breakdown request
app.post('/api/bookings/create', upload.fields([
  { name: 'photos', maxCount: 5 },
  { name: 'audio', maxCount: 1 }
]), async (req, res) => {
  try {
    const db = readDatabase();
    
    // Find selected mechanic
    const mechanic = db.mechanics.find(m => m.id === req.body.mechanicId);
    if (!mechanic) {
      return res.status(404).json({ success: false, message: 'Mechanic not found' });
    }
    
    // Generate tracking ID
    const trackingId = generateTrackingId();
    
    // Process uploaded files
    const photos = req.files?.photos ? req.files.photos.map(file => `/uploads/${file.filename}`) : [];
    const audioFile = req.files?.audio ? `/uploads/${req.files.audio[0].filename}` : null;
    
    // Calculate estimated cost
    const estimatedCost = calculateEstimatedCost(req.body.vehicleType, req.body.urgencyLevel);
    
    // Create breakdown request
    const breakdownRequest = {
      id: `req-${Date.now()}`,
      trackingId: trackingId,
      driverPhone: req.body.driverPhone,
      driverEmail: req.body.driverEmail,
      driverName: req.body.driverName || '',
      vehicleType: req.body.vehicleType,
      vehicleMake: req.body.vehicleMake || '',
      vehicleModel: req.body.vehicleModel || '',
      vehicleYear: req.body.vehicleYear || '',
      problemDescription: req.body.problemDescription,
      urgencyLevel: req.body.urgencyLevel,
      additionalNotes: req.body.additionalNotes || '',
      breakdownLat: parseFloat(req.body.breakdownLat),
      breakdownLng: parseFloat(req.body.breakdownLng),
      breakdownAddress: req.body.breakdownAddress || '',
      mechanicId: req.body.mechanicId,
      mechanicName: mechanic.businessName,
      mechanicPhone: mechanic.phone,
      status: 'pending',
      estimatedCost: estimatedCost,
      photos: photos,
      audioExplanation: audioFile,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      emailSent: false,
      smsSent: false
    };
    
    // Save to database
    db.breakdownRequests.push(breakdownRequest);
    
    // Create initial status history
    db.statusHistory.push({
      id: `status-${Date.now()}`,
      breakdownRequestId: breakdownRequest.id,
      status: 'pending',
      message: 'Breakdown request submitted',
      timestamp: new Date().toISOString(),
      updatedBy: 'system'
    });
    
    writeDatabase(db);
    
    // Send confirmation email
    const emailTemplate = emailTemplates.bookingConfirmation(breakdownRequest);
    await sendEmail(breakdownRequest.driverEmail, emailTemplate);
    
    // Update email sent status
    breakdownRequest.emailSent = true;
    writeDatabase(db);
    
    res.status(201).json({
      success: true,
      message: 'Breakdown request created successfully',
      trackingId: trackingId,
      trackingUrl: `${req.protocol}://${req.get('host')}/driver-track/${trackingId}`,
      estimatedCost: estimatedCost,
      mechanic: {
        businessName: mechanic.businessName,
        phone: mechanic.phone
      }
    });
    
  } catch (error) {
    console.error('Error creating breakdown request:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get pending requests for mechanic
app.get('/api/bookings/mechanic/:mechanicId/pending', (req, res) => {
  try {
    const { mechanicId } = req.params;
    const db = readDatabase();
    
    const pendingRequests = db.breakdownRequests.filter(r => 
      r.mechanicId === mechanicId && r.status === 'pending'
    );
    
    res.json({
      success: true,
      requests: pendingRequests,
      count: pendingRequests.length
    });
  } catch (error) {
    console.error('Error fetching pending requests:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Accept breakdown request
app.patch('/api/bookings/:requestId/accept', async (req, res) => {
  try {
    const { requestId } = req.params;
    const db = readDatabase();
    
    const request = db.breakdownRequests.find(r => r.id === requestId);
    if (!request) {
      return res.status(404).json({ success: false, message: 'Request not found' });
    }
    
    if (request.status !== 'pending') {
      return res.status(400).json({ success: false, message: 'Request already processed' });
    }
    
    // Update request status
    request.status = 'accepted';
    request.acceptedAt = new Date().toISOString();
    request.updatedAt = new Date().toISOString();
    
    // Add status history
    db.statusHistory.push({
      id: `status-${Date.now()}`,
      breakdownRequestId: request.id,
      status: 'accepted',
      message: 'Mechanic accepted the request',
      timestamp: new Date().toISOString(),
      updatedBy: request.mechanicId
    });
    
    writeDatabase(db);
    
    // Send acceptance email
    const trackingUrl = `${req.protocol}://${req.get('host')}/driver-track/${request.trackingId}`;
    const emailTemplate = emailTemplates.acceptance(request, trackingUrl);
    await sendEmail(request.driverEmail, emailTemplate);
    
    res.json({
      success: true,
      message: 'Request accepted successfully. Driver has been notified.',
      trackingId: request.trackingId
    });
    
  } catch (error) {
    console.error('Error accepting request:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Reject breakdown request
app.patch('/api/bookings/:requestId/reject', async (req, res) => {
  try {
    const { requestId } = req.params;
    const { reason } = req.body;
    const db = readDatabase();
    
    const request = db.breakdownRequests.find(r => r.id === requestId);
    if (!request) {
      return res.status(404).json({ success: false, message: 'Request not found' });
    }
    
    if (request.status !== 'pending') {
      return res.status(400).json({ success: false, message: 'Request already processed' });
    }
    
    // Update request status
    request.status = 'rejected';
    request.rejectionReason = reason || 'No reason provided';
    request.updatedAt = new Date().toISOString();
    
    // Add status history
    db.statusHistory.push({
      id: `status-${Date.now()}`,
      breakdownRequestId: request.id,
      status: 'rejected',
      message: `Request rejected: ${request.rejectionReason}`,
      timestamp: new Date().toISOString(),
      updatedBy: request.mechanicId
    });
    
    writeDatabase(db);
    
    // Send rejection email with exact format
    const bookingUrl = `${req.protocol}://${req.get('host')}/driver-booking`;
    const emailTemplate = emailTemplates.rejection(request, request.rejectionReason, bookingUrl);
    await sendEmail(request.driverEmail, emailTemplate);
    
    res.json({
      success: true,
      message: 'Request rejected. Driver has been notified.',
      rejectionReason: request.rejectionReason
    });
    
  } catch (error) {
    console.error('Error rejecting request:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Update request status
app.patch('/api/bookings/:requestId/status', async (req, res) => {
  try {
    const { requestId } = req.params;
    const { status } = req.body;
    const db = readDatabase();
    
    const request = db.breakdownRequests.find(r => r.id === requestId);
    if (!request) {
      return res.status(404).json({ success: false, message: 'Request not found' });
    }
    
    const validStatuses = ['en_route', 'arrived', 'working', 'completed'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status' });
    }
    
    // Update request
    request.status = status;
    request.updatedAt = new Date().toISOString();
    
    if (status === 'completed') {
      request.completedAt = new Date().toISOString();
    }
    
    // Add status history
    const statusMessages = {
      'en_route': 'Mechanic is on the way',
      'arrived': 'Mechanic has arrived at location',
      'working': 'Repair work has started',
      'completed': 'Service has been completed'
    };
    
    db.statusHistory.push({
      id: `status-${Date.now()}`,
      breakdownRequestId: request.id,
      status: status,
      message: statusMessages[status],
      timestamp: new Date().toISOString(),
      updatedBy: request.mechanicId
    });
    
    writeDatabase(db);
    
    // Send status update email (simplified for now)
    const statusUpdateTemplate = {
      subject: `🔄 Service Update - ${statusMessages[status]}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #3b82f6, #1d4ed8); padding: 30px; text-align: center; color: white;">
            <h1 style="margin: 0; font-size: 24px;">🔄 Service Update</h1>
            <p style="margin: 10px 0 0 0; opacity: 0.9;">Your service progress has been updated</p>
          </div>
          
          <div style="padding: 30px; background: white;">
            <h2 style="color: #1d4ed8; margin-top: 0;">Status Update</h2>
            <p><strong>${statusMessages[status]}</strong></p>
            
            <div style="background: #f0f9ff; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <p><strong>Tracking ID:</strong> ${request.trackingId}</p>
              <p><strong>Current Status:</strong> ${status.toUpperCase()}</p>
              <p><strong>Mechanic:</strong> ${request.mechanicName}</p>
            </div>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="${req.protocol}://${req.get('host')}/driver-track/${request.trackingId}" style="background: #2563eb; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">
                🗺️ View Live Tracking
              </a>
            </div>
          </div>
        </div>
      `
    };
    
    await sendEmail(request.driverEmail, statusUpdateTemplate);
    
    res.json({
      success: true,
      message: `Status updated to ${status}. Driver has been notified.`,
      status: status,
      trackingId: request.trackingId
    });
    
  } catch (error) {
    console.error('Error updating status:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get tracking data (public access)
app.get('/api/tracking/:trackingId', (req, res) => {
  try {
    const { trackingId } = req.params;
    const db = readDatabase();
    
    const request = db.breakdownRequests.find(r => r.trackingId === trackingId);
    if (!request) {
      return res.status(404).json({ success: false, message: 'Tracking ID not found' });
    }
    
    // Get mechanic details
    const mechanic = db.mechanics.find(m => m.id === request.mechanicId);
    if (!mechanic) {
      return res.status(404).json({ success: false, message: 'Mechanic not found' });
    }
    
    // Get status history
    const statusHistory = db.statusHistory.filter(s => s.breakdownRequestId === request.id);
    
    // Calculate real-time distance and ETA
    let distance = null;
    let estimatedArrival = null;
    
    if (mechanic.currentLocation && request.status === 'en_route') {
      const dist = calculateDistance(
        request.breakdownLat, request.breakdownLng,
        mechanic.currentLocation.lat, mechanic.currentLocation.lng
      );
      distance = `${dist.toFixed(1)} km`;
      estimatedArrival = `~${Math.round(dist * 2.5)} min`;
    }
    
    // Create or update tracking session
    let trackingSession = db.trackingSessions.find(s => s.trackingId === trackingId);
    if (!trackingSession) {
      trackingSession = {
        id: `session-${Date.now()}`,
        trackingId: trackingId,
        sessionId: `session_${trackingId}_${Date.now()}`,
        accessCount: 0,
        lastAccessed: new Date().toISOString(),
        isActive: true
      };
      db.trackingSessions.push(trackingSession);
    }
    
    trackingSession.accessCount += 1;
    trackingSession.lastAccessed = new Date().toISOString();
    writeDatabase(db);
    
    res.json({
      success: true,
      trackingData: {
        id: request.id,
        trackingId: request.trackingId,
        status: request.status,
        rejectionReason: request.rejectionReason,
        mechanic: {
          id: mechanic.id,
          name: mechanic.username,
          businessName: mechanic.businessName,
          phone: mechanic.phone,
          photo: 'https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
          rating: mechanic.rating,
          specializations: mechanic.specialties,
          currentLocation: mechanic.currentLocation
        },
        driver: {
          phone: request.driverPhone,
          email: request.driverEmail,
          vehicleType: request.vehicleType,
          vehicleMake: request.vehicleMake,
          vehicleModel: request.vehicleModel,
          problemDescription: request.problemDescription,
          urgencyLevel: request.urgencyLevel,
          photos: request.photos,
          audioExplanation: request.audioExplanation
        },
        location: {
          driver: { lat: request.breakdownLat, lng: request.breakdownLng },
          mechanic: mechanic.currentLocation
        },
        estimatedCost: request.estimatedCost,
        estimatedArrival: estimatedArrival,
        distance: distance,
        createdAt: request.createdAt,
        updatedAt: request.updatedAt,
        completedAt: request.completedAt,
        statusHistory: statusHistory.map(s => ({
          status: s.status,
          message: s.message,
          timestamp: s.timestamp
        })),
        trackingUrl: `${req.protocol}://${req.get('host')}/driver-track/${trackingId}`,
        lastUpdate: new Date().toISOString()
      }
    });
    
  } catch (error) {
    console.error('Error fetching tracking data:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Update mechanic location
app.patch('/api/tracking/:trackingId/location', (req, res) => {
  try {
    const { trackingId } = req.params;
    const { lat, lng, accuracy = 10 } = req.body;
    const db = readDatabase();
    
    const request = db.breakdownRequests.find(r => r.trackingId === trackingId);
    if (!request) {
      return res.status(404).json({ success: false, message: 'Tracking ID not found' });
    }
    
    // Update mechanic location
    const mechanic = db.mechanics.find(m => m.id === request.mechanicId);
    if (mechanic) {
      mechanic.currentLocation = { lat: parseFloat(lat), lng: parseFloat(lng) };
      mechanic.lastLocationUpdate = new Date().toISOString();
    }
    
    writeDatabase(db);
    
    res.json({
      success: true,
      message: 'Location updated successfully',
      location: { lat: parseFloat(lat), lng: parseFloat(lng), accuracy, timestamp: new Date().toISOString() }
    });
    
  } catch (error) {
    console.error('Error updating location:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Process payment
app.post('/api/bookings/:requestId/payment', async (req, res) => {
  try {
    const { requestId } = req.params;
    const { paymentMethod, phoneNumber, fullName, pin } = req.body;
    const db = readDatabase();
    
    const request = db.breakdownRequests.find(r => r.id === requestId);
    if (!request || request.status !== 'completed') {
      return res.status(404).json({ success: false, message: 'Request not found or not ready for payment' });
    }
    
    // Calculate payment breakdown
    const totalAmount = request.estimatedCost;
    const adminCommission = Math.round(totalAmount * 0.15); // 15%
    const processingFee = Math.round(totalAmount * 0.02); // 2%
    const mechanicAmount = totalAmount - adminCommission - processingFee;
    
    // Generate verification code
    const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();
    
    // Create payment record
    const payment = {
      id: `pay-${Date.now()}`,
      breakdownRequestId: request.id,
      amount: totalAmount,
      mechanicAmount: mechanicAmount,
      adminCommission: adminCommission,
      processingFee: processingFee,
      paymentMethod: paymentMethod,
      phoneNumber: phoneNumber,
      fullName: fullName,
      transactionId: `TXN${Date.now()}`,
      verificationCode: verificationCode,
      status: 'processing',
      createdAt: new Date().toISOString()
    };
    
    db.payments.push(payment);
    writeDatabase(db);
    
    res.json({
      success: true,
      message: 'Verification code sent to your phone',
      paymentId: payment.id,
      verificationRequired: true,
      amount: totalAmount,
      smsMessage: `Your verification code is: ${verificationCode}. Enter this code to complete your payment of Le ${totalAmount.toLocaleString()}.`
    });
    
  } catch (error) {
    console.error('Error processing payment:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Verify payment
app.post('/api/payments/:paymentId/verify', async (req, res) => {
  try {
    const { paymentId } = req.params;
    const { verificationCode } = req.body;
    const db = readDatabase();
    
    const payment = db.payments.find(p => p.id === paymentId);
    if (!payment || payment.status !== 'processing') {
      return res.status(404).json({ success: false, message: 'Payment not found' });
    }
    
    if (verificationCode !== payment.verificationCode) {
      return res.status(400).json({ success: false, message: 'Invalid verification code' });
    }
    
    // Complete payment
    payment.status = 'completed';
    payment.completedAt = new Date().toISOString();
    
    // Update breakdown request
    const request = db.breakdownRequests.find(r => r.id === payment.breakdownRequestId);
    if (request) {
      request.isPaid = true;
      request.finalCost = payment.amount;
      request.paymentMethod = payment.paymentMethod;
    }
    
    // Update mechanic balance
    const mechanic = db.mechanics.find(m => m.id === request.mechanicId);
    if (mechanic) {
      mechanic.balance = (mechanic.balance || 0) + payment.mechanicAmount;
    }
    
    writeDatabase(db);
    
    res.json({
      success: true,
      message: 'Payment completed successfully',
      transactionId: payment.transactionId,
      amount: payment.amount,
      mechanicAmount: payment.mechanicAmount
    });
    
  } catch (error) {
    console.error('Error verifying payment:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Authentication endpoints
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const db = readDatabase();
    
    // Check in users first
    let user = db.users.find(u => u.email === email);
    
    // If not found in users, check in mechanics
    if (!user) {
      const mechanic = db.mechanics.find(m => m.email === email);
      if (mechanic) {
        user = {
          id: mechanic.userId || mechanic.id,
          username: mechanic.username,
          email: mechanic.email,
          phone: mechanic.phone,
          password: mechanic.password,
          role: 'mechanic',
          isApproved: mechanic.isApproved,
          isSuspended: mechanic.isSuspended,
          currentLocation: mechanic.currentLocation,
          balance: mechanic.balance
        };
      }
    }
    
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
    
    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
    
    // Check approval status
    if (user.role === 'mechanic' && !user.isApproved) {
      return res.status(401).json({ success: false, message: 'Account pending approval' });
    }
    
    if (user.isSuspended) {
      return res.status(401).json({ success: false, message: 'Account suspended' });
    }
    
    // Generate JWT token
    const token = jwt.sign(
      { userId: user.id, email: user.email, role: user.role },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '24h' }
    );
    
    // Remove password from response
    const { password: _, ...userResponse } = user;
    
    res.json({
      success: true,
      message: 'Login successful',
      user: userResponse,
      tokens: {
        access: token,
        refresh: token // Simplified for demo
      }
    });
    
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Test email endpoint
app.post('/api/notifications/test-email', async (req, res) => {
  try {
    const { email } = req.body;
    
    const testTemplate = {
      subject: '🧪 Test Email - Vehicle RMS',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #10b981, #059669); padding: 30px; text-align: center; color: white;">
            <h1 style="margin: 0; font-size: 24px;">🧪 Test Email</h1>
            <p style="margin: 10px 0 0 0; opacity: 0.9;">Email system is working correctly!</p>
          </div>
          
          <div style="padding: 30px; background: white;">
            <p>This is a test email from Vehicle Repair Management System.</p>
            <p>If you received this email, the email system is working correctly!</p>
            <p>Best regards,<br>Vehicle RMS Team</p>
          </div>
        </div>
      `
    };
    
    await sendEmail(email || 'test@example.com', testTemplate);
    
    res.json({
      success: true,
      message: `Test email sent to ${email || 'test@example.com'}`
    });
    
  } catch (error) {
    console.error('Test email error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('Server error:', error);
  res.status(500).json({
    success: false,
    message: 'Internal server error',
    error: process.env.NODE_ENV === 'development' ? error.message : undefined
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    success: false,
    message: 'API endpoint not found'
  });
});

// Initialize database and start server
initializeDatabase();

app.listen(PORT, () => {
  console.log(`\n🚀 Vehicle RMS Backend Server Running`);
  console.log(`📍 Server: http://localhost:${PORT}`);
  console.log(`🔌 API Base: http://localhost:${PORT}/api`);
  console.log(`📧 Email Mode: ${process.env.NODE_ENV === 'production' ? 'SMTP' : 'Console Logging'}`);
  console.log(`\n📋 Sample Accounts:`);
  console.log(`Admin: admin@vehiclerms.com / admin123`);
  console.log(`Mechanics: mechanic123 (password for all mechanics)`);
  console.log(`\n✅ Ready to accept requests!\n`);
});