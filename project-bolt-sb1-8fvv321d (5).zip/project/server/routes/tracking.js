const express = require('express');
const router = express.Router();
const { readDatabase, writeDatabase } = require('../database/db');
const path = require('path');

// Get booking by tracking ID (public access - no auth required)
router.get('/:trackingId', async (req, res) => {
  try {
    const { trackingId } = req.params;
    const db = readDatabase();
    
    // Find booking by tracking ID
    const booking = db.bookings.find(b => b.trackingId === trackingId);
    
    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found' });
    }

    // Get mechanic details
    const mechanic = db.mechanics.find(m => m.id === booking.mechanicId);
    if (!mechanic) {
      return res.status(404).json({ success: false, message: 'Mechanic not found' });
    }

    // Calculate distance and ETA if both locations available
    let distance = null;
    let estimatedArrival = null;
    
    if (booking.location && mechanic.currentLocation) {
      const lat1 = booking.location.lat;
      const lng1 = booking.location.lng;
      const lat2 = mechanic.currentLocation.lat;
      const lng2 = mechanic.currentLocation.lng;
      
      const R = 6371; // Earth's radius in km
      const dLat = (lat2 - lat1) * Math.PI / 180;
      const dLng = (lng2 - lng1) * Math.PI / 180;
      const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                Math.sin(dLng/2) * Math.sin(dLng/2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
      const distanceKm = R * c;
      
      distance = `${distanceKm.toFixed(1)} km`;
      estimatedArrival = `~${Math.round(distanceKm * 2)} min`;
    }

    // Add status history if not exists
    if (!booking.statusHistory) {
      booking.statusHistory = [
        { status: 'pending', timestamp: booking.createdAt, message: 'Request submitted' }
      ];
    }

    res.json({
      success: true,
      booking: {
        ...booking,
        mechanic,
        distance,
        estimatedArrival,
        statusHistory: booking.statusHistory
      }
    });
  } catch (error) {
    console.error('Error fetching booking:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;